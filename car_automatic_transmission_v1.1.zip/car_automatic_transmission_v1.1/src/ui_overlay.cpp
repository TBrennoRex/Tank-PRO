#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <stdio.h>
#include <math.h>
#include <vector>
#include <string>
#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>
#include "car_automatic_transmission_manager/car_automatic_transmission_manager.h"
#include "car_automatic_transmission_manager/car_automatic_transmission_manager_impl_win32.h"
#include "car_automatic_transmission_manager/car_automatic_transmission_manager_impl_dx11.h"
#include "minhook/include/MinHook.h"
#include "car_automatic_transmission.h"

typedef HRESULT (STDMETHODCALLTYPE *Present_t)(IDXGISwapChain*, UINT, UINT);
typedef HRESULT (STDMETHODCALLTYPE *ResizeBuffers_t)(IDXGISwapChain*, UINT, UINT, UINT, DXGI_FORMAT, UINT);
typedef BOOL (WINAPI *SetCursorPos_t)(int X, int Y);
typedef BOOL (WINAPI *GetCursorPos_t)(LPPOINT lpPoint);
typedef BOOL (WINAPI *GetCursorInfo_t)(PCURSORINFO pci);
typedef BOOL (WINAPI *ClipCursor_t)(const RECT *lpRect);
typedef HRESULT (STDMETHODCALLTYPE *GetDeviceState_t)(IDirectInputDevice8A*, DWORD, LPVOID);
typedef HRESULT (STDMETHODCALLTYPE *GetDeviceData_t)(IDirectInputDevice8A*, DWORD, LPDIDEVICEOBJECTDATA, LPDWORD, DWORD);

static Present_t       oPresent = NULL;
static ResizeBuffers_t oResizeBuffers = NULL;
static SetCursorPos_t  oSetCursorPos = NULL;
static GetCursorPos_t  oGetCursorPos = NULL;
static GetCursorInfo_t oGetCursorInfo = NULL;
static ClipCursor_t    oClipCursor = NULL;
static GetDeviceState_t oGetDeviceState = NULL;
static GetDeviceData_t  oGetDeviceData = NULL;
static void*           g_pGetDeviceStateTarget = NULL;
static void*           g_pGetDeviceDataTarget = NULL;

static WNDPROC         g_oWndProc = NULL;
static HWND            g_hGameWindow = NULL;
static ID3D11Device*   g_pd3dDevice = NULL;
static ID3D11DeviceContext* g_pd3dContext = NULL;
static ID3D11RenderTargetView* g_mainRenderTargetView = NULL;
static bool            g_bInitialized = false;
static bool            g_bShowMenu = false;
static char            g_saveMsg[64] = "";
static DWORD           g_saveMsgTime = 0;
static void*           g_pPresentTarget = NULL;
static void*           g_pResizeBuffersTarget = NULL;
static POINT           g_gameCenterPos = { 0, 0 };

extern IMGUI_IMPL_API LRESULT CarAutomaticTransmissionManager_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

static HANDLE g_hOverlayEvent = NULL;

static void EnsureOverlayEvent(void)
{
    if (!g_hOverlayEvent) {
        g_hOverlayEvent = CreateEventA(NULL, TRUE, FALSE, "Local\\ETS2_Plugin_Overlay_Active");
    }
}

static bool IsAnyMenuOpen(void)
{
    if (g_bShowMenu) return true;
    EnsureOverlayEvent();
    if (g_hOverlayEvent) {
        return (WaitForSingleObject(g_hOverlayEvent, 0) == WAIT_OBJECT_0);
    }
    return false;
}

static void NotifyMenuState(bool open)
{
    EnsureOverlayEvent();
    if (g_hOverlayEvent) {
        if (open) SetEvent(g_hOverlayEvent);
        else ResetEvent(g_hOverlayEvent);
    }
}

static bool IsCallerExe(void* return_address)
{
    static uintptr_t s_exe_start = 0;
    static uintptr_t s_exe_end = 0;
    if (!s_exe_start) {
        s_exe_start = (uintptr_t)GetModuleHandleA(NULL);
        if (s_exe_start) {
            const unsigned char* b = (const unsigned char*)s_exe_start;
            const IMAGE_DOS_HEADER* dos = (const IMAGE_DOS_HEADER*)b;
            if (dos->e_magic == IMAGE_DOS_SIGNATURE) {
                const IMAGE_NT_HEADERS* nt = (const IMAGE_NT_HEADERS*)(b + dos->e_lfanew);
                if (nt->Signature == IMAGE_NT_SIGNATURE) {
                    s_exe_end = s_exe_start + nt->OptionalHeader.SizeOfImage;
                }
            }
            if (!s_exe_end) s_exe_end = s_exe_start + 0x08000000;
        }
    }
    uintptr_t addr = (uintptr_t)return_address;
    return (addr >= s_exe_start && addr < s_exe_end);
}

static BOOL WINAPI HookedSetCursorPos(int X, int Y)
{
    g_gameCenterPos.x = X;
    g_gameCenterPos.y = Y;

    if (IsAnyMenuOpen()) {
        return TRUE;
    }
    if (oSetCursorPos) return oSetCursorPos(X, Y);
    return SetCursorPos(X, Y);
}

static BOOL WINAPI HookedGetCursorPos(LPPOINT lpPoint)
{
    if (IsAnyMenuOpen() && lpPoint && IsCallerExe(__builtin_return_address(0))) {
        if (g_gameCenterPos.x == 0 && g_gameCenterPos.y == 0 && g_hGameWindow) {
            RECT rc;
            if (GetClientRect(g_hGameWindow, &rc)) {
                POINT pt = { (rc.right - rc.left) / 2, (rc.bottom - rc.top) / 2 };
                ClientToScreen(g_hGameWindow, &pt);
                g_gameCenterPos = pt;
            }
        }
        *lpPoint = g_gameCenterPos;
        return TRUE;
    }

    if (oGetCursorPos) return oGetCursorPos(lpPoint);
    return GetCursorPos(lpPoint);
}

static BOOL WINAPI HookedGetCursorInfo(PCURSORINFO pci)
{
    BOOL res = oGetCursorInfo ? oGetCursorInfo(pci) : GetCursorInfo(pci);
    if (res && IsAnyMenuOpen() && pci && IsCallerExe(__builtin_return_address(0))) {
        if (g_gameCenterPos.x != 0 || g_gameCenterPos.y != 0) {
            pci->ptScreenPos = g_gameCenterPos;
        }
    }
    return res;
}

static BOOL WINAPI HookedClipCursor(const RECT *lpRect)
{
    if (IsAnyMenuOpen()) {
        if (oClipCursor) return oClipCursor(NULL);
        return ClipCursor(NULL);
    }
    if (oClipCursor) return oClipCursor(lpRect);
    return ClipCursor(lpRect);
}

static HRESULT STDMETHODCALLTYPE HookedGetDeviceState(IDirectInputDevice8A* pDevice, DWORD cbData, LPVOID lpvData)
{
    HRESULT hr = oGetDeviceState(pDevice, cbData, lpvData);
    if (IsAnyMenuOpen() && SUCCEEDED(hr) && lpvData) {
        if (cbData == sizeof(DIMOUSESTATE)) {
            DIMOUSESTATE* ms = (DIMOUSESTATE*)lpvData;
            ms->lX = 0;
            ms->lY = 0;
            ms->lZ = 0;
            memset(ms->rgbButtons, 0, sizeof(ms->rgbButtons));
        } else if (cbData == sizeof(DIMOUSESTATE2)) {
            DIMOUSESTATE2* ms2 = (DIMOUSESTATE2*)lpvData;
            ms2->lX = 0;
            ms2->lY = 0;
            ms2->lZ = 0;
            memset(ms2->rgbButtons, 0, sizeof(ms2->rgbButtons));
        }
    }
    return hr;
}

static HRESULT STDMETHODCALLTYPE HookedGetDeviceData(IDirectInputDevice8A* pDevice, DWORD cbObjectData, LPDIDEVICEOBJECTDATA rgdod, LPDWORD pdwInOut, DWORD dwFlags)
{
    HRESULT hr = oGetDeviceData(pDevice, cbObjectData, rgdod, pdwInOut, dwFlags);
    if (IsAnyMenuOpen() && SUCCEEDED(hr)) {
        DIDEVCAPS caps;
        caps.dwSize = sizeof(caps);
        if (SUCCEEDED(pDevice->GetCapabilities(&caps))) {
            if (GET_DIDEVICE_TYPE(caps.dwDevType) == DI8DEVTYPE_MOUSE) {
                if (pdwInOut) *pdwInOut = 0;
            }
        }
    }
    return hr;
}

static DWORD s_lastToggleTick = 0;

static bool s_bListeningForKey = false;
static DWORD s_listenStartTick = 0;
static int s_justBoundVk = 0;
static DWORD s_boundTick = 0;

static bool s_bListeningForModeKey = false;
static DWORD s_listenModeStartTick = 0;
static int s_justBoundModeVk = 0;
static DWORD s_boundModeTick = 0;
static DWORD s_lastModeToggleTick = 0;

static void ToggleMenu(void)
{
    DWORD now = GetTickCount();
    if (now - s_lastToggleTick < 250) return;
    s_lastToggleTick = now;

    g_bShowMenu = !g_bShowMenu;
    NotifyMenuState(g_bShowMenu);
    trans_log("ToggleMenu: g_bShowMenu is now %d", g_bShowMenu);
    if (!g_bShowMenu) {
        s_bListeningForKey = false;
        s_bListeningForModeKey = false;
        s_justBoundVk = 0;
        s_justBoundModeVk = 0;
    }
    if (g_bShowMenu) {
        ClipCursor(NULL);
        ReleaseCapture();
    }
}

static LRESULT CALLBACK HookedWndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{

    if (s_bListeningForKey) {
        if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) {
            trans_log("HookedWndProc [LISTENING]: key 0x%X", (int)wParam);
            if (GetTickCount() - s_listenStartTick > 50) {
                int vk = (int)wParam;
                if (vk == VK_ESCAPE) {
                    trans_log("HookedWndProc [LISTENING]: ESC pressed, cancelling");
                    s_bListeningForKey = false;
                    return 1;
                }

                if (vk != VK_SHIFT && vk != VK_CONTROL && vk != VK_MENU &&
                    vk != VK_LWIN && vk != VK_RWIN && vk != VK_CAPITAL) {
                    trans_log("HookedWndProc [LISTENING]: assigning new key 0x%X", vk);
                    trans_set_menu_vk(vk);
                    s_bListeningForKey = false;
                    s_justBoundVk = vk;
                    s_boundTick = GetTickCount();
                    s_lastToggleTick = s_boundTick;
                    return 1;
                }
            }
        }
        if (msg >= WM_KEYFIRST && msg <= WM_KEYLAST) {
            return 1;
        }
    }

    if (s_bListeningForModeKey) {
        if (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) {
            trans_log("HookedWndProc [LISTENING MODE]: key 0x%X", (int)wParam);
            if (GetTickCount() - s_listenModeStartTick > 50) {
                int vk = (int)wParam;
                if (vk == VK_ESCAPE) {
                    trans_log("HookedWndProc [LISTENING MODE]: ESC pressed, cancelling");
                    s_bListeningForModeKey = false;
                    return 1;
                }

                if (vk != VK_SHIFT && vk != VK_CONTROL && vk != VK_MENU &&
                    vk != VK_LWIN && vk != VK_RWIN && vk != VK_CAPITAL) {
                    trans_log("HookedWndProc [LISTENING MODE]: assigning new mode key 0x%X", vk);
                    trans_set_mode_vk(vk);
                    s_bListeningForModeKey = false;
                    s_justBoundModeVk = vk;
                    s_boundModeTick = GetTickCount();
                    s_lastModeToggleTick = s_boundModeTick;
                    return 1;
                }
            }
        }
        if (msg >= WM_KEYFIRST && msg <= WM_KEYLAST) {
            return 1;
        }
    }

    if (s_justBoundVk != 0) {
        if (msg == WM_KEYUP || msg == WM_SYSKEYUP) {
            if ((int)wParam == s_justBoundVk) {
                trans_log("HookedWndProc [JUST_BOUND]: key 0x%X released", s_justBoundVk);
                s_justBoundVk = 0;
                return 1;
            }
        }
        if (GetTickCount() - s_boundTick > 1000) {
            s_justBoundVk = 0;
        } else if ((msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) && (int)wParam == s_justBoundVk) {
            return 1;
        }
    }

    if (s_justBoundModeVk != 0) {
        if (msg == WM_KEYUP || msg == WM_SYSKEYUP) {
            if ((int)wParam == s_justBoundModeVk) {
                trans_log("HookedWndProc [JUST_BOUND MODE]: key 0x%X released", s_justBoundModeVk);
                s_justBoundModeVk = 0;
                return 1;
            }
        }
        if (GetTickCount() - s_boundModeTick > 1000) {
            s_justBoundModeVk = 0;
        } else if ((msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) && (int)wParam == s_justBoundModeVk) {
            return 1;
        }
    }

    if (!s_bListeningForKey && !s_bListeningForModeKey && s_justBoundVk == 0 && (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN)) {
        if (cfg.menu_vk > 0 && (int)wParam == cfg.menu_vk) {
            trans_log("HookedWndProc: menu key matched! (0x%X == 0x%X)", (int)wParam, cfg.menu_vk);
            ToggleMenu();
            return 1;
        }
    }

    if (!s_bListeningForKey && !s_bListeningForModeKey && s_justBoundModeVk == 0 && (msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN)) {
        if (cfg.mode_vk > 0 && (int)wParam == cfg.mode_vk) {
            DWORD now = GetTickCount();
            if (now - s_lastModeToggleTick >= 250) {
                s_lastModeToggleTick = now;
                trans_log("HookedWndProc: mode key matched! (0x%X)", (int)wParam);
                trans_cycle_mode();
            }
            return 1;
        }
    }

    if (g_bShowMenu) {
        CarAutomaticTransmissionManager_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam);

        if (msg == WM_INPUT) {
            return DefWindowProcA(hWnd, msg, wParam, lParam);
        }

        if (msg >= WM_MOUSEFIRST && msg <= WM_MOUSELAST) {
            return 1;
        }

        if (msg == WM_MOUSEACTIVATE) {
            return MA_ACTIVATEANDEAT;
        }

        ImGuiIO& io = CarAutomaticTransmissionManager::GetIO();
        if (io.WantCaptureKeyboard) {
            if (msg >= WM_KEYFIRST && msg <= WM_KEYLAST) return 1;
        }
    } else if (IsAnyMenuOpen()) {

        if (msg == WM_INPUT) {
            return DefWindowProcA(hWnd, msg, wParam, lParam);
        }
    }

    return CallWindowProcA(g_oWndProc, hWnd, msg, wParam, lParam);
}

static char  s_hudTitle[64] = "";
static char  s_hudDesc[128] = "";
static int   s_hudModeIdx   = 0;
static DWORD s_hudNotifyTick = 0;

extern "C" void trans_trigger_hud_notification(const char* title, const char* desc, int mode_idx)
{
    if (title) strncpy(s_hudTitle, title, sizeof(s_hudTitle) - 1);
    else s_hudTitle[0] = 0;
    s_hudTitle[sizeof(s_hudTitle) - 1] = 0;

    if (desc) strncpy(s_hudDesc, desc, sizeof(s_hudDesc) - 1);
    else s_hudDesc[0] = 0;
    s_hudDesc[sizeof(s_hudDesc) - 1] = 0;

    s_hudModeIdx = mode_idx;
    s_hudNotifyTick = GetTickCount();
}

static void RenderHudToast(void)
{
    DWORD now = GetTickCount();
    if (s_hudNotifyTick == 0 || now - s_hudNotifyTick > 2400) {
        return;
    }

    DWORD elapsed = now - s_hudNotifyTick;
    float alpha = 1.0f;
    if (elapsed < 180) {
        alpha = (float)elapsed / 180.0f;
    } else if (elapsed > 1800) {
        alpha = 1.0f - (float)(elapsed - 1800) / 600.0f;
    }
    if (alpha < 0.0f) alpha = 0.0f;
    if (alpha > 1.0f) alpha = 1.0f;

    ImVec4 border_col;
    ImVec4 badge_col;
    const char* badge_text = "";
    switch (s_hudModeIdx) {
        case 0:
            border_col = ImVec4(0.20f, 0.85f, 0.40f, alpha);
            badge_col  = ImVec4(0.20f, 0.85f, 0.40f, alpha);
            badge_text = "NORMAL";
            break;
        case 1:
            border_col = ImVec4(1.00f, 0.35f, 0.15f, alpha);
            badge_col  = ImVec4(1.00f, 0.35f, 0.15f, alpha);
            badge_text = "SPORT";
            break;
        case 2:
            border_col = ImVec4(0.25f, 0.65f, 1.00f, alpha);
            badge_col  = ImVec4(0.25f, 0.65f, 1.00f, alpha);
            badge_text = "COMFORT";
            break;
        default:
            border_col = ImVec4(0.65f, 0.65f, 0.70f, alpha);
            badge_col  = ImVec4(0.65f, 0.65f, 0.70f, alpha);
            badge_text = "STOCK (TRUCK)";
            break;
    }

    char label[64];
    snprintf(label, sizeof(label), "MODE: %s", badge_text);

    ImGuiIO& io = CarAutomaticTransmissionManager::GetIO();
    float text_w = CarAutomaticTransmissionManager::CalcTextSize(label).x;
    float toast_w = text_w + 40.0f;
    float toast_h = 36.0f;
    float pos_x = (io.DisplaySize.x - toast_w) * 0.5f;
    float pos_y = 50.0f;

    CarAutomaticTransmissionManager::SetNextWindowPos(ImVec2(pos_x, pos_y), ImGuiCond_Always);
    CarAutomaticTransmissionManager::SetNextWindowSize(ImVec2(toast_w, toast_h), ImGuiCond_Always);

    CarAutomaticTransmissionManager::PushStyleVar(ImGuiStyleVar_WindowRounding, 6.0f);
    CarAutomaticTransmissionManager::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.0f);
    CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.08f, 0.09f, 0.12f, alpha * 0.94f));
    CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_Border, border_col);
    CarAutomaticTransmissionManager::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(10.0f, 6.0f));

    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration |
                            ImGuiWindowFlags_NoInputs |
                            ImGuiWindowFlags_NoNav |
                            ImGuiWindowFlags_AlwaysAutoResize |
                            ImGuiWindowFlags_NoSavedSettings |
                            ImGuiWindowFlags_NoFocusOnAppearing;

    if (CarAutomaticTransmissionManager::Begin("##TransHudToast", NULL, flags)) {
        CarAutomaticTransmissionManager::SetCursorPosX((toast_w - text_w) * 0.5f);
        CarAutomaticTransmissionManager::SetCursorPosY((toast_h - CarAutomaticTransmissionManager::GetTextLineHeight()) * 0.5f);
        CarAutomaticTransmissionManager::TextColored(badge_col, "%s", label);
    }
    CarAutomaticTransmissionManager::End();

    CarAutomaticTransmissionManager::PopStyleVar(3);
    CarAutomaticTransmissionManager::PopStyleColor(2);
}

static void RenderTransMenu(void)
{
    CarAutomaticTransmissionManager::SetNextWindowSize(ImVec2(640, 680), ImGuiCond_FirstUseEver);

    CarAutomaticTransmissionManager::SetNextWindowPos(ImVec2(25, 25), ImGuiCond_FirstUseEver);

    if (!CarAutomaticTransmissionManager::Begin("Car Automatic Transmission Manager###TransManagerWindow", &g_bShowMenu, ImGuiWindowFlags_NoCollapse)) {
        CarAutomaticTransmissionManager::End();
        return;
    }

    if (s_bListeningForKey) {
        CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.85f, 0.2f, 1.0f), ">> Press any key (or ESC) <<");
    } else {
        CarAutomaticTransmissionManager::TextDisabled("Press %s to open/close this menu", cfg.menu_key[0] ? cfg.menu_key : "F9");
    }
    CarAutomaticTransmissionManager::SameLine();
    CarAutomaticTransmissionManager::SetCursorPosX(CarAutomaticTransmissionManager::GetWindowWidth() - 250.0f);
    CarAutomaticTransmissionManager::Text("Menu Key:");
    CarAutomaticTransmissionManager::SameLine();

    if (s_bListeningForKey) {
        CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_Button, ImVec4(0.90f, 0.60f, 0.0f, 1.0f));
        CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.70f, 0.1f, 1.0f));
        CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
        if (CarAutomaticTransmissionManager::Button("Press Key...##hotkey_btn", ImVec2(90, 22))) {
            s_bListeningForKey = false;
        }
        CarAutomaticTransmissionManager::PopStyleColor(3);
        if (CarAutomaticTransmissionManager::IsItemHovered()) {
            CarAutomaticTransmissionManager::SetTooltip("Click to cancel key assignment");
        }

        CarAutomaticTransmissionManager::SameLine();
        if (CarAutomaticTransmissionManager::Button("Cancel##hotkey_cancel", ImVec2(55, 22))) {
            s_bListeningForKey = false;
        }
    } else {
        char btn_label[64];
        snprintf(btn_label, sizeof(btn_label), "[ %s ]##hotkey_btn", cfg.menu_key[0] ? cfg.menu_key : "F9");
        if (CarAutomaticTransmissionManager::Button(btn_label, ImVec2(90, 22))) {
            s_bListeningForKey = true;
            s_listenStartTick = GetTickCount();
        }
        if (CarAutomaticTransmissionManager::IsItemHovered()) {
            CarAutomaticTransmissionManager::SetTooltip("Click to change hotkey: then press any key on your keyboard");
        }
    }

    if (s_bListeningForModeKey) {
        CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.85f, 0.2f, 1.0f), ">> Press any key (or ESC) <<");
    } else {
        CarAutomaticTransmissionManager::TextDisabled("Press %s to cycle drive modes", cfg.mode_key[0] ? cfg.mode_key : "F8");
    }
    CarAutomaticTransmissionManager::SameLine();
    CarAutomaticTransmissionManager::SetCursorPosX(CarAutomaticTransmissionManager::GetWindowWidth() - 250.0f);
    CarAutomaticTransmissionManager::Text("Mode Key:");
    CarAutomaticTransmissionManager::SameLine();

    if (s_bListeningForModeKey) {
        CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_Button, ImVec4(0.90f, 0.60f, 0.0f, 1.0f));
        CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.70f, 0.1f, 1.0f));
        CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_Text, ImVec4(1.0f, 1.0f, 1.0f, 1.0f));
        if (CarAutomaticTransmissionManager::Button("Press Key...##mode_key_btn", ImVec2(90, 22))) {
            s_bListeningForModeKey = false;
        }
        CarAutomaticTransmissionManager::PopStyleColor(3);
        if (CarAutomaticTransmissionManager::IsItemHovered()) {
            CarAutomaticTransmissionManager::SetTooltip("Click to cancel key assignment");
        }

        CarAutomaticTransmissionManager::SameLine();
        if (CarAutomaticTransmissionManager::Button("Cancel##mode_key_cancel", ImVec2(55, 22))) {
            s_bListeningForModeKey = false;
        }
    } else {
        char btn_label[64];
        snprintf(btn_label, sizeof(btn_label), "[ %s ]##mode_key_btn", cfg.mode_key[0] ? cfg.mode_key : "F8");
        if (CarAutomaticTransmissionManager::Button(btn_label, ImVec2(90, 22))) {
            s_bListeningForModeKey = true;
            s_listenModeStartTick = GetTickCount();
        }
        if (CarAutomaticTransmissionManager::IsItemHovered()) {
            CarAutomaticTransmissionManager::SetTooltip("Click to change mode switch hotkey: then press any key on your keyboard");
        }
    }
    CarAutomaticTransmissionManager::Separator();

    CarAutomaticTransmissionManager::Spacing();
    CarAutomaticTransmissionManager::Text("Quick Presets:");
    int curMode = trans_get_current_mode_idx();

    if (curMode == 0) CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_Button, ImVec4(0.15f, 0.60f, 0.30f, 1.0f));
    if (CarAutomaticTransmissionManager::Button("Normal", ImVec2(100, 26))) {
        trans_switch_mode(0);
        trans_trigger_hud_notification("NORMAL", NULL, 0);
        snprintf(g_saveMsg, sizeof(g_saveMsg), "Mode 'Normal' activated!");
        g_saveMsgTime = GetTickCount();
    }
    if (curMode == 0) CarAutomaticTransmissionManager::PopStyleColor();
    CarAutomaticTransmissionManager::SameLine();

    if (curMode == 1) CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_Button, ImVec4(0.75f, 0.25f, 0.10f, 1.0f));
    if (CarAutomaticTransmissionManager::Button("Sport", ImVec2(100, 26))) {
        trans_switch_mode(1);
        trans_trigger_hud_notification("SPORT", NULL, 1);
        snprintf(g_saveMsg, sizeof(g_saveMsg), "Mode 'Sport' activated!");
        g_saveMsgTime = GetTickCount();
    }
    if (curMode == 1) CarAutomaticTransmissionManager::PopStyleColor();
    CarAutomaticTransmissionManager::SameLine();

    if (curMode == 2) CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_Button, ImVec4(0.20f, 0.45f, 0.80f, 1.0f));
    if (CarAutomaticTransmissionManager::Button("Comfort", ImVec2(100, 26))) {
        trans_switch_mode(2);
        trans_trigger_hud_notification("COMFORT", NULL, 2);
        snprintf(g_saveMsg, sizeof(g_saveMsg), "Mode 'Comfort' activated!");
        g_saveMsgTime = GetTickCount();
    }
    if (curMode == 2) CarAutomaticTransmissionManager::PopStyleColor();
    CarAutomaticTransmissionManager::SameLine();

    if (curMode == 3) CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_Button, ImVec4(0.40f, 0.40f, 0.45f, 1.0f));
    if (CarAutomaticTransmissionManager::Button("Stock (Truck)", ImVec2(110, 26))) {
        trans_switch_mode(3);
        trans_trigger_hud_notification("STOCK (TRUCK)", NULL, 3);
        snprintf(g_saveMsg, sizeof(g_saveMsg), "Mode 'Stock (Truck)' activated!");
        g_saveMsgTime = GetTickCount();
    }
    if (curMode == 3) CarAutomaticTransmissionManager::PopStyleColor();

    CarAutomaticTransmissionManager::Spacing();
    bool enabled_bool = (cfg.enabled != 0);
    if (CarAutomaticTransmissionManager::Checkbox("Automatic Transmission Tuning Enabled##master_enable", &enabled_bool)) {
        cfg.enabled = enabled_bool ? 1 : 0;
    }
    CarAutomaticTransmissionManager::Separator();

    if (CarAutomaticTransmissionManager::BeginTabBar("TransTabs", ImGuiTabBarFlags_FittingPolicyScroll)) {

        if (CarAutomaticTransmissionManager::BeginTabItem("Shift Map")) {
            CarAutomaticTransmissionManager::Spacing();

            CarAutomaticTransmissionManager::BeginDisabled(!cfg.enabled);

            CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.8f, 0.3f, 1.0f), "Main Control:");
            CarAutomaticTransmissionManager::SliderFloat("Minimum High RPM##min_rpm_hi", &cfg.min_rpm_hi, 0.40f, 0.95f, "%.2f");
            CarAutomaticTransmissionManager::TextDisabled("Default: 0.72 (72%% of rev limiter). At 7000 RPM, holds gears until at least 5040 RPM under full throttle.");

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.8f, 0.3f, 1.0f), "Throttle Thresholds & Response:");
            CarAutomaticTransmissionManager::SliderFloat("Pedal Low Threshold##thr_lo", &cfg.thr_lo, 0.00f, 0.80f, "%.2f");
            CarAutomaticTransmissionManager::TextDisabled("Default: 0.15 (15%% pedal). Below this position, shift points remain stock.");

            CarAutomaticTransmissionManager::SliderFloat("Pedal High Threshold##thr_hi", &cfg.thr_hi, 0.20f, 1.00f, "%.2f");
            CarAutomaticTransmissionManager::TextDisabled("Default: 0.85 (85%% pedal). Full kickdown is reached without having to press 100%%.");

            CarAutomaticTransmissionManager::SliderFloat("Throttle Curve Exponent##thr_curve", &cfg.thr_curve, 0.50f, 3.00f, "%.2f");
            CarAutomaticTransmissionManager::TextDisabled("Default: 1.60. Progression curve: >1.0 keeps RPM low during cruising, and ramps up aggressively when pedal is pressed deep.");

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.8f, 0.3f, 1.0f), "Safety & Peak Ceilings:");
            CarAutomaticTransmissionManager::SliderFloat("Shift Window Ceiling##thr_peak", &cfg.thr_peak, 0.60f, 1.00f, "%.2f");
            CarAutomaticTransmissionManager::TextDisabled("Default: 0.90 (90%% of rev limiter). Maximum shift RPM limit (prevents bouncing off rev limiter before shifting).");

            CarAutomaticTransmissionManager::SliderFloat("Window Shift Gain Limit##thr_gain", &cfg.thr_gain, 0.00f, 6.00f, "%.2fx");
            CarAutomaticTransmissionManager::TextDisabled("Default: 3.00x. Multiplier limit on how much shift points may be expanded above stock.");

            CarAutomaticTransmissionManager::EndDisabled();
            CarAutomaticTransmissionManager::EndTabItem();
        }

        if (CarAutomaticTransmissionManager::BeginTabItem("Gear Steps")) {
            CarAutomaticTransmissionManager::Spacing();

            CarAutomaticTransmissionManager::BeginDisabled(!cfg.enabled);

            CarAutomaticTransmissionManager::SliderInt("Gears per Upshift##up_step", &cfg.up_step, 0, 4);
            if (cfg.up_step == 1) {
                CarAutomaticTransmissionManager::TextDisabled("1 = Strictly sequential.");
            } else if (cfg.up_step == 0) {
                CarAutomaticTransmissionManager::TextDisabled("0 = Unlimited (Stock truck behavior).");
            } else {
                CarAutomaticTransmissionManager::TextDisabled("Up to %d gears per upshift.", cfg.up_step);
            }

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::SliderInt("Gears per Downshift##down_step", &cfg.down_step, 0, 4);
            CarAutomaticTransmissionManager::TextDisabled("Default: 2. Allows skipping up to 2 gears during normal braking/deceleration.");

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::SliderInt("Gears on Kickdown##kick_step", &cfg.kick_step, 0, 6);
            if (cfg.kick_step == 0) {
                CarAutomaticTransmissionManager::TextDisabled("0 = Unlimited.");
            } else {
                CarAutomaticTransmissionManager::TextDisabled("Drop up to %d gears on kickdown.", cfg.kick_step);
            }

            CarAutomaticTransmissionManager::EndDisabled();
            CarAutomaticTransmissionManager::EndTabItem();
        }

        if (CarAutomaticTransmissionManager::BeginTabItem("Shift Timing & Delays")) {
            CarAutomaticTransmissionManager::Spacing();

            CarAutomaticTransmissionManager::BeginDisabled(!cfg.enabled);

            CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.8f, 0.3f, 1.0f), "Dynamic Gear Hold (Fast-Off / Hang-On):");
            CarAutomaticTransmissionManager::SliderFloat("Fast-Off Gear Hold##fast_off", &cfg.fast_off_hold, 0.00f, 5.00f, "%.1f seconds");
            if (cfg.fast_off_hold > 0.0f) {
                if (g_trans_telem.fast_off_active) {
                    CarAutomaticTransmissionManager::TextColored(ImVec4(0.2f, 1.0f, 0.4f, 1.0f), ">> Gear Hold Active (%.1fs remaining) <<", g_trans_telem.fast_off_remaining);
                } else {
                    CarAutomaticTransmissionManager::TextDisabled("Holds gear when throttle is released rapidly (engine braking & cornering). 0 = off.");
                }
            } else {
                CarAutomaticTransmissionManager::TextDisabled("Disabled (gearbox upshifts immediately upon throttle release).");
            }

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::Separator();
            CarAutomaticTransmissionManager::Spacing();

            CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.8f, 0.3f, 1.0f), "Coasting Gear Hold:");
            bool coast_en = cfg.coast_hold != 0;
            if (CarAutomaticTransmissionManager::Checkbox("Hold Gear while Coasting##coast_hold", &coast_en)) {
                cfg.coast_hold = coast_en ? 1 : 0;
            }
            if (cfg.coast_hold) {
                float thr_pct = cfg.coast_thr * 100.0f;
                if (CarAutomaticTransmissionManager::SliderFloat("Coasting Throttle Threshold##coast_thr", &thr_pct, 1.0f, 15.0f, "%.0f %%")) {
                    cfg.coast_thr = thr_pct / 100.0f;
                }
                CarAutomaticTransmissionManager::TextDisabled("Default: 6%%. Throttle position considered coasting (foot off the pedal).");
                CarAutomaticTransmissionManager::SliderFloat("Coast Timeout##coast_to", &cfg.coast_timeout, 0.00f, 15.00f,
                                   cfg.coast_timeout <= 0.0f ? "0 (Hold indefinitely)" : "%.1f seconds");
                CarAutomaticTransmissionManager::TextDisabled("Default: 6.0s. Duration to hold gear on level roads before stepping into overdrive.");
                CarAutomaticTransmissionManager::SliderFloat("Tip-In Cruise Delay##tip_in", &cfg.tip_in_delay, 0.00f, 1.50f, "%.2f seconds");
                CarAutomaticTransmissionManager::TextDisabled("Default: 0.45s. Prevents sudden upshift when gently stepping back on throttle after coasting.");
                if (g_trans_telem.coast_downhill) {
                    CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.85f, 0.2f, 1.0f),
                                       ">> Downhill Detected: Holding %s for Engine Braking <<",
                                       g_trans_telem.gear_str[0] ? g_trans_telem.gear_str : "gear");
                } else if (g_trans_telem.coast_active) {
                    if (cfg.coast_timeout > 0.0f) {
                        CarAutomaticTransmissionManager::TextColored(ImVec4(0.2f, 1.0f, 0.4f, 1.0f),
                                           ">> Coast Hold Active (Holding %s, %.1fs remaining) <<",
                                           g_trans_telem.gear_str[0] ? g_trans_telem.gear_str : "gear",
                                           g_trans_telem.coast_remaining);
                    } else {
                        CarAutomaticTransmissionManager::TextColored(ImVec4(0.2f, 1.0f, 0.4f, 1.0f),
                                           ">> Coast Hold Active (Holding %s indefinitely) <<",
                                           g_trans_telem.gear_str[0] ? g_trans_telem.gear_str : "gear");
                    }
                } else if (g_trans_telem.tip_in_active) {
                    CarAutomaticTransmissionManager::TextColored(ImVec4(0.3f, 0.9f, 1.0f, 1.0f),
                                       ">> Tip-In Debounce (%.2fs remaining before Overdrive) <<",
                                       g_trans_telem.tip_in_remaining);
                } else {
                    CarAutomaticTransmissionManager::TextDisabled("Prevents upshifting to overdrive during coasting.");
                }
            } else {
                CarAutomaticTransmissionManager::TextDisabled("Disabled (gearbox upshifts to top gear even with 0% throttle).");
            }

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::Separator();
            CarAutomaticTransmissionManager::Spacing();

            CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.8f, 0.3f, 1.0f), "Shift Delays:");
            CarAutomaticTransmissionManager::SliderFloat("Inter-Shift Delay##inter_delay", &cfg.inter_shift_delay, 0.00f, 2.00f, "%.2f seconds");
            CarAutomaticTransmissionManager::TextDisabled("Default: 0.80s. Pause between shifts (prevents rapid hunting 5->3->4->2).");

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::SliderFloat("Upshift Delay##up_delay", &cfg.up_delay, 0.00f, 10.00f, "%.2f seconds");

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::SliderFloat("Downshift Delay##dn_delay", &cfg.dn_delay, 0.00f, 5.00f, "%.2f seconds");
            CarAutomaticTransmissionManager::TextDisabled("Default: 0.00s. Minimum pause before another downshift or upshift.");

            CarAutomaticTransmissionManager::EndDisabled();
            CarAutomaticTransmissionManager::EndTabItem();
        }

        if (CarAutomaticTransmissionManager::BeginTabItem("Flywheel")) {
            CarAutomaticTransmissionManager::Spacing();

            CarAutomaticTransmissionManager::BeginDisabled(!cfg.enabled);

            CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.8f, 0.3f, 1.0f), "Flywheel Inertia & Mass:");
            CarAutomaticTransmissionManager::SliderFloat("Flywheel Inertia##flywheel_inertia", &cfg.flywheel_inertia, 0.05f, 0.50f, "%.2f kg*m²");
            CarAutomaticTransmissionManager::TextDisabled("Default: Sport=0.10, Normal=0.18, Comfort=0.25. Lower value = faster revving like a single-mass lightweight racing flywheel.");

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.8f, 0.3f, 1.0f), "Throttle & Rev Dynamics:");
            CarAutomaticTransmissionManager::SliderFloat("Rev Response Multiplier##flywheel_response", &cfg.flywheel_response, 0.50f, 4.00f, "%.2fx");
            CarAutomaticTransmissionManager::TextDisabled("Default: Sport=2.40x, Normal=1.50x, Comfort=1.00x. Intake manifold filling & ECU rev response. Higher = more throttle response.");

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::SliderFloat("Rev-Drop Rate##flywheel_drop_rate", &cfg.flywheel_drop_rate, 0.50f, 3.00f, "%.2fx");
            CarAutomaticTransmissionManager::TextDisabled("Default: Sport=1.60x, Normal=1.20x, Comfort=0.90x. Engine drag, friction, pumping losses, fuel cut. Higher = faster rev drop.");

            CarAutomaticTransmissionManager::EndDisabled();

            CarAutomaticTransmissionManager::EndTabItem();
        }

        if (CarAutomaticTransmissionManager::BeginTabItem("Live Telemetry")) {
            CarAutomaticTransmissionManager::Spacing();

            CarAutomaticTransmissionManager::Columns(2, "telem_cols", false);

            if (g_trans_telem.forward_gear_count > 0) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(0.3f, 0.9f, 1.0f, 1.0f), "Active Gear:        %s (Total: %d)",
                                   g_trans_telem.gear_str[0] ? g_trans_telem.gear_str : "N",
                                   g_trans_telem.forward_gear_count);
            } else {
                CarAutomaticTransmissionManager::TextColored(ImVec4(0.3f, 0.9f, 1.0f, 1.0f), "Active Gear:        %s",
                                   g_trans_telem.gear_str[0] ? g_trans_telem.gear_str : "N");
            }
            CarAutomaticTransmissionManager::Text("Vehicle Speed:      %.1f km/h", g_trans_telem.speed_kmh);
            ImVec4 accel_col = ImVec4(0.85f, 0.85f, 0.85f, 1.0f);
            if (g_trans_telem.accel_mps2 > 0.5f) accel_col = ImVec4(0.3f, 1.0f, 0.4f, 1.0f);
            else if (g_trans_telem.accel_mps2 < -0.5f) accel_col = ImVec4(1.0f, 0.4f, 0.3f, 1.0f);
            CarAutomaticTransmissionManager::TextColored(accel_col, "Acceleration:       %+.2f m/s² (%+.2fg)",
                               g_trans_telem.accel_mps2, g_trans_telem.accel_g);

            if (g_trans_telem.idle_rpm > 0.0f) {
                CarAutomaticTransmissionManager::Text("Engine RPM:         %.0f (Idle: %.0f)", g_trans_telem.engine_rpm, g_trans_telem.idle_rpm);
            } else {
                CarAutomaticTransmissionManager::Text("Engine RPM:         %.0f RPM", g_trans_telem.engine_rpm);
            }
            CarAutomaticTransmissionManager::Text("RPM Gradient:       %+.1f RPM/s", g_trans_telem.rpm_grad);
            CarAutomaticTransmissionManager::Text("Rev Limiter:        %.0f RPM", g_trans_telem.rpm_limit);

            float steer_pct = g_trans_telem.steering * 100.0f;
            const char *steer_side = (steer_pct > 1.0f) ? "Right" : (steer_pct < -1.0f ? "Left" : "Center");
            CarAutomaticTransmissionManager::Text("Steering Angle:     %+.1f%% (%s)", steer_pct, steer_side);
            if (g_trans_telem.inter_shift_locked) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.4f, 0.2f, 1.0f), "Shift Dwell Lock:   LOCKED (%.2fs)", g_trans_telem.inter_shift_remaining);
            } else {
                CarAutomaticTransmissionManager::Text("Time Since Shift:   %.1f s", g_trans_telem.time_since_shift);
            }

            CarAutomaticTransmissionManager::NextColumn();

            CarAutomaticTransmissionManager::Text("Downshift Below:    %.0f RPM", g_trans_telem.win_min_rpm);
            CarAutomaticTransmissionManager::Text("Upshift Above:      %.0f RPM", g_trans_telem.win_max_rpm);
            CarAutomaticTransmissionManager::Text("Stock Shift Window: %.0f - %.0f", g_trans_telem.win_min_orig, g_trans_telem.win_max_orig);
            CarAutomaticTransmissionManager::Text("Throttle Gradient:  %+.2f /s", g_trans_telem.thr_grad);

            if (g_trans_telem.cruise_control_kmh > 0.5f) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(0.2f, 1.0f, 0.4f, 1.0f), "Cruise Control:     %.0f km/h", g_trans_telem.cruise_control_kmh);
            } else {
                CarAutomaticTransmissionManager::TextDisabled("Cruise Control:     OFF");
            }

            if (g_trans_telem.bos_active) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.4f, 0.2f, 1.0f), "Brake Override:     ACTIVE (Smart Pedal Cut)");
            } else if (g_trans_telem.brake > 0.05f) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.3f, 0.3f, 1.0f), "Footbrake Lock:     UPSHIFTS LOCKED (%.0f%%)", g_trans_telem.brake * 100.0f);
            } else if (g_trans_telem.parking_brake) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.35f, 0.35f, 1.0f), "Parking Brake:      ENGAGED");
            } else {
                CarAutomaticTransmissionManager::Text("Parking Brake:      Released");
            }

            if (g_trans_telem.fast_off_active) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(0.2f, 1.0f, 0.4f, 1.0f), "Fast-Off Hold:      ACTIVE (%.1fs)", g_trans_telem.fast_off_remaining);
            } else {
                CarAutomaticTransmissionManager::TextDisabled("Fast-Off Hold:      Inactive");
            }
            if (g_trans_telem.coast_downhill) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.85f, 0.2f, 1.0f), "Coasting Hold:      DOWNHILL (Engine Braking)");
            } else if (g_trans_telem.coast_active) {
                if (cfg.coast_timeout > 0.0f) {
                    CarAutomaticTransmissionManager::TextColored(ImVec4(0.2f, 1.0f, 0.4f, 1.0f), "Coasting Hold:      ACTIVE (%.1fs timeout)", g_trans_telem.coast_remaining);
                } else {
                    CarAutomaticTransmissionManager::TextColored(ImVec4(0.2f, 1.0f, 0.4f, 1.0f), "Coasting Hold:      ACTIVE (Indefinite)");
                }
            } else if (g_trans_telem.tip_in_active) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(0.3f, 0.9f, 1.0f, 1.0f), "Tip-In Debounce:    ACTIVE (%.2fs)", g_trans_telem.tip_in_remaining);
            } else {
                CarAutomaticTransmissionManager::TextDisabled("Coasting Hold:      Inactive");
            }

            CarAutomaticTransmissionManager::Columns(1);

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::Text("Throttle Position:");
            CarAutomaticTransmissionManager::ProgressBar(g_trans_telem.throttle, ImVec2(-1, 16));

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::Text("Brake Position:");
            CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_PlotHistogram, ImVec4(1.0f, 0.3f, 0.3f, 1.0f));
            CarAutomaticTransmissionManager::ProgressBar(g_trans_telem.brake, ImVec2(-1, 16));
            CarAutomaticTransmissionManager::PopStyleColor();

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::Text("Shift Map Influence:");
            ImVec4 ramp_col = ImVec4(0.2f, 0.7f, 1.0f, 1.0f);
            if (g_trans_telem.pedal_ramp > 0.70f) ramp_col = ImVec4(1.0f, 0.4f, 0.2f, 1.0f);
            CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_PlotHistogram, ramp_col);
            CarAutomaticTransmissionManager::ProgressBar(g_trans_telem.pedal_ramp, ImVec2(-1, 16));
            CarAutomaticTransmissionManager::PopStyleColor();

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::Separator();
            CarAutomaticTransmissionManager::Spacing();

            CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.75f, 0.2f, 1.0f), "DSG / Dual-Clutch:");
            CarAutomaticTransmissionManager::Columns(2, "dsg_cols", false);
            CarAutomaticTransmissionManager::Text("DSG Phase:          %s", g_trans_telem.dsg_phase_str[0] ? g_trans_telem.dsg_phase_str : "STEADY");
            CarAutomaticTransmissionManager::Text("Active Clutch:      Clutch %d (%s)", g_trans_telem.dsg_active_clutch,
                        (g_trans_telem.dsg_active_clutch == 1) ? "Odd Gears 1,3,5,7" : "Even Gears 2,4,6,R");
            if (g_trans_telem.dsg_preselected_gear > 0) {
                CarAutomaticTransmissionManager::Text("Preselected Gear:   D%d (Pre-Synced)", g_trans_telem.dsg_preselected_gear);
            } else if (g_trans_telem.dsg_preselected_gear < 0) {
                CarAutomaticTransmissionManager::Text("Preselected Gear:   R%d (Reverse)", -g_trans_telem.dsg_preselected_gear);
            } else {
                CarAutomaticTransmissionManager::Text("Preselected Gear:   Neutral");
            }
            if (g_trans_telem.dsg_is_skip_shift) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.4f, 0.2f, 1.0f), "Skip-Shift Mode:    ACTIVE (Stepping 2-Stage)");
            } else {
                CarAutomaticTransmissionManager::TextDisabled("Skip-Shift Mode:    Direct Handoff");
            }

            CarAutomaticTransmissionManager::NextColumn();

            CarAutomaticTransmissionManager::Text("Propshaft Torque:   %.0f Nm", g_trans_telem.dsg_propshaft_torque);
            CarAutomaticTransmissionManager::Text("Wheel Torque:       %.0f Nm (Diff: %.2f:1)", g_trans_telem.dsg_wheel_torque, g_trans_telem.dsg_diff_ratio);
            if (g_trans_telem.dsg_ignition_cut) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(1.0f, 0.3f, 0.1f, 1.0f), "Ignition Cut:       ACTIVE (-85%% Torque Crater)");
            } else if (g_trans_telem.dsg_inertia_kick_nm > 1.0f) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(0.2f, 1.0f, 0.4f, 1.0f), "Inertia Kick:       +%.0f Nm (Forward Punch)", g_trans_telem.dsg_inertia_kick_nm);
            } else if (g_trans_telem.dsg_active_blip_nm > 1.0f) {
                CarAutomaticTransmissionManager::TextColored(ImVec4(0.3f, 0.9f, 1.0f, 1.0f), "Rev-Match Blip:     +%.0f Nm (Throttle Blip)", g_trans_telem.dsg_active_blip_nm);
            } else {
                CarAutomaticTransmissionManager::TextDisabled("Inertia / Blip:     None (Steady Drive)");
            }
            CarAutomaticTransmissionManager::Text("K1 Torque:          %.0f Nm", g_trans_telem.dsg_k1_torque);
            CarAutomaticTransmissionManager::Text("K2 Torque:          %.0f Nm", g_trans_telem.dsg_k2_torque);

            CarAutomaticTransmissionManager::Columns(1);

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::Text("Clutch 1 (Odd: 1, 3, 5, 7): %.0f%% (Pressure)", g_trans_telem.dsg_k1_pressure * 100.0f);
            CarAutomaticTransmissionManager::ProgressBar(g_trans_telem.dsg_k1_pressure, ImVec2(-1, 14));

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::Text("Clutch 2 (Even: 2, 4, 6, R): %.0f%% (Pressure)", g_trans_telem.dsg_k2_pressure * 100.0f);
            CarAutomaticTransmissionManager::ProgressBar(g_trans_telem.dsg_k2_pressure, ImVec2(-1, 14));

            CarAutomaticTransmissionManager::Spacing();
            CarAutomaticTransmissionManager::Separator();
            CarAutomaticTransmissionManager::Spacing();

            CarAutomaticTransmissionManager::TextColored(ImVec4(0.3f, 0.8f, 1.0f, 1.0f), "System & Hook Status:");
            CarAutomaticTransmissionManager::BulletText("Patched Call Sites: %d (Window sites: %d)",
                              g_trans_telem.patches_applied, g_trans_telem.window_sites);
            if (g_trans_telem.status_line[0]) {
                CarAutomaticTransmissionManager::BulletText("Status: %s", g_trans_telem.status_line);
            }

            CarAutomaticTransmissionManager::EndTabItem();
        }

        CarAutomaticTransmissionManager::EndTabBar();
    }

    CarAutomaticTransmissionManager::Spacing();
    CarAutomaticTransmissionManager::Separator();
    CarAutomaticTransmissionManager::Spacing();

    CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_Button, ImVec4(0.16f, 0.55f, 0.30f, 1.0f));
    CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.22f, 0.70f, 0.38f, 1.0f));
    CarAutomaticTransmissionManager::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.12f, 0.45f, 0.22f, 1.0f));
    if (CarAutomaticTransmissionManager::Button("Save to Config", ImVec2(150, 30))) {
        trans_save_config();
        snprintf(g_saveMsg, sizeof(g_saveMsg), "Successfully saved to config file!");
        g_saveMsgTime = GetTickCount();
    }
    CarAutomaticTransmissionManager::PopStyleColor(3);

    CarAutomaticTransmissionManager::SameLine();
    if (CarAutomaticTransmissionManager::Button("Reload Config", ImVec2(140, 30))) {
        trans_reload_config();
        snprintf(g_saveMsg, sizeof(g_saveMsg), "Config reloaded!");
        g_saveMsgTime = GetTickCount();
    }

    CarAutomaticTransmissionManager::SameLine();
    if (CarAutomaticTransmissionManager::Button("Reset Defaults", ImVec2(130, 30))) {
        trans_reset_defaults();
        snprintf(g_saveMsg, sizeof(g_saveMsg), "Defaults restored!");
        g_saveMsgTime = GetTickCount();
    }

    CarAutomaticTransmissionManager::SameLine();
    if (CarAutomaticTransmissionManager::Button("Close", ImVec2(80, 30))) {
        g_bShowMenu = false;
    }

    if (g_saveMsg[0] && (GetTickCount() - g_saveMsgTime < 4000)) {
        CarAutomaticTransmissionManager::Spacing();
        CarAutomaticTransmissionManager::TextColored(ImVec4(0.2f, 1.0f, 0.3f, 1.0f), "%s", g_saveMsg);
    }

    CarAutomaticTransmissionManager::End();
}

static HRESULT STDMETHODCALLTYPE HookedPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
    static int s_presentFrames = 0;
    if (s_presentFrames < 3) {
        trans_log("HookedPresent: frame %d, pSwapChain=%p, g_bInitialized=%d", s_presentFrames, pSwapChain, g_bInitialized);
        s_presentFrames++;
    }

    if (!g_bInitialized && pSwapChain) {
        if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&g_pd3dDevice))) {
            g_pd3dDevice->GetImmediateContext(&g_pd3dContext);
            DXGI_SWAP_CHAIN_DESC desc;
            pSwapChain->GetDesc(&desc);
            g_hGameWindow = desc.OutputWindow;
            trans_log("HookedPresent: initializing ImGui for window %p", g_hGameWindow);

            ID3D11Texture2D* pBackBuffer = NULL;
            if (SUCCEEDED(pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer))) {
                g_pd3dDevice->CreateRenderTargetView(pBackBuffer, NULL, &g_mainRenderTargetView);
                pBackBuffer->Release();
            }

            IMGUI_CHECKVERSION();
            CarAutomaticTransmissionManager::CreateContext();
            ImGuiIO& io = CarAutomaticTransmissionManager::GetIO();
            io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
            io.IniFilename = "car_automatic_transmission_manager.ini";

            CarAutomaticTransmissionManager::StyleColorsDark();
            ImGuiStyle& style = CarAutomaticTransmissionManager::GetStyle();
            style.WindowRounding = 6.0f;
            style.FrameRounding = 4.0f;
            style.GrabRounding = 3.0f;
            style.WindowBorderSize = 1.0f;
            style.Colors[ImGuiCol_WindowBg]       = ImVec4(0.08f, 0.09f, 0.11f, 0.94f);
            style.Colors[ImGuiCol_TitleBgActive]  = ImVec4(0.15f, 0.35f, 0.55f, 1.00f);
            style.Colors[ImGuiCol_Button]         = ImVec4(0.18f, 0.42f, 0.65f, 0.85f);
            style.Colors[ImGuiCol_ButtonHovered]  = ImVec4(0.25f, 0.55f, 0.82f, 1.00f);
            style.Colors[ImGuiCol_SliderGrab]     = ImVec4(0.30f, 0.65f, 0.95f, 1.00f);
            style.Colors[ImGuiCol_Header]         = ImVec4(0.18f, 0.38f, 0.60f, 0.80f);
            style.Colors[ImGuiCol_PlotLines]      = ImVec4(0.35f, 0.75f, 1.00f, 1.00f);

            CarAutomaticTransmissionManager_ImplWin32_Init(g_hGameWindow);
            CarAutomaticTransmissionManager_ImplDX11_Init(g_pd3dDevice, g_pd3dContext);

            g_oWndProc = (WNDPROC)SetWindowLongPtrA(g_hGameWindow, GWLP_WNDPROC, (LONG_PTR)HookedWndProc);
            trans_log("HookedPresent: WndProc hooked (old=%p, new=%p)", g_oWndProc, HookedWndProc);

            g_bInitialized = true;
        }
    }

    if (g_bInitialized && cfg.menu_vk > 0 && !s_bListeningForKey && s_justBoundVk == 0) {
        static bool s_wasKeyDown = false;
        static int s_lastCheckedVk = 0;

        if (cfg.menu_vk != s_lastCheckedVk) {
            s_lastCheckedVk = cfg.menu_vk;
            s_wasKeyDown = (GetAsyncKeyState(cfg.menu_vk) & 0x8000) != 0;
        }

        bool isKeyDown = (GetAsyncKeyState(cfg.menu_vk) & 0x8000) != 0;

        if (isKeyDown && !s_wasKeyDown) {
            ToggleMenu();
        }
        s_wasKeyDown = isKeyDown;
    }

    if (g_bInitialized && cfg.mode_vk > 0 && !s_bListeningForModeKey && s_justBoundModeVk == 0) {
        static bool s_wasModeKeyDown = false;
        static int s_lastCheckedModeVk = 0;

        if (cfg.mode_vk != s_lastCheckedModeVk) {
            s_lastCheckedModeVk = cfg.mode_vk;
            s_wasModeKeyDown = (GetAsyncKeyState(cfg.mode_vk) & 0x8000) != 0;
        }

        bool isModeKeyDown = (GetAsyncKeyState(cfg.mode_vk) & 0x8000) != 0;
        if (isModeKeyDown && !s_wasModeKeyDown) {
            DWORD now = GetTickCount();
            if (now - s_lastModeToggleTick >= 250) {
                s_lastModeToggleTick = now;
                trans_cycle_mode();
            }
        }
        s_wasModeKeyDown = isModeKeyDown;
    }

    bool hudActive = (s_hudNotifyTick != 0 && (GetTickCount() - s_hudNotifyTick < 2600));

    if (g_bInitialized && g_mainRenderTargetView) {
        if (g_bShowMenu || hudActive) {
            CarAutomaticTransmissionManager_ImplDX11_NewFrame();
            CarAutomaticTransmissionManager_ImplWin32_NewFrame();

            DXGI_SWAP_CHAIN_DESC sd_now;
            if (SUCCEEDED(pSwapChain->GetDesc(&sd_now))) {
                extern ImVec2 g_ImplWin32MouseScale;
                ImGuiIO& io_fb = CarAutomaticTransmissionManager::GetIO();
                if (io_fb.DisplaySize.x > 0.0f && io_fb.DisplaySize.y > 0.0f &&
                    sd_now.BufferDesc.Width > 0 && sd_now.BufferDesc.Height > 0) {
                    ImVec2 scale((float)sd_now.BufferDesc.Width / io_fb.DisplaySize.x,
                                 (float)sd_now.BufferDesc.Height / io_fb.DisplaySize.y);
                    if (scale.x != g_ImplWin32MouseScale.x || scale.y != g_ImplWin32MouseScale.y) {
                        trans_log("Overlay: window %.0fx%.0f, backbuffer %ux%u -> mouse scale %.3fx%.3f",
                                  io_fb.DisplaySize.x, io_fb.DisplaySize.y,
                                  sd_now.BufferDesc.Width, sd_now.BufferDesc.Height, scale.x, scale.y);
                    }
                    g_ImplWin32MouseScale = scale;
                    io_fb.DisplaySize = ImVec2((float)sd_now.BufferDesc.Width, (float)sd_now.BufferDesc.Height);
                    io_fb.DisplayFramebufferScale = ImVec2(1.0f, 1.0f);
                }
            }

            CarAutomaticTransmissionManager::NewFrame();

            if (g_bShowMenu) {
                CarAutomaticTransmissionManager::GetIO().MouseDrawCursor = true;
                RenderTransMenu();
            } else {
                CarAutomaticTransmissionManager::GetIO().MouseDrawCursor = false;
            }

            if (hudActive) {
                RenderHudToast();
            }

            CarAutomaticTransmissionManager::Render();
            g_pd3dContext->OMSetRenderTargets(1, &g_mainRenderTargetView, NULL);
            CarAutomaticTransmissionManager_ImplDX11_RenderDrawData(CarAutomaticTransmissionManager::GetDrawData());
        } else {
            CarAutomaticTransmissionManager::GetIO().MouseDrawCursor = false;
        }
    }

    return oPresent(pSwapChain, SyncInterval, Flags);
}

static HRESULT STDMETHODCALLTYPE HookedResizeBuffers(IDXGISwapChain* pSwapChain, UINT BufferCount, UINT Width, UINT Height, DXGI_FORMAT NewFormat, UINT SwapChainFlags)
{
    if (g_mainRenderTargetView) {
        g_pd3dContext->OMSetRenderTargets(0, 0, 0);
        g_mainRenderTargetView->Release();
        g_mainRenderTargetView = NULL;
    }

    HRESULT hr = oResizeBuffers(pSwapChain, BufferCount, Width, Height, NewFormat, SwapChainFlags);

    ID3D11Texture2D* pBackBuffer = NULL;
    if (SUCCEEDED(pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer))) {
        g_pd3dDevice->CreateRenderTargetView(pBackBuffer, NULL, &g_mainRenderTargetView);
        pBackBuffer->Release();
    }

    return hr;
}

static bool GetD3D11Targets(void)
{
    WNDCLASSEXA wc = { sizeof(WNDCLASSEXA), CS_CLASSDC, DefWindowProcA, 0L, 0L, GetModuleHandleA(NULL), NULL, NULL, NULL, NULL, "TransDX11Hook", NULL };
    RegisterClassExA(&wc);
    HWND hWnd = CreateWindowA("TransDX11Hook", "", WS_OVERLAPPEDWINDOW, 0, 0, 100, 100, NULL, NULL, wc.hInstance, NULL);
    if (!hWnd) return false;

    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevels[] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };

    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 1;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.BufferDesc.ScanlineOrdering = DXGI_MODE_SCANLINE_ORDER_UNSPECIFIED;
    sd.BufferDesc.Scaling = DXGI_MODE_SCALING_UNSPECIFIED;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    IDXGISwapChain* dummySwapChain = NULL;
    ID3D11Device* dummyDevice = NULL;
    ID3D11DeviceContext* dummyContext = NULL;

    HRESULT hr = D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_HARDWARE, NULL, 0, featureLevels, 2,
        D3D11_SDK_VERSION, &sd, &dummySwapChain, &dummyDevice, &featureLevel, &dummyContext);

    if (FAILED(hr)) {
        hr = D3D11CreateDeviceAndSwapChain(NULL, D3D_DRIVER_TYPE_WARP, NULL, 0, featureLevels, 2,
            D3D11_SDK_VERSION, &sd, &dummySwapChain, &dummyDevice, &featureLevel, &dummyContext);
    }

    if (SUCCEEDED(hr) && dummySwapChain) {
        void** pVMT = *(void***)dummySwapChain;
        g_pPresentTarget = pVMT[8];
        g_pResizeBuffersTarget = pVMT[13];
        dummySwapChain->Release();
        if (dummyDevice) dummyDevice->Release();
        if (dummyContext) dummyContext->Release();
    }

    DestroyWindow(hWnd);
    UnregisterClassA("TransDX11Hook", wc.hInstance);
    return (g_pPresentTarget != NULL);
}

static bool GetDInputTargets(void)
{
    HMODULE hDInput = LoadLibraryA("dinput8.dll");
    if (!hDInput) return false;

    typedef HRESULT (WINAPI *DICreate_t)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);
    DICreate_t pCreate = (DICreate_t)GetProcAddress(hDInput, "DirectInput8Create");
    if (!pCreate) return false;

    IDirectInput8A *pDI = NULL;
    HRESULT hr = pCreate(GetModuleHandleA(NULL), 0x0800, IID_IDirectInput8A, (void**)&pDI, NULL);
    if (FAILED(hr) || !pDI) return false;

    IDirectInputDevice8A *pMouse = NULL;
    hr = pDI->CreateDevice(GUID_SysMouse, &pMouse, NULL);
    if (SUCCEEDED(hr) && pMouse) {
        void **vtable = *(void***)pMouse;
        g_pGetDeviceStateTarget = vtable[9];
        g_pGetDeviceDataTarget = vtable[10];
        pMouse->Release();
    }
    pDI->Release();
    return (g_pGetDeviceStateTarget != NULL);
}

static DWORD WINAPI OverlayInitThread(LPVOID lpParam)
{
    (void)lpParam;
    trans_log("OverlayInitThread: started, waiting for dxgi.dll & d3d11.dll...");
    while (!GetModuleHandleA("dxgi.dll") || !GetModuleHandleA("d3d11.dll")) {
        Sleep(100);
    }
    Sleep(800);

    bool d3d_ok = GetD3D11Targets();
    trans_log("OverlayInitThread: GetD3D11Targets=%d (PresentTarget=%p, ResizeTarget=%p)", d3d_ok, g_pPresentTarget, g_pResizeBuffersTarget);
    if (!d3d_ok) return 1;

    bool di_ok = GetDInputTargets();
    trans_log("OverlayInitThread: GetDInputTargets=%d", di_ok);

    MH_STATUS s_mh = MH_Initialize();
    trans_log("OverlayInitThread: MH_Initialize=%d", (int)s_mh);
    if (s_mh != MH_OK && s_mh != MH_ERROR_ALREADY_INITIALIZED) return 2;

    MH_STATUS mh_p = MH_CreateHook(g_pPresentTarget, (LPVOID)&HookedPresent, (LPVOID*)&oPresent);
    trans_log("OverlayInitThread: MH_CreateHook(Present)=%d", (int)mh_p);
    if (mh_p != MH_OK && mh_p != MH_ERROR_ALREADY_CREATED) {
        return 3;
    }

    MH_STATUS mh_r = MH_CreateHook(g_pResizeBuffersTarget, (LPVOID)&HookedResizeBuffers, (LPVOID*)&oResizeBuffers);
    trans_log("OverlayInitThread: MH_CreateHook(ResizeBuffers)=%d", (int)mh_r);

    MH_CreateHook((LPVOID)&SetCursorPos, (LPVOID)&HookedSetCursorPos, (LPVOID*)&oSetCursorPos);
    MH_CreateHook((LPVOID)&GetCursorPos, (LPVOID)&HookedGetCursorPos, (LPVOID*)&oGetCursorPos);
    MH_CreateHook((LPVOID)&GetCursorInfo, (LPVOID)&HookedGetCursorInfo, (LPVOID*)&oGetCursorInfo);
    MH_CreateHook((LPVOID)&ClipCursor, (LPVOID)&HookedClipCursor, (LPVOID*)&oClipCursor);

    if (g_pGetDeviceStateTarget) {
        MH_CreateHook(g_pGetDeviceStateTarget, (LPVOID)&HookedGetDeviceState, (LPVOID*)&oGetDeviceState);
    }
    if (g_pGetDeviceDataTarget) {
        MH_CreateHook(g_pGetDeviceDataTarget, (LPVOID)&HookedGetDeviceData, (LPVOID*)&oGetDeviceData);
    }

    MH_STATUS ep = MH_EnableHook(g_pPresentTarget);
    MH_STATUS er = MH_EnableHook(g_pResizeBuffersTarget);
    trans_log("OverlayInitThread: MH_EnableHook(Present)=%d, Resize=%d", (int)ep, (int)er);

    MH_STATUS s_all = MH_EnableHook(MH_ALL_HOOKS);
    trans_log("OverlayInitThread: MH_EnableHook(MH_ALL_HOOKS)=%d", (int)s_all);

    return 0;
}

extern "C" void trans_overlay_init(void)
{
    trans_log("trans_overlay_init called");
    HANDLE hThread = CreateThread(NULL, 0, OverlayInitThread, NULL, 0, NULL);
    if (hThread) CloseHandle(hThread);
    else trans_log("trans_overlay_init: FAILED to create thread, err=%lu", GetLastError());
}

extern "C" void trans_overlay_shutdown(void)
{
    if (g_bInitialized) {
        if (g_oWndProc && g_hGameWindow) {
            SetWindowLongPtrA(g_hGameWindow, GWLP_WNDPROC, (LONG_PTR)g_oWndProc);
            g_oWndProc = NULL;
        }
        MH_DisableHook(MH_ALL_HOOKS);
        MH_Uninitialize();
        CarAutomaticTransmissionManager_ImplDX11_Shutdown();
        CarAutomaticTransmissionManager_ImplWin32_Shutdown();
        CarAutomaticTransmissionManager::DestroyContext();
        if (g_mainRenderTargetView) {
            g_mainRenderTargetView->Release();
            g_mainRenderTargetView = NULL;
        }
        if (g_pd3dContext) {
            g_pd3dContext->Release();
            g_pd3dContext = NULL;
        }
        if (g_pd3dDevice) {
            g_pd3dDevice->Release();
            g_pd3dDevice = NULL;
        }
        g_bInitialized = false;
    }
}


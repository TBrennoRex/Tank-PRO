#include <windows.h>
#include <shellapi.h>
#include <stdarg.h>
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "car_automatic_transmission.h"
#include "minhook/include/MinHook.h"

#define SCS_TELEMETRY_VERSION_1_00 0x00010000
#define SCS_VALUE_TYPE_bool   1
#define SCS_VALUE_TYPE_s32    2
#define SCS_VALUE_TYPE_u32    3
#define SCS_VALUE_TYPE_float  5

#define SCS_TELEMETRY_CHANNEL_FLAG_none       0x00000000
#define SCS_TELEMETRY_CHANNEL_FLAG_each_frame 0x00000001
#define SCS_U32_NIL ((unsigned int)-1)

typedef struct scs_value_s {
    unsigned int type;
    unsigned int _padding;
    union {
        struct { unsigned char value; } value_bool;
        struct { int value; } value_s32;
        struct { unsigned int value; } value_u32;
        struct { float value; } value_float;
    };
} scs_value_t;

typedef void (__cdecl *scs_telemetry_channel_callback_t)(
    const char *name,
    unsigned int index,
    const scs_value_t *value,
    void *context);

typedef int (__cdecl *scs_telemetry_register_for_channel_t)(
    const char *name,
    unsigned int index,
    unsigned int type,
    unsigned int flags,
    scs_telemetry_channel_callback_t callback,
    void *context);

typedef struct scs_sdk_init_params_v100_s {
    const char *game_name;
    const char *game_id;
    unsigned int game_version;
    unsigned int _padding;
    void (__cdecl *log)(int type, const char *message);
} scs_sdk_init_params_v100_t;

typedef struct scs_telemetry_init_params_v100_s {
    scs_sdk_init_params_v100_t common;
    void *register_for_event;
    void *unregister_from_event;
    scs_telemetry_register_for_channel_t register_for_channel;
    void *unregister_from_channel;
} scs_telemetry_init_params_v100_t;

#define OFF_INNER           0x10
#define OFF_GEAR            0x14b0
#define OFF_THROTTLE        0x68
#define OFF_ENGINE_HANDLE   0x1040
#define OFF_RPM_LIMIT       0x234
#define OFF_STEP_TABLE      0x48
#define OFF_STEP_COUNT      0x50
#define OFF_REV_GEARS       0x20
#define OFF_ENGINE_PHYS     0x150
#define OFF_ANGVEL          0x2e4
#define RADS_TO_RPM         9.5492965855f

#define RPM_LIMIT_MIN       500.0f
#define RPM_LIMIT_MAX       20000.0f

#define PAT_WINDOW  "48 8B 46 10 80 B8 A8 14 00 00 00 74 ?? F2 0F 10 83 44 02 00 00"
#define PAT_BOUND   "48 8B 41 10 0F 57 C9 F3 0F 10 15 ?? ?? ?? ?? 48 8B 90 F8 01 00 00 " \
                    "F3 0F 10 82 B0 01 00 00 F3 0F 58 82 A4 01 00 00"
#define PAT_LOBOUND "40 53 48 83 EC 40 48 8B D9 0F 29 7C 24 20 48 8B 49 10 E8"
#define PAT_CHOOSER "4C 63 B9 B0 14 00 00"
#define PAT_GATE    "F3 0F 59 81 F4 02 00 00 41 0F 2F C0 72 ??"

#define BOUND_DISC_OFF  0x40
#define GATE_JB_OFF     12
#define MAX_WIN_SITES   16

typedef int    (*bound_fn)(void *self);
typedef float *(*window_fn)(void *self, float *out, unsigned int gear);
typedef void  *(*resolve_fn)(void *handle);

static uintptr_t  g_base;
static bound_fn   o_hi_e60, o_hi_ed0, o_lo_e70;
static window_fn  o_window;
static resolve_fn o_resolve;

trans_config_t cfg = {
    1,
    1,
    2,
    0,
    3.00f,
    0.90f,
    0.72f,
    0.10f,
    0.85f,
    1.60f,
    1,
    2.00f,
    1,
    0.06f,
    0,
    6.00f,
    0.45f,
    0.75f,
    0.00f,
    0.00f,
    0.18f,
    1.50f,
    1.20f,
    "F9",
    VK_F9,
    "F8",
    VK_F8,
};

trans_mode_t g_modes[4] = {

    { 1, 1, 2, 0, 3.00f, 0.90f, 0.72f, 0.10f, 0.85f, 1.60f, 2.00f, 1, 0.06f, 0, 6.00f, 0.45f, 0.75f, 0.00f, 0.00f, 0.18f, 1.50f, 1.20f },

    { 1, 1, 2, 0, 4.00f, 0.98f, 0.88f, 0.00f, 0.70f, 1.25f, 3.50f, 1, 0.09f, 7, 8.00f, 0.25f, 0.45f, 0.00f, 0.00f, 0.10f, 2.40f, 1.60f },

    { 1, 1, 1, 0, 1.80f, 0.75f, 0.55f, 0.25f, 0.90f, 2.10f, 0.50f, 0, 0.03f, 0, 2.00f, 0.60f, 1.05f, 0.00f, 0.00f, 0.25f, 1.00f, 0.90f },

    { 0, 0, 0, 0, 0.00f, 0.90f, 0.65f, 0.45f, 0.85f, 1.60f, 0.00f, 0, 0.00f, 0, 0.00f, 0.00f, 0.00f, 0.00f, 0.00f, 1.00f, 1.00f, 1.00f }
};

char g_cfg_path[MAX_PATH * 2];
static char g_dir[MAX_PATH];
char g_cfg_dir[MAX_PATH * 2];

const char *trans_get_mode_name(int idx)
{
    switch (idx) {
        case 0: return "Normal";
        case 1: return "Sport";
        case 2: return "Comfort";
        case 3: return "Stock";
        default: return "Custom";
    }
}

trans_telemetry_t g_trans_telem = {0};
static ULONGLONG  g_last_telem_tick = 0;

static char s_vk_name_buf[32];

const char* trans_vk_to_name(int vk)
{
    if (vk >= VK_F1 && vk <= VK_F24) {
        snprintf(s_vk_name_buf, sizeof(s_vk_name_buf), "F%d", vk - VK_F1 + 1);
        return s_vk_name_buf;
    }
    if (vk >= '0' && vk <= '9') {
        snprintf(s_vk_name_buf, sizeof(s_vk_name_buf), "%c", (char)vk);
        return s_vk_name_buf;
    }
    if (vk >= 'A' && vk <= 'Z') {
        snprintf(s_vk_name_buf, sizeof(s_vk_name_buf), "%c", (char)vk);
        return s_vk_name_buf;
    }
    if (vk >= VK_NUMPAD0 && vk <= VK_NUMPAD9) {
        snprintf(s_vk_name_buf, sizeof(s_vk_name_buf), "NUM%d", vk - VK_NUMPAD0);
        return s_vk_name_buf;
    }
    switch (vk) {
        case VK_MULTIPLY: return "NUM*";
        case VK_ADD:      return "NUM+";
        case VK_SUBTRACT: return "NUM-";
        case VK_DECIMAL:  return "NUM.";
        case VK_DIVIDE:   return "NUM/";
        case VK_INSERT:   return "INSERT";
        case VK_DELETE:   return "DELETE";
        case VK_HOME:     return "HOME";
        case VK_END:      return "END";
        case VK_PRIOR:    return "PAGEUP";
        case VK_NEXT:     return "PAGEDOWN";
        case VK_TAB:      return "TAB";
        case VK_BACK:     return "BACKSPACE";
        case VK_RETURN:   return "ENTER";
        case VK_SPACE:    return "SPACE";
        case VK_PAUSE:    return "PAUSE";
        case VK_CAPITAL:  return "CAPSLOCK";
        case VK_SCROLL:   return "SCROLLLOCK";
        case VK_NUMLOCK:  return "NUMLOCK";
        case VK_SNAPSHOT: return "PRINTSCREEN";
        case VK_UP:       return "UP";
        case VK_DOWN:     return "DOWN";
        case VK_LEFT:     return "LEFT";
        case VK_RIGHT:    return "RIGHT";
        case VK_OEM_3:    return "~";
        case VK_OEM_MINUS: return "-";
        case VK_OEM_PLUS:  return "=";
        case VK_OEM_4:    return "[";
        case VK_OEM_6:    return "]";
        case VK_OEM_5:    return "\\";
        case VK_OEM_1:    return ";";
        case VK_OEM_7:    return "'";
        case VK_OEM_COMMA: return ",";
        case VK_OEM_PERIOD: return ".";
        case VK_OEM_2:    return "/";
        default: break;
    }

    UINT sc = MapVirtualKeyA(vk, MAPVK_VK_TO_VSC);
    if (sc != 0) {
        switch (vk) {
            case VK_LEFT: case VK_UP: case VK_RIGHT: case VK_DOWN:
            case VK_PRIOR: case VK_NEXT:
            case VK_END: case VK_HOME:
            case VK_INSERT: case VK_DELETE:
            case VK_DIVIDE: case VK_NUMLOCK:
                sc |= 0x100;
                break;
        }
        char sys_name[64] = {0};
        if (GetKeyNameTextA(sc << 16, sys_name, sizeof(sys_name)) > 0) {
            strncpy(s_vk_name_buf, sys_name, sizeof(s_vk_name_buf) - 1);
            s_vk_name_buf[sizeof(s_vk_name_buf) - 1] = 0;
            return s_vk_name_buf;
        }
    }

    snprintf(s_vk_name_buf, sizeof(s_vk_name_buf), "KEY_%d", vk);
    return s_vk_name_buf;
}

int trans_parse_key(const char *name)
{
    if (!name || !name[0]) return VK_F9;

    if ((name[0] == 'F' || name[0] == 'f') && isdigit((unsigned char)name[1])) {
        int fnum = atoi(name + 1);
        if (fnum >= 1 && fnum <= 24) return VK_F1 + (fnum - 1);
    }

    if (name[1] == '\0' && ((name[0] >= 'A' && name[0] <= 'Z') || (name[0] >= 'a' && name[0] <= 'z'))) {
        return toupper((unsigned char)name[0]);
    }

    if (name[1] == '\0' && name[0] >= '0' && name[0] <= '9') {
        return name[0];
    }

    if (!_strnicmp(name, "NUMPAD ", 7)) {
        if (name[7] >= '0' && name[7] <= '9' && name[8] == '\0') {
            return VK_NUMPAD0 + (name[7] - '0');
        }
    }
    if (!_strnicmp(name, "NUMPAD", 6)) {
        if (name[6] >= '0' && name[6] <= '9' && name[7] == '\0') {
            return VK_NUMPAD0 + (name[6] - '0');
        }
    }
    if (!_strnicmp(name, "NUM", 3)) {
        if (name[3] >= '0' && name[3] <= '9' && name[4] == '\0') {
            return VK_NUMPAD0 + (name[3] - '0');
        }
        if (!_stricmp(name, "NUM*") || !_stricmp(name, "NUMPAD*")) return VK_MULTIPLY;
        if (!_stricmp(name, "NUM+") || !_stricmp(name, "NUMPAD+")) return VK_ADD;
        if (!_stricmp(name, "NUM-") || !_stricmp(name, "NUMPAD-")) return VK_SUBTRACT;
        if (!_stricmp(name, "NUM.") || !_stricmp(name, "NUMPAD.")) return VK_DECIMAL;
        if (!_stricmp(name, "NUM/") || !_stricmp(name, "NUMPAD/")) return VK_DIVIDE;
    }

    if (!_stricmp(name, "INSERT") || !_stricmp(name, "INS") || !_stricmp(name, "EINFG")) return VK_INSERT;
    if (!_stricmp(name, "DELETE") || !_stricmp(name, "DEL") || !_stricmp(name, "ENTF")) return VK_DELETE;
    if (!_stricmp(name, "HOME") || !_stricmp(name, "POS1")) return VK_HOME;
    if (!_stricmp(name, "END") || !_stricmp(name, "ENDE")) return VK_END;
    if (!_stricmp(name, "PAGEUP") || !_stricmp(name, "PGUP") || !_stricmp(name, "BILD_AUF") || !_stricmp(name, "BILD AUF") || !_stricmp(name, "PAGE UP")) return VK_PRIOR;
    if (!_stricmp(name, "PAGEDOWN") || !_stricmp(name, "PGDN") || !_stricmp(name, "BILD_AB") || !_stricmp(name, "BILD AB") || !_stricmp(name, "PAGE DOWN")) return VK_NEXT;
    if (!_stricmp(name, "TAB")) return VK_TAB;
    if (!_stricmp(name, "BACKSPACE") || !_stricmp(name, "BACK")) return VK_BACK;
    if (!_stricmp(name, "ENTER") || !_stricmp(name, "RETURN")) return VK_RETURN;
    if (!_stricmp(name, "SPACE") || !_stricmp(name, "LEERTASTE")) return VK_SPACE;
    if (!_stricmp(name, "PAUSE")) return VK_PAUSE;
    if (!_stricmp(name, "CAPSLOCK") || !_stricmp(name, "CAPS")) return VK_CAPITAL;
    if (!_stricmp(name, "SCROLLLOCK") || !_stricmp(name, "SCROLL")) return VK_SCROLL;
    if (!_stricmp(name, "NUMLOCK")) return VK_NUMLOCK;
    if (!_stricmp(name, "PRINTSCREEN") || !_stricmp(name, "PRINT") || !_stricmp(name, "DRUCK")) return VK_SNAPSHOT;

    if (!_stricmp(name, "UP")) return VK_UP;
    if (!_stricmp(name, "DOWN")) return VK_DOWN;
    if (!_stricmp(name, "LEFT")) return VK_LEFT;
    if (!_stricmp(name, "RIGHT")) return VK_RIGHT;

    if (!_stricmp(name, "~") || !_stricmp(name, "`") || !_stricmp(name, "GRAVE") || !_stricmp(name, "TILDE") || !_stricmp(name, "^")) return VK_OEM_3;
    if (!_stricmp(name, "-") || !_stricmp(name, "MINUS")) return VK_OEM_MINUS;
    if (!_stricmp(name, "=") || !_stricmp(name, "+") || !_stricmp(name, "PLUS")) return VK_OEM_PLUS;
    if (!_stricmp(name, "[")) return VK_OEM_4;
    if (!_stricmp(name, "]")) return VK_OEM_6;
    if (!_stricmp(name, "\\")) return VK_OEM_5;
    if (!_stricmp(name, ";")) return VK_OEM_1;
    if (!_stricmp(name, "'")) return VK_OEM_7;
    if (!_stricmp(name, ",")) return VK_OEM_COMMA;
    if (!_stricmp(name, ".")) return VK_OEM_PERIOD;
    if (!_stricmp(name, "/")) return VK_OEM_2;

    if (!_strnicmp(name, "KEY_", 4)) {
        int val = atoi(name + 4);
        if (val > 0) return val;
    }
    if (name[0] == '0' && (name[1] == 'x' || name[1] == 'X')) {
        int val = (int)strtol(name, NULL, 16);
        if (val > 0) return val;
    }
    int val = atoi(name);
    if (val > 0) return val;

    return VK_F9;
}

void trans_set_menu_key(const char *name)
{
    if (!name || !name[0]) name = "F9";
    strncpy(cfg.menu_key, name, sizeof(cfg.menu_key) - 1);
    cfg.menu_key[sizeof(cfg.menu_key) - 1] = 0;
    cfg.menu_vk = trans_parse_key(cfg.menu_key);
}

void trans_set_menu_vk(int vk)
{
    if (vk <= 0) vk = VK_F9;
    cfg.menu_vk = vk;
    const char *kname = trans_vk_to_name(vk);
    if (kname && kname[0]) {
        strncpy(cfg.menu_key, kname, sizeof(cfg.menu_key) - 1);
    } else {
        snprintf(cfg.menu_key, sizeof(cfg.menu_key), "KEY_%d", vk);
    }
    cfg.menu_key[sizeof(cfg.menu_key) - 1] = 0;
    trans_save_config();
}

void trans_set_mode_key(const char *name)
{
    if (!name || !name[0]) name = "F8";
    strncpy(cfg.mode_key, name, sizeof(cfg.mode_key) - 1);
    cfg.mode_key[sizeof(cfg.mode_key) - 1] = 0;
    cfg.mode_vk = trans_parse_key(cfg.mode_key);
}

void trans_set_mode_vk(int vk)
{
    if (vk <= 0) vk = VK_F8;
    cfg.mode_vk = vk;
    const char *kname = trans_vk_to_name(vk);
    if (kname && kname[0]) {
        strncpy(cfg.mode_key, kname, sizeof(cfg.mode_key) - 1);
    } else {
        snprintf(cfg.mode_key, sizeof(cfg.mode_key), "KEY_%d", vk);
    }
    cfg.mode_key[sizeof(cfg.mode_key) - 1] = 0;
    trans_save_config();
}

static int s_current_mode_idx = 0;

int trans_get_current_mode_idx(void)
{
    return s_current_mode_idx;
}

void trans_set_current_mode_idx(int idx)
{
    s_current_mode_idx = (idx >= 0 && idx < 4) ? idx : 0;
}

static void sync_current_mode_to_g_modes(void)
{
    if (s_current_mode_idx >= 0 && s_current_mode_idx < 4) {
        g_modes[s_current_mode_idx].enabled    = cfg.enabled;
        g_modes[s_current_mode_idx].up_step    = cfg.up_step;
        g_modes[s_current_mode_idx].down_step  = cfg.down_step;
        g_modes[s_current_mode_idx].kick_step  = cfg.kick_step;
        g_modes[s_current_mode_idx].thr_gain   = cfg.thr_gain;
        g_modes[s_current_mode_idx].thr_peak   = cfg.thr_peak;
        g_modes[s_current_mode_idx].min_rpm_hi = cfg.min_rpm_hi;
        g_modes[s_current_mode_idx].thr_lo     = cfg.thr_lo;
        g_modes[s_current_mode_idx].thr_hi     = cfg.thr_hi;
        g_modes[s_current_mode_idx].thr_curve  = cfg.thr_curve;
        g_modes[s_current_mode_idx].fast_off_hold = cfg.fast_off_hold;
        g_modes[s_current_mode_idx].coast_hold  = cfg.coast_hold;
        g_modes[s_current_mode_idx].coast_thr   = cfg.coast_thr;
        g_modes[s_current_mode_idx].max_coast_gear = cfg.max_coast_gear;
        g_modes[s_current_mode_idx].coast_timeout = cfg.coast_timeout;
        g_modes[s_current_mode_idx].tip_in_delay = cfg.tip_in_delay;
        g_modes[s_current_mode_idx].inter_shift_delay = cfg.inter_shift_delay;
        g_modes[s_current_mode_idx].up_delay   = cfg.up_delay;
        g_modes[s_current_mode_idx].dn_delay   = cfg.dn_delay;
        g_modes[s_current_mode_idx].flywheel_inertia   = cfg.flywheel_inertia;
        g_modes[s_current_mode_idx].flywheel_response  = cfg.flywheel_response;
        g_modes[s_current_mode_idx].flywheel_drop_rate = cfg.flywheel_drop_rate;
    }
}

void trans_apply_mode_idx(int idx)
{
    if (idx < 0 || idx > 3) idx = 0;
    s_current_mode_idx = idx;
    cfg.enabled     = g_modes[idx].enabled;
    cfg.up_step     = g_modes[idx].up_step;
    cfg.down_step   = g_modes[idx].down_step;
    cfg.kick_step   = g_modes[idx].kick_step;
    cfg.thr_gain    = g_modes[idx].thr_gain;
    cfg.thr_peak    = g_modes[idx].thr_peak;
    cfg.min_rpm_hi  = g_modes[idx].min_rpm_hi;
    cfg.thr_lo      = g_modes[idx].thr_lo;
    cfg.thr_hi      = g_modes[idx].thr_hi;
    cfg.thr_curve   = g_modes[idx].thr_curve;
    cfg.fast_off_hold = g_modes[idx].fast_off_hold;
    cfg.coast_hold  = g_modes[idx].coast_hold;
    cfg.coast_thr   = g_modes[idx].coast_thr;
    cfg.max_coast_gear = g_modes[idx].max_coast_gear;
    cfg.coast_timeout = g_modes[idx].coast_timeout;
    cfg.tip_in_delay = g_modes[idx].tip_in_delay;
    cfg.inter_shift_delay = g_modes[idx].inter_shift_delay;
    cfg.up_delay    = g_modes[idx].up_delay;
    cfg.dn_delay    = g_modes[idx].dn_delay;
    cfg.flywheel_inertia   = g_modes[idx].flywheel_inertia;
    cfg.flywheel_response  = g_modes[idx].flywheel_response;
    cfg.flywheel_drop_rate = g_modes[idx].flywheel_drop_rate;
    trans_update_gate();
    trans_flight_log(TRANS_LOG_MODE,
        "MODE APPLIED: '%s' (up_step=%d, dn_step=%d, inter_shift=%.2fs, fast_off=%.1fs, coast_to=%.1fs, tip_in=%.2fs, J=%.2f, resp=%.2f)",
        trans_get_mode_name(idx), cfg.up_step, cfg.down_step, cfg.inter_shift_delay, cfg.fast_off_hold, cfg.coast_timeout, cfg.tip_in_delay, cfg.flywheel_inertia, cfg.flywheel_response);
}

void trans_switch_mode(int mode_idx)
{
    if (mode_idx < 0 || mode_idx > 3) mode_idx = 0;
    sync_current_mode_to_g_modes();
    trans_apply_mode_idx(mode_idx);
}

void trans_cycle_mode(void)
{
    sync_current_mode_to_g_modes();
    if (s_current_mode_idx >= 2) {
        s_current_mode_idx = 0;
    } else {
        s_current_mode_idx++;
    }
    trans_apply_mode_idx(s_current_mode_idx);
    switch (s_current_mode_idx) {
        case 0:
            trans_trigger_hud_notification("NORMAL", NULL, 0);
            break;
        case 1:
            trans_trigger_hud_notification("SPORT", NULL, 1);
            break;
        case 2:
            trans_trigger_hud_notification("COMFORT", NULL, 2);
            break;
    }
    trans_save_config();
}

static void status(const char *fmt, ...)
{
    (void)fmt;
}

static const unsigned char *g_text;
static size_t               g_text_size;
static uintptr_t            g_text_va;

typedef struct { uint32_t begin, end, unwind; } RTF;
static const RTF *g_rtf;
static size_t     g_rtf_count;

static int pe_init(void)
{
    const unsigned char *b = (const unsigned char *)g_base;
    const IMAGE_DOS_HEADER *dos = (const IMAGE_DOS_HEADER *)b;
    const IMAGE_NT_HEADERS64 *nt;
    const IMAGE_SECTION_HEADER *sec;
    const IMAGE_DATA_DIRECTORY *dir;
    unsigned i;

    if (!b || dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
    nt = (const IMAGE_NT_HEADERS64 *)(b + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return 0;
    if (nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC) return 0;

    sec = (const IMAGE_SECTION_HEADER *)((const unsigned char *)&nt->OptionalHeader +
                                         nt->FileHeader.SizeOfOptionalHeader);
    for (i = 0; i < nt->FileHeader.NumberOfSections; i++) {
        if (!memcmp(sec[i].Name, ".text", 5)) {
            g_text      = b + sec[i].VirtualAddress;
            g_text_size = sec[i].Misc.VirtualSize;
            g_text_va   = g_base + sec[i].VirtualAddress;
            break;
        }
    }
    dir = &nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION];
    if (!dir->VirtualAddress || dir->Size < sizeof(RTF)) return 0;
    g_rtf       = (const RTF *)(b + dir->VirtualAddress);
    g_rtf_count = dir->Size / sizeof(RTF);
    return g_text && g_text_size && g_rtf_count;
}

static int pat_parse(const char *p, unsigned char *bytes, unsigned char *mask, int cap)
{
    int n = 0;
    while (*p && n < cap) {
        while (*p == ' ') p++;
        if (!*p) break;
        if (p[0] == '?' && p[1] == '?') { bytes[n] = 0; mask[n] = 0; p += 2; }
        else {
            int hi = (p[0] <= '9') ? p[0] - '0' : (p[0] | 32) - 'a' + 10;
            int lo = (p[1] <= '9') ? p[1] - '0' : (p[1] | 32) - 'a' + 10;
            bytes[n] = (unsigned char)((hi << 4) | lo);
            mask[n] = 1;
            p += 2;
        }
        n++;
    }
    return n;
}

static int pat_scan(const char *pattern, uintptr_t *hits, int max_hits)
{
    unsigned char bytes[80], mask[80];
    int len = pat_parse(pattern, bytes, mask, 80);
    int found = 0;
    const unsigned char *p = g_text;
    size_t left = g_text_size;

    if (len < 4 || !mask[0]) return -1;
    for (;;) {
        const unsigned char *m = (const unsigned char *)memchr(p, bytes[0], left);
        size_t off;
        int i, ok;
        if (!m) break;
        off = (size_t)(m - g_text);
        if (off + (size_t)len > g_text_size) break;
        ok = 1;
        for (i = 1; i < len; i++)
            if (mask[i] && m[i] != bytes[i]) { ok = 0; break; }
        if (ok) {
            if (found >= max_hits) return -1;
            hits[found++] = g_text_va + off;
        }
        p    = m + 1;
        left = g_text_size - (size_t)(p - g_text);
        if (!left) break;
    }
    return found;
}

static int rtf_index_of(uintptr_t va)
{
    uint32_t rva = (uint32_t)(va - g_base);
    int lo = 0, hi = (int)g_rtf_count - 1;
    while (lo <= hi) {
        int m = lo + (hi - lo) / 2;
        if (rva < g_rtf[m].begin)     hi = m - 1;
        else if (rva >= g_rtf[m].end) lo = m + 1;
        else return m;
    }
    return -1;
}

static int rtf_primary(int i)
{
    int guard;
    for (guard = 0; guard < 16; guard++) {
        const unsigned char *u = (const unsigned char *)(g_base + g_rtf[i].unwind);
        unsigned codes, off;
        uint32_t chained;
        int j;
        if (!((u[0] >> 3) & 4)) return i;
        codes = u[2];
        off   = 4 + ((codes + 1) / 2) * 4;
        memcpy(&chained, u + off, 4);
        j = rtf_index_of(g_base + chained);
        if (j < 0 || j == i) return i;
        i = j;
    }
    return i;
}

static int func_extent(uintptr_t va, uintptr_t *lo_out, uintptr_t *hi_out)
{
    int i = rtf_index_of(va), p, lo, hi;
    if (i < 0) return 0;
    p  = rtf_primary(i);
    lo = i;
    while (lo > 0 && rtf_primary(lo - 1) == p) lo--;
    hi = i;
    while (hi + 1 < (int)g_rtf_count && rtf_primary(hi + 1) == p) hi++;
    *lo_out = g_base + g_rtf[lo].begin;
    *hi_out = g_base + g_rtf[hi].end;
    return 1;
}

static int calls_to(uintptr_t target, uintptr_t lo, uintptr_t hi,
                    uintptr_t *out, int max_out)
{
    const unsigned char *p = (const unsigned char *)lo;
    const unsigned char *end;
    int found = 0;
    if (hi <= lo + 5) return 0;
    end = (const unsigned char *)(hi - 5);
    for (; p <= end; p++) {
        int32_t rel;
        if (*p != 0xE8) continue;
        memcpy(&rel, p + 1, 4);
        if ((uintptr_t)(p + 5) + (intptr_t)rel != target) continue;
        if (found >= max_out) return -1;
        out[found++] = (uintptr_t)p;
    }
    return found;
}

static uintptr_t first_call_in(uintptr_t lo, uintptr_t hi)
{
    const unsigned char *p = (const unsigned char *)lo;
    const unsigned char *end;
    if (hi <= lo + 5) return 0;
    end = (const unsigned char *)(hi - 5);
    for (; p <= end; p++) {
        int32_t rel;
        if (*p != 0xE8) continue;
        memcpy(&rel, p + 1, 4);
        return (uintptr_t)(p + 5) + (intptr_t)rel;
    }
    return 0;
}

static uintptr_t s_hi_kick, s_lo_kick, s_hi_shared, s_lo_down, s_hi_up;
static uintptr_t s_window[MAX_WIN_SITES];
static int       s_window_count;
static uintptr_t s_gate;

static const char *discover(void)
{
    uintptr_t hits[8], lo, hi, ced0[4], ce70[4], ce60[4];
    uintptr_t fn_window, fn_resolve, fn_e60 = 0, fn_ed0 = 0, fn_e70;
    int n, i;

    if (!pe_init()) return "PE header";

    n = pat_scan(PAT_WINDOW, hits, 8);
    if (n != 1) return "window pattern";
    if (!func_extent(hits[0], &lo, &hi)) return "window extent";
    fn_window  = lo;
    fn_resolve = first_call_in(lo, hi);
    if (!fn_resolve || fn_resolve < g_text_va || fn_resolve >= g_text_va + g_text_size)
        return "resolver";

    n = pat_scan(PAT_BOUND, hits, 8);
    if (n != 2) return "bound pattern";
    for (i = 0; i < 2; i++) {
        const unsigned char *d = (const unsigned char *)(hits[i] + BOUND_DISC_OFF);
        if (d[0] == 0x8B && d[1] == 0x41 && d[2] == 0x1C) fn_e60 = hits[i];
        if (d[0] == 0x8B && d[1] == 0x41 && d[2] == 0x20) fn_ed0 = hits[i];
    }
    if (!fn_e60 || !fn_ed0) return "bound discriminator";

    n = pat_scan(PAT_LOBOUND, hits, 8);
    if (n != 1) return "lower bound pattern";
    fn_e70 = hits[0];

    n = pat_scan(PAT_CHOOSER, hits, 8);
    if (n != 1) return "chooser pattern";
    if (!func_extent(hits[0], &lo, &hi)) return "chooser extent";

    if (calls_to(fn_ed0, lo, hi, ced0, 4) != 2) return "kick/up call sites";
    if (calls_to(fn_e70, lo, hi, ce70, 4) != 2) return "kick/down call sites";
    if (calls_to(fn_e60, lo, hi, ce60, 4) != 1) return "shared call site";
    s_hi_kick   = ced0[0];
    s_hi_up     = ced0[1];
    s_lo_kick   = ce70[0];
    s_lo_down   = ce70[1];
    s_hi_shared = ce60[0];

    s_window_count = calls_to(fn_window, g_text_va, g_text_va + g_text_size,
                              s_window, MAX_WIN_SITES);
    if (s_window_count < 1) return "window call sites";

    n = pat_scan(PAT_GATE, hits, 8);
    if (n != 1) return "gate pattern";
    s_gate = hits[0] + GATE_JB_OFF;
    if (*(const unsigned char *)s_gate != 0x72) return "gate opcode";

    o_hi_e60  = (bound_fn)fn_e60;
    o_hi_ed0  = (bound_fn)fn_ed0;
    o_lo_e70  = (bound_fn)fn_e70;
    o_window  = (window_fn)fn_window;
    o_resolve = (resolve_fn)fn_resolve;
    return NULL;
}

static int cur_abs_gear(void *self)
{
    char *inner;
    int gi;
    if (!self) return -1;
    inner = *(char **)((char *)self + OFF_INNER);
    if (!inner) return -1;
    gi = *(int32_t *)(inner + OFF_GEAR);
    if (gi < -64 || gi > 64) return -1;
    return gi < 0 ? -gi : gi;
}

static int clamp_hi(void *self, int orig, int step)
{
    int cur, lim;
    if (step <= 0) return orig;
    cur = cur_abs_gear(self);
    if (cur < 0) return orig;
    lim = cur + step;
    if (lim < 1) lim = 1;
    return orig < lim ? orig : lim;
}

static inline int is_panic_braking(void)
{
    return (g_trans_telem.accel_mps2 < -7.0f && g_trans_telem.brake > 0.40f) ||
           (g_trans_telem.accel_mps2 < -9.0f) ||
           (g_trans_telem.brake > 0.70f && g_trans_telem.accel_mps2 < -4.5f);
}

static int clamp_lo(void *self, int orig, int step)
{
    int cur, lim;
    cur = cur_abs_gear(self);
    if (cur < 0) return orig;

    int panic = is_panic_braking();
    float d1_lock_spd = panic ? 45.0f : 15.0f;

    if (g_trans_telem.speed_kmh >= d1_lock_spd && orig < 2 && cur >= 2) {
        orig = 2;
    }

    if (panic || g_trans_telem.brake > 0.25f || g_trans_telem.accel_mps2 < -3.0f ||
        g_trans_telem.throttle >= 0.90f) {
        step = 0;
    } else if (g_trans_telem.throttle > 0.0f && g_trans_telem.throttle < 0.50f && step != 1) {
        step = 1;
    }

    if (step <= 0) return orig;
    lim = cur - step;
    if (lim < 1) lim = 1;
    if (g_trans_telem.speed_kmh >= d1_lock_spd && lim < 2 && cur >= 2) lim = 2;
    return orig > lim ? orig : lim;
}

#define NSLOT 16
static struct { void *self; int gear; ULONGLONG t; } g_slot[NSLOT];

static ULONGLONG since_shift(void *self)
{
    ULONGLONG now = GetTickCount64();
    int cur = cur_abs_gear(self);
    int i, free_i = -1;
    if (cur < 0) return (ULONGLONG)-1;
    for (i = 0; i < NSLOT; i++) {
        if (g_slot[i].self == self) {
            if (g_slot[i].gear != cur) { g_slot[i].gear = cur; g_slot[i].t = now; return 0; }
            return now - g_slot[i].t;
        }
        if (g_slot[i].self == NULL && free_i < 0) free_i = i;
    }
    if (free_i < 0) free_i = (int)((uintptr_t)self >> 5) & (NSLOT - 1);
    g_slot[free_i].self = self;
    g_slot[free_i].gear = cur;
    g_slot[free_i].t    = now;
    return 0;
}

static int dsg_is_locked(void);

static float downshift_dwell_s(void)
{
    float dn = cfg.dn_delay;
    float soft = cfg.inter_shift_delay * 1.5f;
    if (g_trans_telem.throttle < 0.60f && soft > dn) dn = soft;
    return dn;
}

static int is_shift_locked(void *self, int is_downshift)
{

    if (dsg_is_locked()) return 1;

    ULONGLONG dt = since_shift(self);
    if (dt == (ULONGLONG)-1) return 0;

    if (is_downshift) {

        if (g_trans_telem.brake > 0.05f) return 0;

        if (g_trans_telem.accel_mps2 < -2.0f) return 0;

        if (g_trans_telem.throttle >= 0.90f) return 0;

        if (g_trans_telem.engine_rpm > 100.0f && g_trans_telem.engine_rpm < 1300.0f) return 0;

        float dwell = downshift_dwell_s();
        if (dwell <= 0.0f) return 0;
        return dt < (ULONGLONG)(dwell * 1000.0f);
    }

    float delay = cfg.up_delay;
    if (cfg.inter_shift_delay > delay) delay = cfg.inter_shift_delay;
    if (delay <= 0.0f) return 0;
    return dt < (ULONGLONG)(delay * 1000.0f);
}

static float get_shift_lock_remaining(void *self, int is_downshift)
{
    ULONGLONG dt = since_shift(self);
    if (dt == (ULONGLONG)-1) return 0.0f;

    if (is_downshift) {
        if (g_trans_telem.brake > 0.05f || g_trans_telem.accel_mps2 < -2.0f || g_trans_telem.throttle >= 0.90f) return 0.0f;
        if (g_trans_telem.engine_rpm > 100.0f && g_trans_telem.engine_rpm < 1300.0f) return 0.0f;
        float dwell = downshift_dwell_s();
        if (dwell <= 0.0f) return 0.0f;
        ULONGLONG req = (ULONGLONG)(dwell * 1000.0f);
        if (dt >= req) return 0.0f;
        return (float)(req - dt) / 1000.0f;
    }

    float delay = cfg.up_delay;
    if (cfg.inter_shift_delay > delay) delay = cfg.inter_shift_delay;
    if (delay <= 0.0f) return 0.0f;
    ULONGLONG req = (ULONGLONG)(delay * 1000.0f);
    if (dt >= req) return 0.0f;
    return (float)(req - dt) / 1000.0f;
}

static int shift_locked(void *self, float delay_s)
{
    ULONGLONG dt = since_shift(self);
    if (delay_s <= 0.0f) return 0;
    if (dt == (ULONGLONG)-1) return 0;
    return dt < (ULONGLONG)(delay_s * 1000.0f);
}

static int hold_gear(void *self, int orig)
{
    int cur = cur_abs_gear(self);
    if (cur < 1) return orig;
    return cur;
}

static float engine_rpm_of(void *self)
{
    char *inner, *phys;
    float w;
    if (!self) return 0.0f;
    inner = *(char **)((char *)self + OFF_INNER);
    if (!inner) return 0.0f;
    phys = *(char **)(inner + OFF_ENGINE_PHYS);
    if (!phys) return 0.0f;
    w = *(float *)(phys + OFF_ANGVEL) * RADS_TO_RPM;
    if (w < 0.0f) w = -w;
    if (!(w < 25000.0f)) return 0.0f;
    return w;
}

static float throttle_of(void *self)
{
    float t;

    if (g_trans_telem.brake > 0.10f) return 0.0f;
    if (!self) return 0.0f;
    t = *(float *)((char *)self + OFF_THROTTLE);
    if (!(t >= 0.0f)) return 0.0f;
    return t > 1.0f ? 1.0f : t;
}

static float shift_pedal_filtered(float t)
{
    static LARGE_INTEGER freq, last;
    static float state;
    LARGE_INTEGER now;
    if (!freq.QuadPart) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&now);
    float dt = last.QuadPart ? (float)(now.QuadPart - last.QuadPart) / (float)freq.QuadPart : -1.0f;
    last = now;

    if (dt < 0.0f || dt > 0.5f || t >= 0.90f) {
        state = t;
        return t;
    }
    int mode = trans_get_current_mode_idx();
    float tau_up = (mode == 1) ? 0.25f : ((mode == 2) ? 0.70f : 0.45f);
    float tau = (t > state) ? tau_up : 0.30f;
    state += (t - state) * (dt / (tau + dt));
    return state;
}

static float pedal_ramp(void *self)
{
    if (g_trans_telem.brake > 0.10f) return 0.0f;
    float t = shift_pedal_filtered(throttle_of(self));
    float f;
    if (cfg.thr_hi <= cfg.thr_lo) return 0.0f;
    f = (t - cfg.thr_lo) / (cfg.thr_hi - cfg.thr_lo);
    if (f <= 0.0f) return 0.0f;
    if (f > 1.0f) f = 1.0f;
    if (cfg.thr_curve != 1.0f) f = powf(f, cfg.thr_curve);
    return f;
}

static float gear_step(void *self, unsigned int gear)
{
    char *base = (char *)self;
    unsigned long long n;
    long long idx;
    float *arr;
    if (!self) return 0.0f;
    n   = *(unsigned long long *)(base + OFF_STEP_COUNT);
    arr = *(float **)(base + OFF_STEP_TABLE);
    idx = (long long)(*(int32_t *)(base + OFF_REV_GEARS)) + (int)gear;
    if (!arr || n > 256 || idx < 0 || (unsigned long long)idx >= n) return 0.0f;
    return arr[idx];
}

static float rpm_limit_of(void *self)
{
    char *inner, *eng;
    void *handle;
    float lim;
    if (!o_resolve || !self) return 0.0f;
    inner = *(char **)((char *)self + OFF_INNER);
    if (!inner) return 0.0f;
    handle = *(void **)(inner + OFF_ENGINE_HANDLE);
    if (!handle) return 0.0f;
    eng = (char *)o_resolve(handle);
    if (!eng) return 0.0f;
    lim = *(float *)(eng + OFF_RPM_LIMIT);
    if (!(lim > RPM_LIMIT_MIN && lim < RPM_LIMIT_MAX)) return 0.0f;
    return lim;
}

typedef enum {
    DSG_PHASE_STEADY = 0,
    DSG_PHASE_TORQUE_CROSS,
    DSG_PHASE_INERTIA,
    DSG_PHASE_LAUNCH_CREEP
} dsg_phase_e;

typedef struct {
    float pressure;
    float transferred_torque;
    int   gear;
    float ratio;
} dsg_clutch_t;

typedef struct {
    dsg_clutch_t k1;
    dsg_clutch_t k2;

    int          active_clutch;
    int          preselected_gear;
    dsg_phase_e  phase;
    float        phase_timer;

    int          shift_from_gear;
    int          shift_to_gear;
    float        ratio_old;
    float        ratio_new;

    int          is_skip_shift;
    int          skip_intermediate_g;
    int          skip_final_target_g;

    float        t_crossover;
    float        t_inertia;
    float        torque_cut_pct;
    float        blip_factor;
    float        j_engine;

    float        effective_load;
    float        propshaft_torque;
    float        inertia_kick_nm;
    float        active_blip_nm;

    int          is_decoupled;

    int          flywheel_state;
    float        flywheel_inertia;
    float        flywheel_response;
    float        flywheel_drop_rate;
} dsg_transmission_t;

static dsg_transmission_t g_dsg = {
    {1.0f, 0.0f, 1, 3.50f},
    {0.0f, 0.0f, 2, 2.15f},
    1, 2, DSG_PHASE_STEADY, 0.0f,
    1, 2, 3.50f, 2.15f,
    0, 0, 0,
    0.20f, 0.15f, 0.30f, 0.65f, 0.22f,
    0.0f, 0.0f, 0.0f, 0.0f,
    0,
    0, 0.10f, 2.40f, 1.60f
};

static int dsg_is_locked(void)
{
    return (g_dsg.phase != DSG_PHASE_STEADY || g_dsg.is_skip_shift);
}

static float dsg_get_diff_ratio(void *self)
{
    if (!self) return 3.23f;
    char *inner = *(char **)((char *)self + OFF_INNER);
    char *phys  = inner ? *(char **)(inner + OFF_ENGINE_PHYS) : NULL;
    char *trans = phys ? *(char **)(phys + 0x358) : NULL;
    if (!trans && inner && o_resolve) {
        void *handle = *(void **)(inner + 0x1038);
        if (handle) trans = (char *)o_resolve(handle);
    }
    if (trans) {

        float diff = *(float *)(trans + 0x1c4);
        if (diff > 0.5f && diff < 15.0f) {
            return diff;
        }
    }
    return 3.23f;
}

static float s_gear_ratio_cache[32] = {0};
static float s_rev_ratio_cache[8]   = {0};

static void *s_last_self   = NULL;
static char *s_last_inner  = NULL;
static char *s_last_phys   = NULL;
static float s_sdk_throttle = 0.0f;
static int   s_sdk_throttle_seen = 0;

static const float s_pkw_ratios[12] = {
    4.71f,
    3.20f,
    2.14f,
    1.72f,
    1.31f,
    1.00f,
    0.82f,
    0.67f,
    0.56f,
    0.48f,
    0.40f,
    0.35f
};

static void dsg_sync_ratio_table(void *self)
{
    if (!self) return;
    char *inner = *(char **)((char *)self + OFF_INNER);
    char *phys  = inner ? *(char **)(inner + OFF_ENGINE_PHYS) : NULL;
    char *trans = phys ? *(char **)(phys + 0x358) : NULL;
    if (!trans && inner && o_resolve) {
        void *handle = *(void **)(inner + 0x1038);
        if (handle) trans = (char *)o_resolve(handle);
    }

    if (trans) {

        float *arr = *(float **)(trans + 0x1f8 + 8);
        unsigned long long count = *(unsigned long long *)(trans + 0x1f8 + 16);
        if (arr && count > 0 && count <= 32) {
            for (unsigned long long i = 0; i < count; i++) {
                if (arr[i] > 0.05f && arr[i] < 30.0f) {
                    s_gear_ratio_cache[i] = arr[i];
                }
            }
        }

        float *rev_arr = *(float **)(trans + 0x220 + 8);
        unsigned long long rev_count = *(unsigned long long *)(trans + 0x220 + 16);
        if (rev_arr && rev_count > 0 && rev_count <= 8) {
            for (unsigned long long i = 0; i < rev_count; i++) {
                if (rev_arr[i] > 0.05f && rev_arr[i] < 30.0f) {
                    s_rev_ratio_cache[i] = rev_arr[i];
                }
            }
        }
    }

    for (int i = 0; i < 12; i++) {
        if (s_gear_ratio_cache[i] <= 0.05f) {
            s_gear_ratio_cache[i] = s_pkw_ratios[i];
        }
    }
    if (s_rev_ratio_cache[0] <= 0.05f) {
        s_rev_ratio_cache[0] = 3.30f;
    }
}

static float dsg_get_gear_ratio(void *self, int gear)
{
    if (gear == 0 || !self) return 0.0f;

    if (s_gear_ratio_cache[0] <= 0.05f) {
        dsg_sync_ratio_table(self);
    }

    char *inner = *(char **)((char *)self + OFF_INNER);
    char *phys  = inner ? *(char **)(inner + OFF_ENGINE_PHYS) : NULL;
    int cur_g   = cur_abs_gear(self);
    if (phys && cur_g > 0 && cur_g <= 32) {
        float cur_r = *(float *)(phys + 0x2c4);
        if (cur_r > 0.1f && cur_r < 30.0f) {
            s_gear_ratio_cache[cur_g - 1] = cur_r;
        }
    }

    if (gear > 0) {
        int idx = gear - 1;
        if (idx >= 0 && idx < 32 && s_gear_ratio_cache[idx] > 0.05f) {
            return s_gear_ratio_cache[idx];
        }
        if (idx >= 0 && idx < 12) return s_pkw_ratios[idx];
        return 1.0f;
    } else {
        int idx = (-gear) - 1;
        if (idx >= 0 && idx < 8 && s_rev_ratio_cache[idx] > 0.05f) {
            return s_rev_ratio_cache[idx];
        }
        return 3.30f;
    }
}

static void dsg_update_preselection(void *self, int cur_gear, float thr_grad, float brake, float speed_kmh)
{
    if (cur_gear == 0) {
        g_dsg.k1.gear = 1;
        g_dsg.k2.gear = 2;
        g_dsg.preselected_gear = 1;
        return;
    }

    if (cur_gear < 0) {
        g_dsg.k1.gear = 1;
        g_dsg.k1.ratio = dsg_get_gear_ratio(self, 1);
        g_dsg.preselected_gear = 1;
        return;
    }

    int is_cur_odd = (cur_gear % 2 != 0);
    int pre_target;
    int wants_downshift = (brake > 0.15f || thr_grad < -1.5f);

    if (is_cur_odd) {

        if (cur_gear == 1) {
            pre_target = (speed_kmh < 1.0f && brake > 0.5f) ? -1 : 2;
        } else {
            pre_target = wants_downshift ? (cur_gear - 1) : (cur_gear + 1);
        }
        g_dsg.k2.gear = pre_target;
        g_dsg.k2.ratio = dsg_get_gear_ratio(self, pre_target);
    } else {

        pre_target = wants_downshift ? (cur_gear - 1) : (cur_gear + 1);
        if (pre_target < 1) pre_target = 1;
        g_dsg.k1.gear = pre_target;
        g_dsg.k1.ratio = dsg_get_gear_ratio(self, pre_target);
    }
    g_dsg.preselected_gear = pre_target;
}

static ULONGLONG s_dsg_shift_start_ms;

static void dsg_trigger_shift(void *self, int from_gear, int to_gear)
{
    if (from_gear == to_gear || from_gear == 0 || to_gear == 0) return;
    s_dsg_shift_start_ms = GetTickCount64();

    int is_from_odd = (from_gear % 2 != 0);
    int is_to_odd   = (to_gear % 2 != 0);

    if (is_from_odd == is_to_odd) {

        int intermediate = (to_gear > from_gear) ? (from_gear + 1) : (from_gear - 1);
        if (intermediate < 1) intermediate = 1;

        g_dsg.is_skip_shift       = 1;
        g_dsg.skip_intermediate_g = intermediate;
        g_dsg.skip_final_target_g = to_gear;

        g_dsg.shift_from_gear = from_gear;
        g_dsg.shift_to_gear   = to_gear;
        g_dsg.ratio_old       = dsg_get_gear_ratio(self, from_gear);
        g_dsg.ratio_new       = dsg_get_gear_ratio(self, to_gear);

        g_dsg.phase = DSG_PHASE_TORQUE_CROSS;
        g_dsg.phase_timer = 0.0f;

        g_dsg.preselected_gear = to_gear;
        if (to_gear % 2 != 0) {
            g_dsg.k1.gear = to_gear;
            g_dsg.k1.ratio = dsg_get_gear_ratio(self, to_gear);
        } else {
            g_dsg.k2.gear = to_gear;
            g_dsg.k2.ratio = dsg_get_gear_ratio(self, to_gear);
        }

        trans_flight_log(TRANS_LOG_DSG,
            "[DSG-SKIP] SAME-SHAFT: D%d -> D%d via D%d (K%d) | i=%.2f -> %.2f | extended shift x1.4",
            from_gear, to_gear, intermediate, (intermediate % 2 != 0 ? 1 : 2),
            g_dsg.ratio_old, g_dsg.ratio_new);
        return;
    }

    g_dsg.is_skip_shift   = 0;
    g_dsg.shift_from_gear = from_gear;
    g_dsg.shift_to_gear   = to_gear;
    g_dsg.ratio_old       = dsg_get_gear_ratio(self, from_gear);
    g_dsg.ratio_new       = dsg_get_gear_ratio(self, to_gear);

    g_dsg.phase = DSG_PHASE_TORQUE_CROSS;
    g_dsg.phase_timer = 0.0f;

    int wants_down = (to_gear < from_gear || g_trans_telem.brake > 0.15f);
    int next_pre;
    if (to_gear % 2 != 0) {

        if (to_gear == 1) {
            next_pre = 2;
        } else {
            next_pre = wants_down ? (to_gear - 1) : (to_gear + 1);
        }
        g_dsg.k2.gear = next_pre;
        g_dsg.k2.ratio = dsg_get_gear_ratio(self, next_pre);
    } else {

        next_pre = wants_down ? (to_gear - 1) : (to_gear + 1);
        if (next_pre < 1) next_pre = 1;
        g_dsg.k1.gear = next_pre;
        g_dsg.k1.ratio = dsg_get_gear_ratio(self, next_pre);
    }
    g_dsg.preselected_gear = next_pre;

    const char *type = (to_gear > from_gear) ? "POWER-UPSHIFT" : "REV-MATCH DOWNSHIFT";
    trans_flight_log(TRANS_LOG_DSG,
        "[DSG] %s: D%d (i=%.2f, K%d) -> D%d (i=%.2f, K%d) [Next-Pre: D%d, t_cross=%.2fs, t_inertia=%.2fs]",
        type, from_gear, g_dsg.ratio_old, (from_gear % 2 != 0 ? 1 : 2),
        to_gear, g_dsg.ratio_new, (to_gear % 2 != 0 ? 1 : 2),
        next_pre, g_dsg.t_crossover, g_dsg.t_inertia);
}

#define FW_RPM_TO_RADS   0.104719755f
#define FW_T_PEAK_NM     300.0f
#define FW_SUBSTEP_S     0.002f
#define FW_TAU_AIR_S     0.07f
#define FW_TAU_REV_S     0.12f
#define FW_TAU_IDLE_S    0.18f
#define FW_LIMIT_HYST    (150.0f * FW_RPM_TO_RADS)
#define FW_PEDAL_DEAD    0.02f

static struct {
    int           active;
    float         w;
    float         t_air;
    int           limiter_cut;
    LARGE_INTEGER last_qpc;
} s_fw;

static float fw_wot_torque(float w, float w_red)
{
    float x = w / w_red;
    if (x < 0.0f) x = 0.0f;
    if (x > 1.2f) x = 1.2f;
    return FW_T_PEAK_NM * (0.72f + 1.10f * x - 1.10f * x * x);
}

static float fw_loss_torque(float w, float load, float drag_scale)
{
    float fric = 18.0f + 0.050f * w + 0.00010f * w * w;
    float pump = 16.0f * (1.0f - load);
    return (fric + pump) * drag_scale;
}

static void fw_set_state(int st)
{
    g_dsg.flywheel_state = st;
    g_trans_telem.flywheel_state = st;
}

static float fw_step(float w_game, float pedal_in, float idle_r, float redline_r, float dt)
{
    float w_idle = idle_r * FW_RPM_TO_RADS;
    float w_red  = redline_r * FW_RPM_TO_RADS;

    float J    = (cfg.flywheel_inertia   > 0.02f) ? cfg.flywheel_inertia   : 0.18f;
    float resp = (cfg.flywheel_response  > 0.10f) ? cfg.flywheel_response  : 1.50f;
    float drag = (cfg.flywheel_drop_rate > 0.10f) ? cfg.flywheel_drop_rate : 1.20f;
    if (J < 0.03f) J = 0.03f;
    if (resp < 0.25f) resp = 0.25f;
    if (drag < 0.25f) drag = 0.25f;

    float pedal = (pedal_in > FW_PEDAL_DEAD) ? (pedal_in - FW_PEDAL_DEAD) / (1.0f - FW_PEDAL_DEAD) : 0.0f;
    if (pedal > 1.0f) pedal = 1.0f;
    g_trans_telem.target_rev_rpm = idle_r + pedal * (redline_r - idle_r);

    if (s_fw.active && w_game < w_idle * 0.3f) s_fw.active = 0;

    if (!s_fw.active) {
        int engine_running = w_game >= w_idle * 0.5f;
        int needs_model    = pedal > 0.0f || w_game > w_idle * 1.05f;
        if (!engine_running || !needs_model) {
            fw_set_state(0);
            return w_game;
        }
        s_fw.active = 1;
        s_fw.w = w_game;
        s_fw.limiter_cut = 0;
        s_fw.t_air = fw_loss_torque(w_game, 0.3f, drag);
        trans_flight_log(TRANS_LOG_FLYWHEEL,
            "ACTIVATE: rpm=%.0f pedal=%.2f idle=%.0f lim=%.0f | J=%.2f resp=%.2f drag=%.2f dt=%.4fs",
            w_game * RADS_TO_RPM, pedal_in, idle_r, redline_r, J, resp, drag, dt);
    }
    int limiter_was = s_fw.limiter_cut;

    int n = (int)(dt / FW_SUBSTEP_S) + 1;
    if (n > 125) n = 125;
    float h = dt / (float)n;
    float tau_air = FW_TAU_AIR_S / resp;
    float tau_rev = FW_TAU_REV_S / resp;

    for (int i = 0; i < n; i++) {
        float w     = s_fw.w;
        float t_wot = fw_wot_torque(w, w_red);
        float load  = s_fw.t_air / t_wot;
        if (load < 0.0f) load = 0.0f;
        if (load > 1.0f) load = 1.0f;
        float t_loss = fw_loss_torque(w, load, drag);

        float t_req;
        if (pedal > 0.0f) {

            float w_tgt = w_idle + pedal * (w_red * 1.06f - w_idle);
            t_req = t_loss + J * (w_tgt - w) / tau_rev;
        } else {
            t_req = t_loss + J * (w_idle - w) / FW_TAU_IDLE_S;
        }
        if (t_req < 0.0f) t_req = 0.0f;
        if (t_req > t_wot) t_req = t_wot;

        s_fw.t_air += (t_req - s_fw.t_air) * (h / (tau_air + h));

        if (s_fw.limiter_cut) {
            if (w < w_red - FW_LIMIT_HYST) s_fw.limiter_cut = 0;
        } else if (w >= w_red) {
            s_fw.limiter_cut = 1;
        }

        float t_ind = (t_req < s_fw.t_air) ? t_req : s_fw.t_air;
        if (s_fw.limiter_cut) t_ind = 0.0f;

        s_fw.w += (t_ind - t_loss) / J * h;
        if (s_fw.w < 0.0f) s_fw.w = 0.0f;
    }

    if (s_fw.limiter_cut && !limiter_was) {
        static ULONGLONG s_last_lim_log = 0;
        ULONGLONG t = GetTickCount64();
        if (t - s_last_lim_log >= 1000) {
            trans_flight_log(TRANS_LOG_FLYWHEEL, "LIMITER: fuel cut at %.0f RPM (limit %.0f)",
                             s_fw.w * RADS_TO_RPM, redline_r);
            s_last_lim_log = t;
        }
    }

    int prev_state = g_trans_telem.flywheel_state;
    if (pedal > 0.0f) {
        fw_set_state(1);
    } else if (s_fw.w > w_idle * 1.02f) {
        fw_set_state(2);
    } else {
        fw_set_state(0);
        if (s_fw.w > w_idle * 0.98f) {
            s_fw.active = 0;
            trans_flight_log(TRANS_LOG_FLYWHEEL, "HANDOFF: settled at %.0f RPM (idle %.0f), SCS idle control",
                             s_fw.w * RADS_TO_RPM, idle_r);
        }
    }
    if (g_trans_telem.flywheel_state != prev_state && s_fw.active) {
        static const char *names[] = { "IDLE", "FREE-REV", "FUEL-CUT" };
        trans_flight_log(TRANS_LOG_FLYWHEEL, "STATE: %s -> %s | rpm=%.0f pedal=%.2f t_air=%.0fNm",
                         names[(prev_state >= 0 && prev_state <= 2) ? prev_state : 0],
                         names[g_trans_telem.flywheel_state],
                         s_fw.w * RADS_TO_RPM, pedal_in, s_fw.t_air);
    }
    return s_fw.w;
}

static void flywheel_neutral_tick_qpc(float *p_angvel, float pedal_in, float idle_r, float redline_r)
{
    static LARGE_INTEGER freq;
    LARGE_INTEGER now;
    if (!freq.QuadPart) QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&now);
    float dt = s_fw.last_qpc.QuadPart
             ? (float)(now.QuadPart - s_fw.last_qpc.QuadPart) / (float)freq.QuadPart
             : 0.0f;
    s_fw.last_qpc = now;
    if (dt <= 0.0f || dt > 0.25f) {
        s_fw.active = 0;
        return;
    }
    *p_angvel = fw_step(*p_angvel, pedal_in, idle_r, redline_r, dt);
}

#define PAT_RPM_STEP        "F3 0F 10 8B AC 02 00 00 F3 0F 10 53 20"
#define OFF_PHYS_INNER      0x10
#define OFF_PHYS_DT         0x20
#define OFF_PHYS_ENG_DATA   0x360
#define OFF_DATA_IDLE_RPM   0x230

typedef float (*rpm_step_fn)(void *engine_phys, float clutch_engagement);
static rpm_step_fn o_rpm_step;
static int         g_fw_hooked;

static float hook_rpm_step(void *engine_phys, float clutch_engagement)
{
    float base = o_rpm_step(engine_phys, clutch_engagement);
    if (!engine_phys) return base;

    char *ep = (char *)engine_phys;
    char *inner = *(char **)(ep + OFF_PHYS_INNER);
    if (!inner) return base;
    s_last_phys = ep;

    int gear = *(int32_t *)(inner + OFF_GEAR);
    g_trans_telem.gear = gear;

    static ULONGLONG s_stat_t0 = 0;
    static int s_calls = 0, s_calls_n = 0, s_calls_n_clutch = 0, s_calls_bad_dt = 0;
    static float s_last_h = 0.0f, s_last_clutch = 0.0f;
    float h = *(float *)(ep + OFF_PHYS_DT);
    ULONGLONG now = GetTickCount64();
    s_calls++;
    if (gear == 0) {
        s_calls_n++;
        if (clutch_engagement > 0.05f) s_calls_n_clutch++;
        if (!(h > 0.0f && h < 0.1f)) s_calls_bad_dt++;
    }
    s_last_h = h;
    s_last_clutch = clutch_engagement;
    if (s_stat_t0 == 0) {
        s_stat_t0 = now;
        trans_flight_log(TRANS_LOG_FLYWHEEL, "HOOK: first rpm step call | gear=%d clutch=%.2f h=%.4fs rpm=%.0f",
                         gear, clutch_engagement, h, *(float *)(ep + OFF_ANGVEL) * RADS_TO_RPM);
    } else if (now - s_stat_t0 >= 1000) {
        if (0 && 0 && gear == 0) {
            trans_flight_log(TRANS_LOG_FLYWHEEL,
                "STATS: calls/s=%d in_N=%d N_clutch>0.05=%d bad_dt=%d | last h=%.4fs clutch=%.2f | sdk_thr=%.2f(seen=%d) mem_thr=%.2f",
                s_calls, s_calls_n, s_calls_n_clutch, s_calls_bad_dt, s_last_h, s_last_clutch,
                s_sdk_throttle, s_sdk_throttle_seen, g_trans_telem.raw_throttle);
        }
        s_stat_t0 = now;
        s_calls = s_calls_n = s_calls_n_clutch = s_calls_bad_dt = 0;
    }

    if (gear != 0) {
        s_fw.active = 0;
        return base;
    }

    if (!cfg.enabled || clutch_engagement > 0.05f) {
        if (!cfg.enabled) { s_fw.active = 0; fw_set_state(0); }
        return base;
    }

    if (!(h > 0.0f && h < 0.1f)) return base;

    float idle_r = (g_trans_telem.idle_rpm > 300.0f) ? g_trans_telem.idle_rpm : 750.0f;
    float red_r  = (g_trans_telem.rpm_limit > 1000.0f) ? g_trans_telem.rpm_limit : 6900.0f;
    char *eng_data = *(char **)(ep + OFF_PHYS_ENG_DATA);
    if (eng_data) {
        float id = *(float *)(eng_data + OFF_DATA_IDLE_RPM);
        float lm = *(float *)(eng_data + OFF_RPM_LIMIT);
        if (id >= 300.0f && id <= 2500.0f) { idle_r = id; g_trans_telem.idle_rpm = id; }
        if (lm > 1000.0f && lm < RPM_LIMIT_MAX) { red_r = lm; g_trans_telem.rpm_limit = lm; }
    }

    static float s_kbd_hold = 0.0f;
    static int   s_kbd_full = 0;
    float pedal_raw = s_sdk_throttle_seen ? s_sdk_throttle : g_trans_telem.raw_throttle;
    if (fabsf(pedal_raw - 0.50f) <= 0.002f) {
        s_kbd_hold += h;
        if (!s_kbd_full && s_kbd_hold >= 0.08f) {
            s_kbd_full = 1;
            trans_flight_log(TRANS_LOG_FLYWHEEL, "KEYBOARD: throttle plateau 0.50 held %.2fs -> full throttle in N", s_kbd_hold);
        }
    } else {
        s_kbd_hold = 0.0f;
        s_kbd_full = 0;
    }
    float pedal  = s_kbd_full ? 1.0f : pedal_raw;
    float w_game = *(float *)(ep + OFF_ANGVEL);
    float w_new  = fw_step(w_game, pedal, idle_r, red_r, h);
    float result = s_fw.active ? w_new : base;

    static ULONGLONG s_last_fw_log = 0;
    if (0 && (s_fw.active || pedal > FW_PEDAL_DEAD) && now - s_last_fw_log >= 100) {
        trans_flight_log(TRANS_LOG_FLYWHEEL,
            "pedal=%.2f raw=%.3f kbd=%d rpm_game=%.0f rpm_base=%.0f rpm_out=%.0f t_air=%.0fNm h=%.4fs idle=%.0f lim=%.0f J=%.2f state=%d active=%d",
            pedal, pedal_raw, s_kbd_full, w_game * RADS_TO_RPM, base * RADS_TO_RPM, result * RADS_TO_RPM, s_fw.t_air, h,
            idle_r, red_r, cfg.flywheel_inertia, g_trans_telem.flywheel_state, s_fw.active);
        s_last_fw_log = now;
    }
    return result;
}

static const char *flywheel_hook_install(void)
{
    uintptr_t hits[8], lo, hi;
    int n = pat_scan(PAT_RPM_STEP, hits, 8);
    if (n < 1) return "rpm step pattern";
    if (!func_extent(hits[0], &lo, &hi)) return "rpm step extent";
    MH_STATUS s = MH_Initialize();
    if (s != MH_OK && s != MH_ERROR_ALREADY_INITIALIZED) return "MH_Initialize";
    if (MH_CreateHook((LPVOID)lo, (LPVOID)&hook_rpm_step, (LPVOID *)&o_rpm_step) != MH_OK) return "MH_CreateHook";
    if (MH_EnableHook((LPVOID)lo) != MH_OK) return "MH_EnableHook";
    g_fw_hooked = 1;
    trans_flight_log(TRANS_LOG_INFO, "[FLYWHEEL] rpm step hook installed at +0x%llx (%d pattern hit(s))",
                     (unsigned long long)(lo - g_base), n);
    return NULL;
}

static void dsg_tick(void *self, float *p_engine_angvel, float turbine_rpm, float engine_raw_torque,
                     int cur_gear, float throttle, float brake, int mode, float dt)
{
    float engine_rpm = (p_engine_angvel) ? (*p_engine_angvel * RADS_TO_RPM) : 0.0f;

    if (mode == 1) {
        g_dsg.t_crossover    = 0.08f;
        g_dsg.t_inertia      = 0.05f;
        g_dsg.torque_cut_pct = 0.00f;
        g_dsg.blip_factor    = 0.85f;
        g_dsg.j_engine       = (cfg.flywheel_inertia > 0.02f) ? cfg.flywheel_inertia : 0.10f;
        g_dsg.flywheel_inertia   = (cfg.flywheel_inertia > 0.02f) ? cfg.flywheel_inertia : 0.10f;
        g_dsg.flywheel_response  = (cfg.flywheel_response > 0.10f) ? cfg.flywheel_response : 2.40f;
        g_dsg.flywheel_drop_rate = (cfg.flywheel_drop_rate > 0.10f) ? cfg.flywheel_drop_rate : 1.60f;
    } else if (mode == 2) {
        g_dsg.t_crossover    = 0.40f;
        g_dsg.t_inertia      = 0.30f;
        g_dsg.torque_cut_pct = 0.60f;
        g_dsg.blip_factor    = 0.45f;
        g_dsg.j_engine       = (cfg.flywheel_inertia > 0.02f) ? cfg.flywheel_inertia : 0.25f;
        g_dsg.flywheel_inertia   = (cfg.flywheel_inertia > 0.02f) ? cfg.flywheel_inertia : 0.25f;
        g_dsg.flywheel_response  = (cfg.flywheel_response > 0.10f) ? cfg.flywheel_response : 1.00f;
        g_dsg.flywheel_drop_rate = (cfg.flywheel_drop_rate > 0.10f) ? cfg.flywheel_drop_rate : 0.90f;
    } else {
        g_dsg.t_crossover    = 0.20f;
        g_dsg.t_inertia      = 0.15f;
        g_dsg.torque_cut_pct = 0.30f;
        g_dsg.blip_factor    = 0.65f;
        g_dsg.j_engine       = (cfg.flywheel_inertia > 0.02f) ? cfg.flywheel_inertia : 0.18f;
        g_dsg.flywheel_inertia   = (cfg.flywheel_inertia > 0.02f) ? cfg.flywheel_inertia : 0.18f;
        g_dsg.flywheel_response  = (cfg.flywheel_response > 0.10f) ? cfg.flywheel_response : 1.50f;
        g_dsg.flywheel_drop_rate = (cfg.flywheel_drop_rate > 0.10f) ? cfg.flywheel_drop_rate : 1.20f;
    }

    if (g_dsg.phase == DSG_PHASE_STEADY) {
        dsg_update_preselection(self, cur_gear, g_trans_telem.thr_grad, brake, g_trans_telem.speed_kmh);
    }

    if (cur_gear == 0) {
        g_dsg.phase = DSG_PHASE_STEADY;
        g_dsg.k1.pressure = 0.0f; g_dsg.k1.transferred_torque = 0.0f;
        g_dsg.k2.pressure = 0.0f; g_dsg.k2.transferred_torque = 0.0f;
        g_dsg.effective_load   = 0.0f;
        g_dsg.propshaft_torque = 0.0f;
        g_dsg.inertia_kick_nm  = 0.0f;
        g_dsg.active_blip_nm   = 0.0f;

        if (g_trans_telem.idle_rpm < 300.0f) g_trans_telem.idle_rpm = 750.0f;
        if (g_trans_telem.rpm_limit < 1000.0f) g_trans_telem.rpm_limit = 6900.0f;

        float raw_thr = g_trans_telem.raw_throttle;
        if (raw_thr <= 0.001f && s_sdk_throttle > 0.001f) {
            raw_thr = s_sdk_throttle;
            g_trans_telem.raw_throttle = raw_thr;
        }

        float *p_angvel = p_engine_angvel;
        if (!p_angvel && s_last_phys) {
            p_angvel = (float *)(s_last_phys + OFF_ANGVEL);
        }

        if (p_angvel && !g_fw_hooked) {

            float pedal = s_sdk_throttle_seen ? s_sdk_throttle : raw_thr;
            float idle_r    = (g_trans_telem.idle_rpm > 300.0f) ? g_trans_telem.idle_rpm : 750.0f;
            float redline_r = (g_trans_telem.rpm_limit > 1000.0f) ? g_trans_telem.rpm_limit : 6900.0f;
            flywheel_neutral_tick_qpc(p_angvel, pedal, idle_r, redline_r);
        }
        return;
    }
    s_fw.active = 0;
    g_dsg.flywheel_state = 0;

    if ((cur_gear == 1 || cur_gear == -1) && g_trans_telem.speed_kmh < 12.0f) {
        g_dsg.phase = DSG_PHASE_LAUNCH_CREEP;

        float ratio = dsg_get_gear_ratio(self, cur_gear);
        dsg_clutch_t *act_k   = (cur_gear == 1) ? &g_dsg.k1 : &g_dsg.k2;
        dsg_clutch_t *inact_k = (cur_gear == 1) ? &g_dsg.k2 : &g_dsg.k1;

        inact_k->pressure = 0.0f;
        inact_k->transferred_torque = 0.0f;
        g_dsg.active_clutch = (cur_gear == 1) ? 1 : 2;

        float thr_val = (g_trans_telem.raw_throttle > 0.01f) ? g_trans_telem.raw_throttle : throttle;

        if (brake > 0.50f) {
            g_dsg.is_decoupled = 1;
        } else if (!g_dsg.is_decoupled) {
            if (brake > 0.15f && g_trans_telem.speed_kmh < 1.5f) {
                g_dsg.is_decoupled = 1;
            }
        } else {
            if (brake < 0.05f || (thr_val > 0.05f && brake <= 0.15f) || g_trans_telem.speed_kmh >= 2.0f) {
                g_dsg.is_decoupled = 0;
            }
        }

        if (g_dsg.is_decoupled || brake > 0.50f) {
            act_k->pressure = 0.0f;
            act_k->transferred_torque = 0.0f;
            g_dsg.effective_load   = 0.0f;
            g_dsg.propshaft_torque = 0.0f;
            g_dsg.inertia_kick_nm  = 0.0f;
            g_dsg.active_blip_nm   = 0.0f;
            return;
        }

        float creep_target = (mode == 1) ? 30.0f : ((mode == 2) ? 15.0f : 22.0f);
        float launch_torque = creep_target + throttle * (engine_raw_torque - creep_target);

        if (brake > 0.05f) {
            float brk_scale = 1.0f - ((brake - 0.05f) / 0.45f);
            if (brk_scale < 0.0f) brk_scale = 0.0f;
            launch_torque *= brk_scale;
        }

        float pressure = launch_torque / (engine_raw_torque + 1.0f);
        if (pressure > 1.0f) pressure = 1.0f;
        if (brake > 0.50f) {
            pressure = 0.0f;
            launch_torque = 0.0f;
        }

        act_k->pressure = pressure;
        act_k->transferred_torque = launch_torque;
        act_k->ratio = ratio;

        g_dsg.effective_load   = launch_torque;
        g_dsg.propshaft_torque = launch_torque * ratio;
        g_dsg.inertia_kick_nm  = 0.0f;
        g_dsg.active_blip_nm   = 0.0f;
        return;
    }

    switch (g_dsg.phase) {
        case DSG_PHASE_STEADY: {
            float ratio = dsg_get_gear_ratio(self, cur_gear);
            if (cur_gear % 2 != 0) {
                g_dsg.k1.pressure = 1.0f;
                g_dsg.k1.transferred_torque = engine_raw_torque;
                g_dsg.k1.ratio = ratio;
                g_dsg.k2.pressure = 0.0f;
                g_dsg.k2.transferred_torque = 0.0f;
                g_dsg.active_clutch = 1;
            } else {
                g_dsg.k2.pressure = 1.0f;
                g_dsg.k2.transferred_torque = engine_raw_torque;
                g_dsg.k2.ratio = ratio;
                g_dsg.k1.pressure = 0.0f;
                g_dsg.k1.transferred_torque = 0.0f;
                g_dsg.active_clutch = 2;
            }
            g_dsg.effective_load   = engine_raw_torque;
            g_dsg.propshaft_torque = engine_raw_torque * ratio;
            g_dsg.inertia_kick_nm  = 0.0f;
            g_dsg.active_blip_nm   = 0.0f;
            break;
        }

        case DSG_PHASE_TORQUE_CROSS: {
            g_dsg.phase_timer += dt;
            float duration = g_dsg.is_skip_shift ? (g_dsg.t_crossover * 1.4f) : g_dsg.t_crossover;
            float t_prog = g_dsg.phase_timer / (duration > 0.01f ? duration : 0.01f);
            if (t_prog > 1.0f) t_prog = 1.0f;

            float blend = 0.5f * (1.0f - cosf(t_prog * 3.14159265f));

            int is_upshift = (g_dsg.shift_to_gear > g_dsg.shift_from_gear);
            float cut = 0.0f;
            int is_ignition_cut = 0;

            if (is_upshift) {
                if (mode == 1) {

                    if (throttle > 0.35f && t_prog >= 0.15f && t_prog <= 0.75f) {
                        cut = 0.85f;
                        is_ignition_cut = 1;
                    }
                } else if (mode == 2) {

                    cut = g_dsg.torque_cut_pct * blend;
                } else {

                    cut = g_dsg.torque_cut_pct * blend;
                }
            }
            g_trans_telem.dsg_ignition_cut = is_ignition_cut;

            static int s_pop_cut_logged = 0;
            if (is_ignition_cut && !s_pop_cut_logged) {
                trans_flight_log(TRANS_LOG_DSG,
                    "[IGNITION-CUT] D%d -> D%d | Cut: 85%% (35ms) | Thr: %.0f%% | RPM: %.0f",
                    g_dsg.shift_from_gear, g_dsg.shift_to_gear, throttle * 100.0f, engine_rpm);
                s_pop_cut_logged = 1;
            }

            float t_active_eng = engine_raw_torque * (1.0f - cut);

            float t_old = t_active_eng * (1.0f - blend);
            float t_new = t_active_eng * blend;

            if (g_dsg.active_clutch == 1) {
                g_dsg.k1.transferred_torque = t_old;
                g_dsg.k2.transferred_torque = t_new;
                g_dsg.k1.pressure = 1.0f - blend;
                g_dsg.k2.pressure = blend;
            } else {
                g_dsg.k2.transferred_torque = t_old;
                g_dsg.k1.transferred_torque = t_new;
                g_dsg.k2.pressure = 1.0f - blend;
                g_dsg.k1.pressure = blend;
            }

            g_dsg.effective_load   = t_old + t_new;
            g_dsg.propshaft_torque = (t_old * g_dsg.ratio_old) + (t_new * g_dsg.ratio_new);

            if (t_prog >= 1.0f) {
                g_dsg.phase = DSG_PHASE_INERTIA;
                g_dsg.phase_timer = 0.0f;
                g_dsg.active_clutch = (g_dsg.active_clutch == 1) ? 2 : 1;
                s_pop_cut_logged = 0;
                g_trans_telem.dsg_ignition_cut = 0;
            }
            break;
        }

        case DSG_PHASE_INERTIA: {
            g_dsg.phase_timer += dt;
            float duration = g_dsg.is_skip_shift ? (g_dsg.t_inertia * 1.4f) : g_dsg.t_inertia;
            float t_prog = g_dsg.phase_timer / (duration > 0.01f ? duration : 0.01f);
            if (t_prog > 1.0f) t_prog = 1.0f;

            float delta_w = (engine_rpm - turbine_rpm) * (3.14159265f / 30.0f);
            float dw_dt   = delta_w / (duration > 0.01f ? duration : 0.01f);
            float active_ratio = (g_dsg.active_clutch == 1) ? g_dsg.k1.ratio : g_dsg.k2.ratio;

            if (delta_w >= 0.0f) {

                float inertia_scale = (mode == 1) ? 1.0f : ((mode == 2) ? 0.40f : 0.70f);
                float inertia_torque = g_dsg.j_engine * dw_dt * inertia_scale;
                g_dsg.inertia_kick_nm  = inertia_torque;
                g_dsg.active_blip_nm   = 0.0f;
                g_dsg.effective_load   = engine_raw_torque + (inertia_torque * 0.5f);
                g_dsg.propshaft_torque = (engine_raw_torque + inertia_torque) * active_ratio;
            } else {

                float target_angvel = turbine_rpm / RADS_TO_RPM;
                float t_rem = (1.0f - t_prog) * duration;
                if (t_rem < 0.01f) t_rem = 0.01f;

                float drag_torque = g_dsg.j_engine * dw_dt;
                float blip_torque = fabsf(drag_torque) * g_dsg.blip_factor;
                g_dsg.active_blip_nm  = blip_torque;
                g_dsg.inertia_kick_nm = drag_torque + blip_torque;

                if (p_engine_angvel && *p_engine_angvel < target_angvel) {
                    float ramp_step = ((target_angvel - *p_engine_angvel) / t_rem) * dt;
                    *p_engine_angvel += ramp_step;
                    if (*p_engine_angvel > target_angvel) {
                        *p_engine_angvel = target_angvel;
                    }
                }

                g_dsg.effective_load   = drag_torque;
                g_dsg.propshaft_torque = (engine_raw_torque + g_dsg.inertia_kick_nm) * active_ratio;
            }

            if (t_prog >= 1.0f || fabsf(engine_rpm - turbine_rpm) < 45.0f) {
                trans_flight_log(TRANS_LOG_DSG,
                    "[DSG] SHIFT DONE: D%d -> D%d%s in %.2fs | RPM: %.0f -> turbine %.0f",
                    g_dsg.shift_from_gear, g_dsg.shift_to_gear, g_dsg.is_skip_shift ? " (same-shaft)" : "",
                    (float)(GetTickCount64() - s_dsg_shift_start_ms) / 1000.0f, engine_rpm, turbine_rpm);
                g_dsg.is_skip_shift = 0;
                g_dsg.phase = DSG_PHASE_STEADY;
                g_dsg.phase_timer = 0.0f;
                g_dsg.inertia_kick_nm = 0.0f;
                g_dsg.active_blip_nm  = 0.0f;
            }
            break;
        }

        default:
            g_dsg.phase = DSG_PHASE_STEADY;
            break;
    }
}

static float     s_last_throttle = 0.0f;
static ULONGLONG s_last_throttle_time = 0;
static ULONGLONG s_fast_off_until = 0;

static void update_fast_off_logic(float cur_thr, float engine_rpm, int cur_gear)
{
    ULONGLONG now = GetTickCount64();
    if (s_last_throttle_time == 0) {
        s_last_throttle = cur_thr;
        s_last_throttle_time = now;
        return;
    }

    float dt = (float)(now - s_last_throttle_time) / 1000.0f;
    if (dt >= 0.020f) {
        float grad = (cur_thr - s_last_throttle) / dt;
        g_trans_telem.thr_grad = grad;

        if (cfg.enabled && cfg.fast_off_hold > 0.0f && cur_gear >= 2) {
            if (s_last_throttle >= 0.25f && cur_thr <= 0.15f && grad <= -1.40f && engine_rpm >= 1200.0f) {
                s_fast_off_until = now + (ULONGLONG)(cfg.fast_off_hold * 1000.0f);
                trans_flight_log(TRANS_LOG_FASTOFF,
                    "FAST-OFF TRIGGERED in D%d: Throttle %.0f%% -> %.0f%% (dThr/dt = %+.2f/s, RPM=%.0f) -> Holding gear for %.2fs",
                    cur_gear, s_last_throttle * 100.0f, cur_thr * 100.0f, grad, engine_rpm, cfg.fast_off_hold);
            }
        }

        s_last_throttle = cur_thr;
        s_last_throttle_time = now;
    }

    if (s_fast_off_until > now) {
        if (cur_thr > 0.12f || (cfg.coast_hold && cur_thr > cfg.coast_thr)) {
            s_fast_off_until = 0;
            trans_flight_log(TRANS_LOG_FASTOFF,
                "FAST-OFF CANCELLED in D%d: Throttle reapplied (%.1f%%)",
                cur_gear, cur_thr * 100.0f);
        } else if (engine_rpm > 0.0f && engine_rpm < 1100.0f) {
            s_fast_off_until = 0;
            trans_flight_log(TRANS_LOG_FASTOFF,
                "FAST-OFF CANCELLED in D%d: Anti-lug protection (RPM=%.0f < 1100 RPM)",
                cur_gear, engine_rpm);
        }
    }

    static int s_prev_fast_off_active = 0;
    if (s_fast_off_until > now) {
        g_trans_telem.fast_off_active = 1;
        g_trans_telem.fast_off_remaining = (float)(s_fast_off_until - now) / 1000.0f;
    } else {
        if (s_prev_fast_off_active && s_fast_off_until == 0) {
            trans_flight_log(TRANS_LOG_FASTOFF, "FAST-OFF EXPIRED in D%d: Hold duration elapsed", cur_gear);
        }
        g_trans_telem.fast_off_active = 0;
        g_trans_telem.fast_off_remaining = 0.0f;
        s_fast_off_until = 0;
    }
    s_prev_fast_off_active = g_trans_telem.fast_off_active;
}

static ULONGLONG s_tip_in_until = 0;
static int       s_was_coasting = 0;
static ULONGLONG s_coast_start_time = 0;
static float     s_last_rpm = 0.0f;
static ULONGLONG s_last_rpm_time = 0;
static float     s_rpm_grad = 0.0f;

static int is_upshift_inhibited(void *s)
{
    if (g_trans_telem.brake > 0.05f) return 1;
    if (is_shift_locked(s, 0)) return 1;
    if (g_trans_telem.fast_off_active) return 1;
    if (g_trans_telem.coast_active) return 1;
    if (g_trans_telem.tip_in_active) return 1;
    return 0;
}

static const char *get_upshift_inhibitor_reason(void *s)
{
    if (g_trans_telem.brake > 0.05f) return "Footbrake Active (Upshift Locked)";
    if (is_shift_locked(s, 0)) return dsg_is_locked() ? "DSG Shift In Progress" : "Inter-Shift Dwell Lock";
    if (g_trans_telem.fast_off_active) return "Fast-Off Hold";
    if (g_trans_telem.coast_downhill) return "Downhill Assist (Engine Braking)";
    if (g_trans_telem.coast_active) return "Coast Hold (Flat Road)";
    if (g_trans_telem.tip_in_active) return "Tip-In Cruise Settling Debounce";
    return "None";
}

static void update_telem_from_self(void *self)
{
    if (self) {
        s_last_self = self;
    } else if (s_last_self) {
        self = s_last_self;
    } else {
        return;
    }

    char *inner = *(char **)((char *)self + OFF_INNER);
    if (inner) {
        s_last_inner = inner;
        char *p = *(char **)(inner + OFF_ENGINE_PHYS);
        if (p) s_last_phys = p;
    } else if (s_last_inner) {
        inner = s_last_inner;
    }

    int raw_g = 0;
    if (inner) {
        raw_g = *(int32_t *)(inner + OFF_GEAR);
    }
    g_trans_telem.gear = raw_g;
    if (raw_g == 0) {
        snprintf(g_trans_telem.gear_str, sizeof(g_trans_telem.gear_str), "N");
    } else if (raw_g < 0) {
        snprintf(g_trans_telem.gear_str, sizeof(g_trans_telem.gear_str), "R %d", -raw_g);
    } else {
        snprintf(g_trans_telem.gear_str, sizeof(g_trans_telem.gear_str), "D %d", raw_g);
    }

    char *base = (char *)self;
    if (base) {
        unsigned long long n = *(unsigned long long *)(base + OFF_STEP_COUNT);
        int rev = *(int32_t *)(base + OFF_REV_GEARS);
        if (n > 0 && n <= 256 && rev >= 0 && (unsigned long long)rev < n) {
            g_trans_telem.forward_gear_count = (int)(n - rev);
            g_trans_telem.reverse_gear_count = rev;
        }
    }

    float raw_thr = 0.0f;
    if (self) {
        float t = *(float *)((char *)self + OFF_THROTTLE);
        if (t >= 0.0f) raw_thr = (t > 1.0f ? 1.0f : t);
    }

    if (raw_thr <= 0.001f && s_sdk_throttle > 0.001f) {
        raw_thr = s_sdk_throttle;
    }
    g_trans_telem.raw_throttle = raw_thr;

    if (g_trans_telem.brake > 0.10f && raw_g != 0) {
        g_trans_telem.bos_active = (raw_thr > 0.05f) ? 1 : 0;
        g_trans_telem.throttle   = 0.0f;
        g_trans_telem.pedal_ramp = 0.0f;
    } else {
        g_trans_telem.bos_active = 0;
        g_trans_telem.throttle   = (raw_g == 0) ? raw_thr : throttle_of(self);
        if (g_trans_telem.throttle <= 0.001f && raw_thr > 0.001f) {
            g_trans_telem.throttle = raw_thr;
        }
        g_trans_telem.pedal_ramp = pedal_ramp(self);
    }

    float lim = rpm_limit_of(self);
    if (lim > 1000.0f) {
        g_trans_telem.rpm_limit = lim;
    } else if (g_trans_telem.rpm_limit < 1000.0f) {
        g_trans_telem.rpm_limit = 6900.0f;
    }

    static int s_bos_logged = 0;
    if (g_trans_telem.bos_active) {
        if (!s_bos_logged) {
            trans_flight_log(TRANS_LOG_INFO,
                "[BOS] Brake Override System ACTIVATED: Raw throttle %.1f%% overridden to 0.0%% (Brake: %.1f%%)",
                g_trans_telem.raw_throttle * 100.0f, g_trans_telem.brake * 100.0f);
            s_bos_logged = 1;
        }
    } else {
        if (s_bos_logged && g_trans_telem.brake <= 0.08f) {
            trans_flight_log(TRANS_LOG_INFO,
                "[BOS] Brake Override System RELEASED: Brake %.1f%%, throttle restored",
                g_trans_telem.brake * 100.0f);
            s_bos_logged = 0;
        }
    }

    if (inner && o_resolve) {
        void *handle = *(void **)(inner + OFF_ENGINE_HANDLE);
        if (handle) {
            char *eng = (char *)o_resolve(handle);
            if (eng) {
                float idle = *(float *)(eng + 0x230);
                if (idle >= 300.0f && idle <= 2500.0f) {
                    g_trans_telem.idle_rpm = idle;
                }
                float eng_lim = *(float *)(eng + OFF_RPM_LIMIT);
                if (eng_lim > 1000.0f && eng_lim < 20000.0f) {
                    g_trans_telem.rpm_limit = eng_lim;
                }
            }
        }
    }
    if (g_trans_telem.idle_rpm < 300.0f) {
        g_trans_telem.idle_rpm = 750.0f;
    }
    if (g_trans_telem.rpm_limit < 1000.0f) {
        g_trans_telem.rpm_limit = 6900.0f;
    }

    float live_rpm = engine_rpm_of(self);
    if (live_rpm > 10.0f) {
        g_trans_telem.engine_rpm = live_rpm;
    } else if (g_trans_telem.engine_rpm <= 10.0f) {

        if (raw_g != 0 && g_trans_telem.speed_kmh > 1.0f) {
            int abs_g = raw_g < 0 ? -raw_g : raw_g;
            float base = (g_trans_telem.idle_rpm >= 500.0f) ? g_trans_telem.idle_rpm : 750.0f;
            g_trans_telem.engine_rpm = base + (g_trans_telem.speed_kmh * 28.0f / (float)abs_g);
            if (g_trans_telem.rpm_limit > 1000.0f && g_trans_telem.engine_rpm >= g_trans_telem.rpm_limit) {
                g_trans_telem.engine_rpm = g_trans_telem.rpm_limit * 0.95f;
            }
        } else if (g_trans_telem.speed_kmh <= 1.0f && g_trans_telem.engine_enabled) {
            g_trans_telem.engine_rpm = (g_trans_telem.idle_rpm >= 500.0f) ? g_trans_telem.idle_rpm : 750.0f;
        }
    }

    static int s_rpm_diag_done = 0;
    if (s_rpm_diag_done < 3) {
        char *p_phys = inner ? *(char **)(inner + OFF_ENGINE_PHYS) : NULL;
        float w_raw = p_phys ? *(float *)(p_phys + OFF_ANGVEL) : 0.0f;
        trans_flight_log(TRANS_LOG_INFO,
            "[RPM_DIAG #%d] self=%p, inner=%p, phys=%p, w_raw=%.2f rad/s (%.1f RPM), engine_rpm=%.1f",
            s_rpm_diag_done + 1, self, inner, p_phys, w_raw, w_raw * RADS_TO_RPM, g_trans_telem.engine_rpm);
        s_rpm_diag_done++;
    }

    ULONGLONG now = GetTickCount64();

    static float s_last_speed_ms = 0.0f;
    static ULONGLONG s_last_accel_time = 0;
    if (s_last_accel_time == 0) {
        s_last_speed_ms = g_trans_telem.speed_kmh / 3.6f;
        s_last_accel_time = now;
        g_trans_telem.accel_mps2 = 0.0f;
        g_trans_telem.accel_g = 0.0f;
    } else {
        ULONGLONG dt_acc = now - s_last_accel_time;
        if (dt_acc >= 80) {
            float dt_s = (float)dt_acc / 1000.0f;
            float cur_speed_ms = g_trans_telem.speed_kmh / 3.6f;
            float raw_accel = (cur_speed_ms - s_last_speed_ms) / dt_s;
            g_trans_telem.accel_mps2 = (g_trans_telem.accel_mps2 * 0.60f) + (raw_accel * 0.40f);
            g_trans_telem.accel_g = g_trans_telem.accel_mps2 / 9.80665f;
            s_last_speed_ms = cur_speed_ms;
            s_last_accel_time = now;
        }
    }

    static int s_last_logged_gear = -999;
    if (s_last_logged_gear == -999) {
        s_last_logged_gear = raw_g;
    } else if (raw_g != s_last_logged_gear) {
        int old_g = s_last_logged_gear;
        int new_g = raw_g;
        if (g_dsg.phase == DSG_PHASE_STEADY) {
            dsg_trigger_shift(self, old_g, new_g);
        }
        char old_g_str[16], new_g_str[16];
        if (s_last_logged_gear == 0) snprintf(old_g_str, sizeof(old_g_str), "N");
        else if (s_last_logged_gear < 0) snprintf(old_g_str, sizeof(old_g_str), "R %d", -s_last_logged_gear);
        else snprintf(old_g_str, sizeof(old_g_str), "D %d", s_last_logged_gear);

        if (raw_g == 0) snprintf(new_g_str, sizeof(new_g_str), "N");
        else if (raw_g < 0) snprintf(new_g_str, sizeof(new_g_str), "R %d", -raw_g);
        else snprintf(new_g_str, sizeof(new_g_str), "D %d", raw_g);

        char steer_buf[16] = "0%";
        if (g_trans_telem.steering > 0.03f) snprintf(steer_buf, sizeof(steer_buf), "R%.0f%%", g_trans_telem.steering * 100.0f);
        else if (g_trans_telem.steering < -0.03f) snprintf(steer_buf, sizeof(steer_buf), "L%.0f%%", -g_trans_telem.steering * 100.0f);

        char cc_buf[16] = "OFF";
        if (g_trans_telem.cruise_control_kmh > 1.0f) snprintf(cc_buf, sizeof(cc_buf), "%.0fkmh", g_trans_telem.cruise_control_kmh);

        char thr_buf[32];
        if (g_trans_telem.bos_active) {
            snprintf(thr_buf, sizeof(thr_buf), "0.0%% (BOS)");
        } else {
            snprintf(thr_buf, sizeof(thr_buf), "%4.1f%%", g_trans_telem.throttle * 100.0f);
        }

        trans_flight_log(TRANS_LOG_SHIFT,
            "GEAR SHIFT: %s -> %s (of %d) | Spd: %5.1f km/h (%+4.1fm/s²) | RPM: %4.0f | Thr: %s (Ramp: %.2f) | Brk: %4.1f%% | Steer: %s | CC: %s | Win: [%.0f..%.0f] | Mode: %s",
            old_g_str, new_g_str, g_trans_telem.forward_gear_count,
            g_trans_telem.speed_kmh, g_trans_telem.accel_mps2, g_trans_telem.engine_rpm,
            thr_buf, g_trans_telem.pedal_ramp,
            g_trans_telem.brake * 100.0f, steer_buf, cc_buf,
            g_trans_telem.win_min_rpm, g_trans_telem.win_max_rpm,
            trans_get_mode_name(trans_get_current_mode_idx()));

        int gear_diff = s_last_logged_gear - raw_g;
        if (is_panic_braking() && gear_diff >= 2 && raw_g > 0) {
            trans_flight_log(TRANS_LOG_SHIFT,
                "BLOCK DOWNSHIFT: D%d -> D%d (skipped %d gears) | Spd: %.1f km/h | Decel: %.1f m/s² | Brk: %.0f%%",
                s_last_logged_gear, raw_g, gear_diff, g_trans_telem.speed_kmh, g_trans_telem.accel_mps2, g_trans_telem.brake * 100.0f);
        }
        s_last_logged_gear = raw_g;
    }

    char *p_phys_dsg = inner ? *(char **)(inner + OFF_ENGINE_PHYS) : NULL;
    if (!p_phys_dsg && s_last_phys) p_phys_dsg = s_last_phys;
    float *p_angvel_dsg = p_phys_dsg ? (float *)(p_phys_dsg + OFF_ANGVEL) : NULL;
    float live_turb_rpm = (p_phys_dsg && *(float *)(p_phys_dsg + 0x2ec) > 0.0f)
                          ? (*(float *)(p_phys_dsg + 0x2ec) * RADS_TO_RPM)
                          : (g_trans_telem.speed_kmh * 28.0f / (float)(raw_g == 0 ? 1 : (raw_g < 0 ? -raw_g : raw_g)));
    float raw_eng_torque = 500.0f * g_trans_telem.raw_throttle;
    if (raw_eng_torque < 25.0f) raw_eng_torque = 25.0f;

    static ULONGLONG s_last_dsg_time = 0;
    float dt_dsg = 0.016f;
    if (s_last_dsg_time != 0 && now > s_last_dsg_time) {
        dt_dsg = (float)(now - s_last_dsg_time) / 1000.0f;
        if (dt_dsg > 0.1f) dt_dsg = 0.016f;
    }
    s_last_dsg_time = now;

    dsg_tick(self, p_angvel_dsg, live_turb_rpm, raw_eng_torque,
             raw_g, g_trans_telem.throttle, g_trans_telem.brake,
             trans_get_current_mode_idx(), dt_dsg);

    g_trans_telem.flywheel_state       = g_dsg.flywheel_state;
    g_trans_telem.dsg_k1_pressure      = g_dsg.k1.pressure;
    g_trans_telem.dsg_k2_pressure      = g_dsg.k2.pressure;
    g_trans_telem.dsg_k1_torque        = g_dsg.k1.transferred_torque;
    g_trans_telem.dsg_k2_torque        = g_dsg.k2.transferred_torque;
    g_trans_telem.dsg_active_clutch    = g_dsg.active_clutch;
    g_trans_telem.dsg_preselected_gear = g_dsg.preselected_gear;
    g_trans_telem.dsg_phase            = (int)g_dsg.phase;
    float diff_r = dsg_get_diff_ratio(self);
    g_trans_telem.dsg_propshaft_torque = g_dsg.propshaft_torque;
    g_trans_telem.dsg_diff_ratio       = diff_r;
    g_trans_telem.dsg_wheel_torque     = g_dsg.propshaft_torque * diff_r;
    g_trans_telem.dsg_inertia_kick_nm  = g_dsg.inertia_kick_nm;
    g_trans_telem.dsg_active_blip_nm   = g_dsg.active_blip_nm;
    g_trans_telem.dsg_is_skip_shift    = g_dsg.is_skip_shift;

    const char *ph_str = "STEADY";
    switch (g_dsg.phase) {
        case DSG_PHASE_TORQUE_CROSS: ph_str = g_trans_telem.dsg_ignition_cut ? "IGNITION CUT" : "TORQUE-CROSSOVER"; break;
        case DSG_PHASE_INERTIA:      ph_str = (g_dsg.shift_to_gear > g_dsg.shift_from_gear) ? "INERTIA (BOOST)" : "INERTIA (REV-MATCH)"; break;
        case DSG_PHASE_LAUNCH_CREEP: ph_str = g_dsg.is_decoupled ? "STAND DECOUPLED" : "CREEP / DRIVE"; break;
        default:                     ph_str = "STEADY"; break;
    }
    snprintf(g_trans_telem.dsg_phase_str, sizeof(g_trans_telem.dsg_phase_str), "%s", ph_str);

    ULONGLONG dt = since_shift(self);
    if (dt != (ULONGLONG)-1) {
        g_trans_telem.time_since_shift = (float)dt / 1000.0f;
    } else {
        g_trans_telem.time_since_shift = 99.0f;
    }

    g_trans_telem.upshift_locked       = is_shift_locked(self, 0);
    g_trans_telem.downshift_locked     = is_shift_locked(self, 1);
    g_trans_telem.inter_shift_locked   = is_shift_locked(self, 0) || is_shift_locked(self, 1);
    g_trans_telem.inter_shift_remaining = get_shift_lock_remaining(self, 0);
    g_trans_telem.brake_locked         = (g_trans_telem.brake > 0.05f);
    g_trans_telem.active               = 1;
    g_last_telem_tick                  = now;

    update_fast_off_logic(g_trans_telem.throttle, g_trans_telem.engine_rpm, raw_g);

    now = GetTickCount64();

    if (s_last_rpm_time == 0) {
        s_last_rpm = g_trans_telem.engine_rpm;
        s_last_rpm_time = now;
        s_rpm_grad = 0.0f;
    } else {
        ULONGLONG dt_rpm = now - s_last_rpm_time;
        if (dt_rpm >= 80) {
            float dt_s = (float)dt_rpm / 1000.0f;
            float raw_grad = (g_trans_telem.engine_rpm - s_last_rpm) / dt_s;
            s_rpm_grad = (s_rpm_grad * 0.60f) + (raw_grad * 0.40f);
            s_last_rpm = g_trans_telem.engine_rpm;
            s_last_rpm_time = now;
        }
    }
    g_trans_telem.rpm_grad = s_rpm_grad;

    typedef enum {
        COAST_STATE_NORMAL  = 0,
        COAST_STATE_HOLD    = 1,
        COAST_STATE_TIPIN   = 2,
        COAST_STATE_EXPIRED = 3
    } coast_state_t;

    static coast_state_t s_cstate = COAST_STATE_NORMAL;
    static ULONGLONG s_last_coast_time = 0;
    static float s_coast_rem = 0.0f;
    static int s_prev_downhill = 0;
    static int s_was_driving = 0;

    static ULONGLONG s_downhill_candidate_start = 0;
    static ULONGLONG s_downhill_clear_start = 0;
    static int s_downhill_confirmed = 0;

    ULONGLONG dt_shift = since_shift(self);
    int shift_settled = (dt_shift != (ULONGLONG)-1 && dt_shift >= 1000);

    int downhill_candidate = (raw_g >= 2 &&
                              g_trans_telem.speed_kmh > 30.0f &&
                              shift_settled &&
                              g_trans_telem.throttle <= cfg.coast_thr &&
                              g_trans_telem.brake <= 0.05f &&
                              g_trans_telem.engine_rpm >= 1150.0f &&
                              s_rpm_grad >= -18.0f);

    if (downhill_candidate) {
        s_downhill_clear_start = 0;
        if (s_downhill_candidate_start == 0) {
            s_downhill_candidate_start = now;
        } else if (now - s_downhill_candidate_start >= 700) {
            s_downhill_confirmed = 1;
        }
    } else {
        s_downhill_candidate_start = 0;

        if (g_trans_telem.throttle > cfg.coast_thr || g_trans_telem.brake > 0.05f || raw_g < 2 || g_trans_telem.speed_kmh < 25.0f) {
            s_downhill_confirmed = 0;
            s_downhill_clear_start = 0;
        } else {

            if (s_downhill_clear_start == 0) {
                s_downhill_clear_start = now;
            } else if (now - s_downhill_clear_start >= 400) {
                s_downhill_confirmed = 0;
            }
        }
    }

    int is_downhill = s_downhill_confirmed;

    if (s_last_coast_time == 0) s_last_coast_time = now;
    float dt_coast_s = (float)(now - s_last_coast_time) / 1000.0f;
    s_last_coast_time = now;
    if (dt_coast_s < 0.0f || dt_coast_s > 1.0f) dt_coast_s = 0.0f;

    if (g_trans_telem.throttle > cfg.coast_thr) {
        s_was_driving = 1;
    }

    switch (s_cstate) {
        case COAST_STATE_NORMAL:
            g_trans_telem.coast_active   = 0;
            g_trans_telem.coast_downhill = 0;
            g_trans_telem.coast_remaining = 0.0f;
            g_trans_telem.tip_in_active  = 0;
            g_trans_telem.tip_in_remaining = 0.0f;
            s_prev_downhill = 0;
            s_downhill_confirmed = 0;
            s_downhill_candidate_start = 0;
            s_downhill_clear_start = 0;

            if (s_was_driving && cfg.enabled && cfg.coast_hold && raw_g >= 2 && g_trans_telem.throttle <= cfg.coast_thr && g_trans_telem.speed_kmh >= 10.0f) {
                if (cfg.max_coast_gear <= 0 || raw_g >= cfg.max_coast_gear) {
                    s_cstate = COAST_STATE_HOLD;
                    s_coast_rem = cfg.coast_timeout;
                    s_was_driving = 0;
                    g_trans_telem.coast_active = 1;
                    g_trans_telem.coast_remaining = s_coast_rem;
                    trans_flight_log(TRANS_LOG_COAST,
                        "COAST HOLD STARTED in %s: Throttle %.1f%% <= %.1f%% | Spd: %.1f km/h | RPM: %.0f | Timeout: %.1fs",
                        g_trans_telem.gear_str, g_trans_telem.throttle * 100.0f, cfg.coast_thr * 100.0f,
                        g_trans_telem.speed_kmh, g_trans_telem.engine_rpm, cfg.coast_timeout);
                }
            }
            break;

        case COAST_STATE_HOLD:

            if (g_trans_telem.rpm_limit > 1000.0f && g_trans_telem.engine_rpm >= (g_trans_telem.rpm_limit - 250.0f)) {
                s_cstate = COAST_STATE_NORMAL;
                trans_flight_log(TRANS_LOG_COAST, "COAST HOLD RELEASED in %s: Overrev protection (RPM %.0f near limit)",
                                 g_trans_telem.gear_str, g_trans_telem.engine_rpm);
                break;
            }

            if (g_trans_telem.throttle > cfg.coast_thr) {
                if (g_trans_telem.throttle <= 0.35f && cfg.tip_in_delay > 0.0f && raw_g >= 2) {
                    s_cstate = COAST_STATE_TIPIN;
                    s_tip_in_until = now + (ULONGLONG)(cfg.tip_in_delay * 1000.0f);
                    g_trans_telem.coast_active = 0;
                    g_trans_telem.coast_downhill = 0;
                    g_trans_telem.tip_in_active = 1;
                    g_trans_telem.tip_in_remaining = cfg.tip_in_delay;
                    trans_flight_log(TRANS_LOG_TIPIN,
                        "TIP-IN DEBOUNCE STARTED in %s: Throttle %.1f%% > %.1f%% | Delaying overdrive by %.2fs to settle cruise | Spd: %.1f km/h | RPM: %.0f",
                        g_trans_telem.gear_str, g_trans_telem.throttle * 100.0f, cfg.coast_thr * 100.0f,
                        cfg.tip_in_delay, g_trans_telem.speed_kmh, g_trans_telem.engine_rpm);
                } else {
                    s_cstate = COAST_STATE_NORMAL;
                    trans_flight_log(TRANS_LOG_COAST,
                        "COAST HOLD ENDED in %s: Throttle %.1f%% > 35%% (Accelerating) | Spd: %.1f km/h",
                        g_trans_telem.gear_str, g_trans_telem.throttle * 100.0f, g_trans_telem.speed_kmh);
                }
                break;
            }

            g_trans_telem.coast_active = 1;
            if (is_downhill) {
                g_trans_telem.coast_downhill = 1;
                s_coast_rem = cfg.coast_timeout;
                if (!s_prev_downhill) {
                    trans_flight_log(TRANS_LOG_DOWNHILL,
                        "DOWNHILL DETECTED in %s: Momentum / Grade hold (dRPM/dt = %+.1f RPM/s >= -18.0 sustained >= 0.7s) at %.0f RPM | Holding for engine braking | Spd: %.1f km/h",
                        g_trans_telem.gear_str, s_rpm_grad, g_trans_telem.engine_rpm, g_trans_telem.speed_kmh);
                }
            } else {
                g_trans_telem.coast_downhill = 0;
                if (s_prev_downhill) {
                    trans_flight_log(TRANS_LOG_DOWNHILL,
                        "DOWNHILL CLEARED in %s: Flat road resumed | Flat timeout (%.1fs remaining)",
                        g_trans_telem.gear_str, s_coast_rem);
                }

                if (g_trans_telem.brake > 0.05f) {

                } else if (cfg.coast_timeout > 0.0f) {
                    s_coast_rem -= dt_coast_s;
                    if (s_coast_rem <= 0.0f) {
                        s_coast_rem = 0.0f;
                        trans_flight_log(TRANS_LOG_COAST,
                            "COAST TIMEOUT EXPIRED in %s: Flat road %.1fs reached -> Releasing overdrive hold (upshift permitted) | Spd: %.1f km/h",
                            g_trans_telem.gear_str, cfg.coast_timeout, g_trans_telem.speed_kmh);
                        s_cstate = COAST_STATE_EXPIRED;
                        g_trans_telem.coast_active = 0;
                        g_trans_telem.coast_downhill = 0;
                        g_trans_telem.coast_remaining = 0.0f;
                    }
                }
            }
            s_prev_downhill = is_downhill;
            g_trans_telem.coast_remaining = s_coast_rem;
            break;

        case COAST_STATE_TIPIN:
            g_trans_telem.coast_active = 0;
            g_trans_telem.coast_downhill = 0;
            g_trans_telem.coast_remaining = 0.0f;
            g_trans_telem.tip_in_active = 1;

            if (g_trans_telem.throttle <= cfg.coast_thr) {
                s_cstate = COAST_STATE_HOLD;
                s_coast_rem = cfg.coast_timeout;
                g_trans_telem.tip_in_active = 0;
                g_trans_telem.tip_in_remaining = 0.0f;
                trans_flight_log(TRANS_LOG_TIPIN,
                    "TIP-IN RETURNED TO COAST in %s: Throttle dropped back to %.1f%% | Spd: %.1f km/h",
                    g_trans_telem.gear_str, g_trans_telem.throttle * 100.0f, g_trans_telem.speed_kmh);
                break;
            }

            if (g_trans_telem.throttle > 0.35f) {
                s_cstate = COAST_STATE_NORMAL;
                g_trans_telem.tip_in_active = 0;
                g_trans_telem.tip_in_remaining = 0.0f;
                trans_flight_log(TRANS_LOG_TIPIN,
                    "TIP-IN CANCELLED in %s: Throttle reached %.1f%% > 35%% (Accelerating) | Spd: %.1f km/h",
                    g_trans_telem.gear_str, g_trans_telem.throttle * 100.0f, g_trans_telem.speed_kmh);
                break;
            }

            if (now >= s_tip_in_until) {
                s_cstate = COAST_STATE_NORMAL;
                g_trans_telem.tip_in_active = 0;
                g_trans_telem.tip_in_remaining = 0.0f;
                trans_flight_log(TRANS_LOG_TIPIN,
                    "TIP-IN SETTLED in %s: Cruise debounce (%.2fs) elapsed -> Overdrive upshift unlocked! | Spd: %.1f km/h | RPM: %.0f",
                    g_trans_telem.gear_str, cfg.tip_in_delay, g_trans_telem.speed_kmh, g_trans_telem.engine_rpm);
                break;
            }

            g_trans_telem.tip_in_remaining = (float)(s_tip_in_until - now) / 1000.0f;
            break;

        case COAST_STATE_EXPIRED:

            g_trans_telem.coast_active   = 0;
            g_trans_telem.coast_downhill = 0;
            g_trans_telem.coast_remaining = 0.0f;
            g_trans_telem.tip_in_active  = 0;
            g_trans_telem.tip_in_remaining = 0.0f;

            if (g_trans_telem.throttle > cfg.coast_thr) {
                s_cstate = COAST_STATE_NORMAL;
                break;
            }

            if (g_trans_telem.speed_kmh < 5.0f || raw_g < 2) {
                s_cstate = COAST_STATE_NORMAL;
                break;
            }
            break;
    }

    if (0 && 0 && 0.0f > 0.0f) {
        static ULONGLONG s_last_telem_snap = 0;
        if (now - s_last_telem_snap >= (ULONGLONG)(0.0f * 1000.0f)) {
            if (g_trans_telem.engine_rpm > 100.0f || g_trans_telem.speed_kmh > 0.5f || raw_g != 0) {
                char state_buf[64] = "NORMAL";
                if (g_trans_telem.brake_locked) {
                    snprintf(state_buf, sizeof(state_buf), "BRAKE_LOCKED");
                } else if (g_trans_telem.inter_shift_locked) {
                    snprintf(state_buf, sizeof(state_buf), "INTER_SHIFT(%.2fs)", g_trans_telem.inter_shift_remaining);
                } else if (g_trans_telem.fast_off_active) {
                    snprintf(state_buf, sizeof(state_buf), "FAST_OFF(%.1fs)", g_trans_telem.fast_off_remaining);
                } else if (g_trans_telem.coast_downhill) {
                    snprintf(state_buf, sizeof(state_buf), "DOWNHILL_HOLD");
                } else if (g_trans_telem.coast_active) {
                    snprintf(state_buf, sizeof(state_buf), "COAST_HOLD(%.1fs)", g_trans_telem.coast_remaining);
                } else if (s_cstate == COAST_STATE_EXPIRED) {
                    snprintf(state_buf, sizeof(state_buf), "COAST_EXPIRED");
                } else if (g_trans_telem.tip_in_active) {
                    snprintf(state_buf, sizeof(state_buf), "TIP_IN_DELAY(%.2fs)", g_trans_telem.tip_in_remaining);
                }

                char steer_buf[16] = "0%";
                if (g_trans_telem.steering > 0.03f) snprintf(steer_buf, sizeof(steer_buf), "R%.0f%%", g_trans_telem.steering * 100.0f);
                else if (g_trans_telem.steering < -0.03f) snprintf(steer_buf, sizeof(steer_buf), "L%.0f%%", -g_trans_telem.steering * 100.0f);

                char cc_buf[16] = "OFF";
                if (g_trans_telem.cruise_control_kmh > 1.0f) snprintf(cc_buf, sizeof(cc_buf), "%.0fkmh", g_trans_telem.cruise_control_kmh);

                char thr_buf[32];
                if (g_trans_telem.bos_active) {
                    snprintf(thr_buf, sizeof(thr_buf), "0.0%% (BOS)");
                } else {
                    snprintf(thr_buf, sizeof(thr_buf), "%4.1f%%", g_trans_telem.throttle * 100.0f);
                }

                trans_flight_log(TRANS_LOG_TELEM,
                    "TELEM: Spd: %5.1f km/h (%+4.1fm/s²) | Gear: %-3s (%d-spd) | RPM: %4.0f / %4.0f | Thr: %s (Ramp: %.2f) | Brk: %4.1f%% | Steer: %-4s | CC: %-5s | Win: [%4.0f..%4.0f] | Mode: %-7s | State: %s",
                    g_trans_telem.speed_kmh, g_trans_telem.accel_mps2,
                    g_trans_telem.gear_str[0] ? g_trans_telem.gear_str : "N",
                    g_trans_telem.forward_gear_count,
                    g_trans_telem.engine_rpm, g_trans_telem.rpm_limit,
                    thr_buf, g_trans_telem.pedal_ramp,
                    g_trans_telem.brake * 100.0f,
                    steer_buf, cc_buf,
                    g_trans_telem.win_min_rpm, g_trans_telem.win_max_rpm,
                    trans_get_mode_name(trans_get_current_mode_idx()),
                    state_buf);
            }
            s_last_telem_snap = now;
        }
    }
}

static int upshift_would_hunt(void *s, int cur, int target)
{
    float rpm   = g_trans_telem.engine_rpm;
    float r_cur = dsg_get_gear_ratio(s, cur);
    float r_new = dsg_get_gear_ratio(s, target);
    if (rpm < 300.0f || r_cur <= 0.05f || r_new <= 0.05f) return 0;
    if (g_trans_telem.rpm_limit > 1000.0f && rpm >= g_trans_telem.rpm_limit * 0.85f) return 0;

    float dn_thr = g_trans_telem.win_min_rpm;
    if (g_trans_telem.win_min_orig > dn_thr && g_trans_telem.win_min_orig < 20000.0f) dn_thr = g_trans_telem.win_min_orig;
    if (!(dn_thr > 500.0f && dn_thr < 20000.0f)) return 0;

    float rpm_after = rpm * r_new / r_cur;
    if (rpm_after >= dn_thr + 150.0f) return 0;

    static ULONGLONG s_last_hunt_log = 0;
    ULONGLONG now = GetTickCount64();
    if (now - s_last_hunt_log >= 1000) {
        trans_flight_log(TRANS_LOG_BLOCK,
            "UPSHIFT BLOCKED: D%d -> D%d would hunt | RPM %.0f -> %.0f < downshift %.0f + 150 | Spd: %.1f km/h | Thr: %.1f%%",
            cur, target, rpm, rpm_after, dn_thr, g_trans_telem.speed_kmh, g_trans_telem.throttle * 100.0f);
        s_last_hunt_log = now;
    }
    return 1;
}

static int stub_hi_kick(void *s)
{
    int o = o_hi_ed0(s);
    update_telem_from_self(s);
    if (!cfg.enabled) return o;
    if (is_upshift_inhibited(s)) {
        int cur = cur_abs_gear(s);
        if (o > cur && cur > 0) {
            static ULONGLONG s_last_kick_block_log = 0;
            static int s_last_kick_block_g = 0;
            ULONGLONG now = GetTickCount64();
            if (now - s_last_kick_block_log >= 1000 || s_last_kick_block_g != cur) {
                trans_flight_log(TRANS_LOG_BLOCK,
                    "UPSHIFT BLOCKED: Game wanted D%d -> D%d, BLOCKED by %s | Spd: %.1f km/h | RPM: %.0f | Thr: %.1f%%",
                    cur, o, get_upshift_inhibitor_reason(s), g_trans_telem.speed_kmh, g_trans_telem.engine_rpm, g_trans_telem.throttle * 100.0f);
                s_last_kick_block_log = now;
                s_last_kick_block_g = cur;
            }
        }
        return hold_gear(s, o);
    }
    int clamped = clamp_hi(s, o, cfg.up_step);
    int cur = cur_abs_gear(s);
    if (clamped > cur && cur > 0 && upshift_would_hunt(s, cur, clamped)) return hold_gear(s, o);
    if (clamped != o && cur > 0) {
        static ULONGLONG s_last_up_clamp_kick = 0;
        ULONGLONG now = GetTickCount64();
        if (now - s_last_up_clamp_kick >= 1000) {
            trans_flight_log(TRANS_LOG_CLAMP,
                "UPSHIFT CLAMPED: Game wanted D%d -> D%d, limited to D%d (max up_step=%d) | Spd: %.1f km/h | RPM: %.0f",
                cur, o, clamped, cfg.up_step, g_trans_telem.speed_kmh, g_trans_telem.engine_rpm);
            s_last_up_clamp_kick = now;
        }
    }
    return clamped;
}

static int stub_lo_kick(void *s)
{
    update_telem_from_self(s);
    if (!cfg.enabled) return o_lo_e70(s);
    int o = o_lo_e70(s);
    int cur = cur_abs_gear(s);

    int panic = is_panic_braking();
    float d1_lock_spd = panic ? 45.0f : 15.0f;

    if (g_trans_telem.speed_kmh >= d1_lock_spd && o < 2 && cur >= 2) {
        o = 2;
    }

    if (o < cur && cur > 0) {
        static ULONGLONG s_last_kick_log = 0;
        ULONGLONG now = GetTickCount64();
        if (now - s_last_kick_log >= 1000) {
            trans_flight_log(TRANS_LOG_SHIFT,
                "KICKDOWN DOWNSHIFT: Thr: %.0f%% | Game wanted D%d -> D%d, kick_step=%d | Spd: %.1f km/h | RPM: %.0f",
                g_trans_telem.throttle * 100.0f, cur, o, cfg.kick_step, g_trans_telem.speed_kmh, g_trans_telem.engine_rpm);
            s_last_kick_log = now;
        }
    }
    return clamp_lo(s, o, cfg.kick_step);
}

static int stub_hi_shared(void *s)
{
    int o = o_hi_e60(s);
    update_telem_from_self(s);
    if (!cfg.enabled) return o;
    if (is_upshift_inhibited(s)) {
        int cur = cur_abs_gear(s);
        if (o > cur && cur > 0) {
            static ULONGLONG s_last_shared_block_log = 0;
            static int s_last_shared_block_g = 0;
            ULONGLONG now = GetTickCount64();
            if (now - s_last_shared_block_log >= 1000 || s_last_shared_block_g != cur) {
                trans_flight_log(TRANS_LOG_BLOCK,
                    "UPSHIFT BLOCKED: Game wanted D%d -> D%d, BLOCKED by %s | Spd: %.1f km/h | RPM: %.0f | Thr: %.1f%%",
                    cur, o, get_upshift_inhibitor_reason(s), g_trans_telem.speed_kmh, g_trans_telem.engine_rpm, g_trans_telem.throttle * 100.0f);
                s_last_shared_block_log = now;
                s_last_shared_block_g = cur;
            }
        }
        return hold_gear(s, o);
    }
    int clamped = clamp_hi(s, o, cfg.up_step);
    int cur = cur_abs_gear(s);
    if (clamped > cur && cur > 0 && upshift_would_hunt(s, cur, clamped)) return hold_gear(s, o);
    if (clamped != o && cur > 0) {
        static ULONGLONG s_last_up_clamp_log = 0;
        ULONGLONG now = GetTickCount64();
        if (now - s_last_up_clamp_log >= 1000) {
            trans_flight_log(TRANS_LOG_CLAMP,
                "UPSHIFT CLAMPED: Game wanted D%d -> D%d, limited to D%d (max up_step=%d) | Spd: %.1f km/h | RPM: %.0f",
                cur, o, clamped, cfg.up_step, g_trans_telem.speed_kmh, g_trans_telem.engine_rpm);
            s_last_up_clamp_log = now;
        }
    }
    return clamped;
}

static int stub_lo_down(void *s)
{
    int o = o_lo_e70(s);
    update_telem_from_self(s);
    if (!cfg.enabled) return o;
    int cur = cur_abs_gear(s);

    int panic = is_panic_braking();
    float d1_lock_spd = panic ? 45.0f : 15.0f;

    if (g_trans_telem.speed_kmh >= d1_lock_spd && o < 2 && cur >= 2) {
        static ULONGLONG s_last_d1_lock = 0;
        ULONGLONG now = GetTickCount64();
        if (now - s_last_d1_lock >= 1000) {
            trans_flight_log(TRANS_LOG_BLOCK,
                "DOWNSHIFT D1 LOCKED: Game wanted D%d -> D%d at %.1f km/h, clamped to D2 (%s lockout >= %.0f km/h)",
                cur, o, g_trans_telem.speed_kmh, panic ? "Panic braking" : "D1 rolling", d1_lock_spd);
            s_last_d1_lock = now;
        }
        o = 2;
    } else if (panic && g_trans_telem.speed_kmh < 45.0f && o < 2 && cur >= 2) {
        static ULONGLONG s_last_panic_d1 = 0;
        ULONGLONG now = GetTickCount64();
        if (now - s_last_panic_d1 >= 1000) {
            trans_flight_log(TRANS_LOG_SHIFT,
                "PANIC BRAKING D1 ALLOWED: Game wanted D%d -> D%d at %.1f km/h (< 45 km/h, Decel: %.1f m/s², Brk: %.0f%%) - D1 allowed to prevent engine stall / Neutral",
                cur, o, g_trans_telem.speed_kmh, g_trans_telem.accel_mps2, g_trans_telem.brake * 100.0f);
            s_last_panic_d1 = now;
        }
    }

    if (panic && cur >= 4 && g_trans_telem.speed_kmh <= 65.0f) {
        static ULONGLONG s_last_panic_block = 0;
        ULONGLONG now = GetTickCount64();
        if (now - s_last_panic_block >= 1000) {
            trans_flight_log(TRANS_LOG_SHIFT,
                "PANIC BRAKING BLOCK DOWNSHIFT: Cur: D%d at %.1f km/h <= 65 km/h (Decel: %.1f m/s², Brk: %.0f%%) - multi-gear skip to D2/D1 to prevent stall/Neutral",
                cur, g_trans_telem.speed_kmh, g_trans_telem.accel_mps2, g_trans_telem.brake * 100.0f);
            s_last_panic_block = now;
        }
    } else if (panic && g_trans_telem.speed_kmh > 65.0f && cur >= 3) {
        static ULONGLONG s_last_panic_seq = 0;
        ULONGLONG now = GetTickCount64();
        if (now - s_last_panic_seq >= 1000) {
            trans_flight_log(TRANS_LOG_SHIFT,
                "PANIC BRAKING HIGH-SPEED DOWN: Cur: D%d at %.1f km/h > 65 km/h (Decel: %.1f m/s², Brk: %.0f%%) - sequential downshift allowed for engine braking",
                cur, g_trans_telem.speed_kmh, g_trans_telem.accel_mps2, g_trans_telem.brake * 100.0f);
            s_last_panic_seq = now;
        }
    }

    if (is_shift_locked(s, 1)) {
        if (o < cur && cur > 0) {
            static ULONGLONG s_last_dn_lock_log = 0;
            ULONGLONG now = GetTickCount64();
            if (now - s_last_dn_lock_log >= 1000) {
                trans_flight_log(TRANS_LOG_BLOCK,
                    "DOWNSHIFT BLOCKED: Game wanted D%d -> D%d, BLOCKED by %s | Spd: %.1f km/h | RPM: %.0f",
                    cur, o, dsg_is_locked() ? "DSG Shift In Progress" : "Downshift Dwell Lock",
                    g_trans_telem.speed_kmh, g_trans_telem.engine_rpm);
                s_last_dn_lock_log = now;
            }
        }
        return hold_gear(s, o);
    }
    int clamped = clamp_lo(s, o, cfg.down_step);
    if (clamped != o && cur > 0) {
        static ULONGLONG s_last_dn_clamp_log = 0;
        ULONGLONG now = GetTickCount64();
        if (now - s_last_dn_clamp_log >= 1000) {
            trans_flight_log(TRANS_LOG_CLAMP,
                "DOWNSHIFT CLAMPED: Game wanted D%d -> D%d, limited to D%d (max down_step=%d) | Spd: %.1f km/h | RPM: %.0f",
                cur, o, clamped, cfg.down_step, g_trans_telem.speed_kmh, g_trans_telem.engine_rpm);
            s_last_dn_clamp_log = now;
        }
    }
    return clamped;
}

static int stub_hi_up(void *s)
{
    int o = o_hi_ed0(s);
    update_telem_from_self(s);
    if (!cfg.enabled) return o;
    if (is_upshift_inhibited(s)) {
        int cur = cur_abs_gear(s);
        if (o > cur && cur > 0) {
            static ULONGLONG s_last_up_block_log = 0;
            static int s_last_up_block_g = 0;
            ULONGLONG now = GetTickCount64();
            if (now - s_last_up_block_log >= 1000 || s_last_up_block_g != cur) {
                trans_flight_log(TRANS_LOG_BLOCK,
                    "UPSHIFT BLOCKED: Game wanted D%d -> D%d, BLOCKED by %s | Spd: %.1f km/h | RPM: %.0f | Thr: %.1f%%",
                    cur, o, get_upshift_inhibitor_reason(s), g_trans_telem.speed_kmh, g_trans_telem.engine_rpm, g_trans_telem.throttle * 100.0f);
                s_last_up_block_log = now;
                s_last_up_block_g = cur;
            }
        }
        return hold_gear(s, o);
    }
    int clamped = clamp_hi(s, o, cfg.up_step);
    int cur = cur_abs_gear(s);
    if (clamped > cur && cur > 0 && upshift_would_hunt(s, cur, clamped)) return hold_gear(s, o);
    if (clamped != o && cur > 0) {
        static ULONGLONG s_last_up_clamp_log2 = 0;
        ULONGLONG now = GetTickCount64();
        if (now - s_last_up_clamp_log2 >= 1000) {
            trans_flight_log(TRANS_LOG_CLAMP,
                "UPSHIFT CLAMPED: Game wanted D%d -> D%d, limited to D%d (max up_step=%d) | Spd: %.1f km/h | RPM: %.0f",
                cur, o, clamped, cfg.up_step, g_trans_telem.speed_kmh, g_trans_telem.engine_rpm);
            s_last_up_clamp_log2 = now;
        }
    }
    return clamped;
}

static float *stub_window(void *self, float *out, unsigned int gear)
{
    float f, k, lim, ceil_, need, mn, mx, mn0, mx0;

    o_window(self, out, gear);
    since_shift(self);
    if (!out) return out;
    if (!(out[0] > 0.0f) || !(out[1] > out[0])) return out;

    mn0 = out[0];
    mx0 = out[1];

    update_telem_from_self(self);
    g_trans_telem.win_min_orig = mn0;
    g_trans_telem.win_max_orig = mx0;

    if (!cfg.enabled) {
        g_trans_telem.win_min_rpm = mn0;
        g_trans_telem.win_max_rpm = mx0;
        return out;
    }

    if (is_panic_braking()) {
        int cur = cur_abs_gear(self);
        if (cur > 1) {
            float lim_rpm = rpm_limit_of(self);
            float safe_down_rpm = 5200.0f;
            if (lim_rpm > 1000.0f && lim_rpm * 0.75f < safe_down_rpm) {
                safe_down_rpm = lim_rpm * 0.75f;
            }

            if (g_trans_telem.speed_kmh >= 45.0f && gear < 2) {
                out[0] = 99999.0f;
                return out;
            }

            if (gear < (unsigned int)cur) {
                if (out[1] < safe_down_rpm) {
                    out[1] = safe_down_rpm;
                }
            }

            if (g_trans_telem.speed_kmh > 65.0f) {

                if (cur >= 3 && gear >= (unsigned int)cur) {
                    out[0] = 99999.0f;
                    return out;
                }
            } else {

                if (cur >= 4) {
                    if (gear >= (unsigned int)(cur - 1)) {
                        out[0] = 99999.0f;
                        return out;
                    }
                } else if (cur == 3) {

                    if (gear >= 3) {
                        out[0] = 99999.0f;
                        return out;
                    }
                } else if (cur == 2) {

                    if (g_trans_telem.speed_kmh < 35.0f && gear >= 2) {
                        out[0] = 99999.0f;
                        return out;
                    }
                }
            }

            g_trans_telem.win_min_rpm = out[0];
            g_trans_telem.win_max_rpm = out[1];
            return out;
        }
    }

    f = pedal_ramp(self);
    if (f <= 0.0f || cfg.thr_gain <= 0.0f) {
        g_trans_telem.win_min_rpm = mn0;
        g_trans_telem.win_max_rpm = mx0;
        return out;
    }

    lim   = rpm_limit_of(self);
    ceil_ = (lim > 0.0f) ? lim * 0.99f : 0.0f;

    if (lim > 0.0f) {
        float demand = lim * cfg.min_rpm_hi;
        if (demand < mn0) demand = mn0;
        mn = mn0 + f * (demand - mn0);
    } else {
        mn = mn0 * (1.0f + f * cfg.thr_gain);
    }
    k = mn / mn0;
    if (k > 1.0f + cfg.thr_gain) { k = 1.0f + cfg.thr_gain; mn = mn0 * k; }
    if (k <= 1.0f) {
        g_trans_telem.win_min_rpm = mn0;
        g_trans_telem.win_max_rpm = mx0;
        return out;
    }

    mx = mx0 * k;
    if (ceil_ > 0.0f && mx > lim * cfg.thr_peak) mx = lim * cfg.thr_peak;
    if (ceil_ > 0.0f && mx > ceil_) mx = ceil_;

    if (lim > 0.0f) {
        float demand_dn = lim * cfg.min_rpm_hi;
        if (demand_dn < mn0) demand_dn = mn0;
        float mn_dn = mn0 + f * f * (demand_dn - mn0);
        if (mn_dn < mn) mn = mn_dn;

        int cur_g = cur_abs_gear(self);
        if (cur_g > 0 && gear < (unsigned int)cur_g) {
            float mx_dn = mx0 * (mn_dn / mn0);
            if (mx_dn < mx0) mx_dn = mx0;
            if (mx_dn < mx) mx = mx_dn;
        }
    }

    need = gear_step(self, gear);
    need = (need > 1.01f) ? need + 0.05f : 1.15f;
    if (mn > mx / need) mn = mx / need;
    if (mn < mn0) mn = mn0;
    if (mx <= mn) {
        out[0] = mn0; out[1] = mx0;
        g_trans_telem.win_min_rpm = mn0;
        g_trans_telem.win_max_rpm = mx0;
        return out;
    }

    out[0] = mn;
    out[1] = mx;
    g_trans_telem.win_min_rpm = mn;
    g_trans_telem.win_max_rpm = mx;
    return out;
}

static unsigned char *g_tramp;
static size_t         g_tramp_used;

static unsigned char *alloc_near(uintptr_t target)
{
    SYSTEM_INFO si;
    uintptr_t gran, d;
    GetSystemInfo(&si);
    gran = si.dwAllocationGranularity;
    for (d = gran; d < 0x60000000u; d += gran) {
        void *p;
        uintptr_t a = (target - d) & ~(uintptr_t)(gran - 1);
        p = VirtualAlloc((void *)a, 0x1000, MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE);
        if (p) return (unsigned char *)p;
        a = (target + d) & ~(uintptr_t)(gran - 1);
        p = VirtualAlloc((void *)a, 0x1000, MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE);
        if (p) return (unsigned char *)p;
    }
    return NULL;
}

static unsigned char *make_tramp(void *fn)
{
    unsigned char *p = g_tramp + g_tramp_used;
    p[0] = 0x48; p[1] = 0xB8;
    memcpy(p + 2, &fn, 8);
    p[10] = 0xFF; p[11] = 0xE0;
    g_tramp_used += 16;
    return p;
}

static int write_mem(void *dst, const void *src, size_t n)
{
    DWORD old;
    if (!VirtualProtect(dst, n, PAGE_EXECUTE_READWRITE, &old)) return 0;
    memcpy(dst, src, n);
    VirtualProtect(dst, n, old, &old);
    FlushInstructionCache(GetCurrentProcess(), dst, n);
    return 1;
}

static int patch_call(uintptr_t site, void *stub)
{
    unsigned char *tr = make_tramp(stub);
    int64_rel64:
    int64_t rel64 = (int64_t)(uintptr_t)tr - (int64_t)(site + 5);
    int32_t rel;
    if (rel64 < (int64_t)INT32_MIN || rel64 > (int64_t)INT32_MAX) return 0;
    rel = (int32_t)rel64;
    return write_mem((void *)(site + 1), &rel, 4);
}

void trans_update_gate(void)
{
    if (!s_gate) return;
    unsigned char op = 0xEB;
    write_mem((void *)s_gate, &op, 1);
}

static void init_default_modes(void)
{

    g_modes[0].enabled    = 1;
    g_modes[0].up_step    = 1;
    g_modes[0].down_step  = 2;
    g_modes[0].kick_step  = 0;
    g_modes[0].thr_gain   = 3.00f;
    g_modes[0].thr_peak   = 0.90f;
    g_modes[0].min_rpm_hi = 0.72f;
    g_modes[0].thr_lo     = 0.10f;
    g_modes[0].thr_hi     = 0.85f;
    g_modes[0].thr_curve  = 1.60f;
    g_modes[0].fast_off_hold = 2.00f;
    g_modes[0].coast_hold  = 1;
    g_modes[0].coast_thr   = 0.06f;
    g_modes[0].max_coast_gear = 0;
    g_modes[0].coast_timeout = 6.00f;
    g_modes[0].tip_in_delay = 0.45f;
    g_modes[0].inter_shift_delay = 0.75f;
    g_modes[0].up_delay   = 0.00f;
    g_modes[0].dn_delay   = 0.00f;
    g_modes[0].flywheel_inertia   = 0.18f;
    g_modes[0].flywheel_response  = 1.50f;
    g_modes[0].flywheel_drop_rate = 1.20f;

    g_modes[1].enabled    = 1;
    g_modes[1].up_step    = 1;
    g_modes[1].down_step  = 2;
    g_modes[1].kick_step  = 0;
    g_modes[1].thr_gain   = 4.00f;
    g_modes[1].thr_peak   = 0.98f;
    g_modes[1].min_rpm_hi = 0.88f;
    g_modes[1].thr_lo     = 0.00f;
    g_modes[1].thr_hi     = 0.70f;
    g_modes[1].thr_curve  = 1.25f;
    g_modes[1].fast_off_hold = 3.50f;
    g_modes[1].coast_hold  = 1;
    g_modes[1].coast_thr   = 0.09f;
    g_modes[1].max_coast_gear = 7;
    g_modes[1].coast_timeout = 8.00f;
    g_modes[1].tip_in_delay = 0.25f;
    g_modes[1].inter_shift_delay = 0.45f;
    g_modes[1].up_delay   = 0.00f;
    g_modes[1].dn_delay   = 0.00f;
    g_modes[1].flywheel_inertia   = 0.10f;
    g_modes[1].flywheel_response  = 2.40f;
    g_modes[1].flywheel_drop_rate = 1.60f;

    g_modes[2].enabled    = 1;
    g_modes[2].up_step    = 1;
    g_modes[2].down_step  = 1;
    g_modes[2].kick_step  = 0;
    g_modes[2].thr_gain   = 1.80f;
    g_modes[2].thr_peak   = 0.75f;
    g_modes[2].min_rpm_hi = 0.55f;
    g_modes[2].thr_lo     = 0.25f;
    g_modes[2].thr_hi     = 0.90f;
    g_modes[2].thr_curve  = 2.10f;
    g_modes[2].fast_off_hold = 0.50f;
    g_modes[2].coast_hold  = 0;
    g_modes[2].coast_thr   = 0.03f;
    g_modes[2].max_coast_gear = 0;
    g_modes[2].coast_timeout = 2.00f;
    g_modes[2].tip_in_delay = 0.60f;
    g_modes[2].inter_shift_delay = 1.05f;
    g_modes[2].up_delay   = 0.00f;
    g_modes[2].dn_delay   = 0.00f;
    g_modes[2].flywheel_inertia   = 0.25f;
    g_modes[2].flywheel_response  = 1.00f;
    g_modes[2].flywheel_drop_rate = 0.90f;

    g_modes[3].enabled    = 0;
    g_modes[3].up_step    = 0;
    g_modes[3].down_step  = 0;
    g_modes[3].kick_step  = 0;
    g_modes[3].thr_gain   = 0.00f;
    g_modes[3].thr_peak   = 0.90f;
    g_modes[3].min_rpm_hi = 0.65f;
    g_modes[3].thr_lo     = 0.45f;
    g_modes[3].thr_hi     = 0.85f;
    g_modes[3].thr_curve  = 1.60f;
    g_modes[3].fast_off_hold = 0.00f;
    g_modes[3].coast_hold  = 0;
    g_modes[3].coast_thr   = 0.00f;
    g_modes[3].max_coast_gear = 0;
    g_modes[3].coast_timeout = 0.00f;
    g_modes[3].tip_in_delay = 0.00f;
    g_modes[3].inter_shift_delay = 0.00f;
    g_modes[3].up_delay   = 0.00f;
    g_modes[3].dn_delay   = 0.00f;
    g_modes[3].flywheel_inertia   = 1.00f;
    g_modes[3].flywheel_response  = 1.00f;
    g_modes[3].flywheel_drop_rate = 1.00f;
}

void trans_save_config(void)
{
    FILE *f;
    if (!g_cfg_path[0]) return;
    CreateDirectoryA(g_cfg_dir, NULL);

    sync_current_mode_to_g_modes();

    f = fopen(g_cfg_path, "w");
    if (!f) return;

    fprintf(f, "# car_automatic_transmission\n");
    fprintf(f, "enabled=%d\n\n", cfg.enabled);

    const char *cur_mode_name = "Normal";
    if (s_current_mode_idx == 1) cur_mode_name = "Sport";
    else if (s_current_mode_idx == 2) cur_mode_name = "Comfort";
    else if (s_current_mode_idx == 3) cur_mode_name = "Stock";
    fprintf(f, "# Active transmission mode (Normal, Sport, Comfort, Stock)\n");
    fprintf(f, "mode=%s\n\n", cur_mode_name);

    fprintf(f, "# Hotkey to toggle the menu\n");
    fprintf(f, "menu_key=%s\n\n", cfg.menu_key[0] ? cfg.menu_key : "F9");
    fprintf(f, "# Hotkey to cycle drive modes\n");
    fprintf(f, "mode_key=%s\n\n", cfg.mode_key[0] ? cfg.mode_key : "F8");

    static const char *sec_names[4] = { "Normal", "Sport", "Comfort", "Stock" };

    fprintf(f, "# ==========================================================\n");
    fprintf(f, "# Drive Modes Configuration\n");
    fprintf(f, "# You can customize each mode individually below.\n");
    fprintf(f, "# ==========================================================\n\n");

    for (int i = 0; i < 4; i++) {
        fprintf(f, "[%s]\n", sec_names[i]);
        fprintf(f, "enabled=%d\n", g_modes[i].enabled);
        fprintf(f, "gears_per_upshift=%d\n", g_modes[i].up_step);
        fprintf(f, "gears_per_downshift=%d\n", g_modes[i].down_step);
        fprintf(f, "gears_on_kickdown=%d\n", g_modes[i].kick_step);
        fprintf(f, "min_rpm_hi=%.2f\n", g_modes[i].min_rpm_hi);
        fprintf(f, "thr_lo=%.2f\n", g_modes[i].thr_lo);
        fprintf(f, "thr_hi=%.2f\n", g_modes[i].thr_hi);
        fprintf(f, "thr_curve=%.2f\n", g_modes[i].thr_curve);
        fprintf(f, "thr_peak=%.2f\n", g_modes[i].thr_peak);
        fprintf(f, "thr_gain=%.2f\n", g_modes[i].thr_gain);
        fprintf(f, "fast_off_hold=%.2f\n", g_modes[i].fast_off_hold);
        fprintf(f, "coast_hold=%d\n", g_modes[i].coast_hold);
        fprintf(f, "coast_threshold=%.2f\n", g_modes[i].coast_thr);
        fprintf(f, "coast_timeout=%.2f\n", g_modes[i].coast_timeout);
        fprintf(f, "tip_in_delay=%.2f\n", g_modes[i].tip_in_delay);
        fprintf(f, "inter_shift_delay=%.2f\n", g_modes[i].inter_shift_delay);
        fprintf(f, "upshift_delay=%.2f\n", g_modes[i].up_delay);
        fprintf(f, "downshift_delay=%.2f\n", g_modes[i].dn_delay);
        fprintf(f, "flywheel_inertia=%.2f\n", g_modes[i].flywheel_inertia);
        fprintf(f, "flywheel_response=%.2f\n", g_modes[i].flywheel_response);
        fprintf(f, "flywheel_drop_rate=%.2f\n\n", g_modes[i].flywheel_drop_rate);
    }

    fclose(f);
}

static void load_cfg(void)
{
    char line[256];
    FILE *f;
    int current_sec = -1;

    if (!g_cfg_path[0]) return;
    f = fopen(g_cfg_path, "r");
    if (!f) {
        init_default_modes();
        s_current_mode_idx = 0;
        trans_apply_mode_idx(0);
        trans_save_config();
        return;
    }

    init_default_modes();

    while (fgets(line, sizeof line, f)) {
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '#' || *p == ';' || *p == 10 || *p == 13 || *p == 0) continue;

        char *end = p + strlen(p) - 1;
        while (end >= p && (*end == '\r' || *end == '\n' || *end == ' ' || *end == '\t')) {
            *end = 0;
            end--;
        }

        if (*p == '[') {
            char *closing = strchr(p, ']');
            if (closing) {
                *closing = 0;
                char *sec_name = p + 1;
                if (!_stricmp(sec_name, "Normal") || !_stricmp(sec_name, "Default") || !_stricmp(sec_name, "pkw_default")) {
                    current_sec = 0;
                } else if (!_stricmp(sec_name, "Sport")) {
                    current_sec = 1;
                } else if (!_stricmp(sec_name, "Comfort")) {
                    current_sec = 2;
                } else if (!_stricmp(sec_name, "Stock") || !_stricmp(sec_name, "Truck")) {
                    current_sec = 3;
                } else {
                    current_sec = -1;
                }
                continue;
            }
        }

        char *e = strchr(p, '=');
        if (!e) continue;
        *e = 0;
        char *key = p;
        char *val = e + 1;

        char *kend = key + strlen(key) - 1;
        while (kend >= key && (*kend == ' ' || *kend == '\t')) { *kend = 0; kend--; }
        while (*val == ' ' || *val == '\t') val++;

        int v = atoi(val);
        double d = atof(val);

        if (current_sec == -1) {
            if (!strcmp(key, "enabled")) {
                cfg.enabled = v;
            }
            else if (!strcmp(key, "mode") || !strcmp(key, "preset")) {
                if (!_stricmp(val, "normal") || !_stricmp(val, "pkw_default") || !_stricmp(val, "default")) {
                    s_current_mode_idx = 0;
                } else if (!_stricmp(val, "sport")) {
                    s_current_mode_idx = 1;
                } else if (!_stricmp(val, "comfort")) {
                    s_current_mode_idx = 2;
                } else if (!_stricmp(val, "stock") || !_stricmp(val, "truck")) {
                    s_current_mode_idx = 3;
                }
            }
            else if (!strcmp(key, "menu_key") || !strcmp(key, "toggle_key") || !strcmp(key, "hotkey")) {
                trans_set_menu_key(val);
            }
            else if (!strcmp(key, "mode_key") || !strcmp(key, "preset_key")) {
                trans_set_mode_key(val);
            }
            else if (!strcmp(key, "status_file") || !strcmp(key, "logging") || !strcmp(key, "log_periodic") || !strcmp(key, "log_interval")) {
                (void)v; (void)d;
            }
            else if (!strcmp(key, "up_step") || !strcmp(key, "gears_per_upshift"))             g_modes[0].up_step = v;
            else if (!strcmp(key, "down_step") || !strcmp(key, "gears_per_downshift"))         g_modes[0].down_step = v;
            else if (!strcmp(key, "kick_step") || !strcmp(key, "gears_on_kickdown"))          g_modes[0].kick_step = v;
            else if (!strcmp(key, "thr_gain") || !strcmp(key, "window_shift_gain_limit"))     g_modes[0].thr_gain = (float)d;
            else if (!strcmp(key, "thr_peak") || !strcmp(key, "shift_window_ceiling"))        g_modes[0].thr_peak = (float)d;
            else if (!strcmp(key, "min_rpm_hi") || !strcmp(key, "minimum_high_rpm"))          g_modes[0].min_rpm_hi = (float)d;
            else if (!strcmp(key, "thr_lo") || !strcmp(key, "pedal_low_threshold"))           g_modes[0].thr_lo = (float)d;
            else if (!strcmp(key, "thr_hi") || !strcmp(key, "pedal_high_threshold"))          g_modes[0].thr_hi = (float)d;
            else if (!strcmp(key, "thr_curve") || !strcmp(key, "throttle_curve"))             g_modes[0].thr_curve = (float)d;
            else if (!strcmp(key, "fast_off_hold") || !strcmp(key, "gear_hold") || !strcmp(key, "hang_on_delay")) g_modes[0].fast_off_hold = (float)d;
            else if (!strcmp(key, "coast_hold") || !strcmp(key, "coasting_hold"))             g_modes[0].coast_hold = v;
            else if (!strcmp(key, "coast_threshold") || !strcmp(key, "coast_thr"))            g_modes[0].coast_thr = (float)d;
            else if (!strcmp(key, "max_coast_gear") || !strcmp(key, "max_coasting_gear"))     g_modes[0].max_coast_gear = v;
            else if (!strcmp(key, "coast_timeout") || !strcmp(key, "coast_hold_time"))        g_modes[0].coast_timeout = (float)d;
            else if (!strcmp(key, "tip_in_delay") || !strcmp(key, "tip_in") || !strcmp(key, "cruise_delay")) g_modes[0].tip_in_delay = (float)d;
            else if (!strcmp(key, "inter_shift_delay") || !strcmp(key, "inter_shift") || !strcmp(key, "dwell_delay")) g_modes[0].inter_shift_delay = (float)d;
            else if (!strcmp(key, "upshift_delay") || !strcmp(key, "upshift_lockout_delay"))  g_modes[0].up_delay = (float)d;
            else if (!strcmp(key, "downshift_delay") || !strcmp(key, "downshift_lockout_delay")) g_modes[0].dn_delay = (float)d;
            else if (!strcmp(key, "flywheel_inertia"))   g_modes[0].flywheel_inertia = (float)d;
            else if (!strcmp(key, "flywheel_response"))  g_modes[0].flywheel_response = (float)d;
            else if (!strcmp(key, "flywheel_drop_rate")) g_modes[0].flywheel_drop_rate = (float)d;
        } else if (current_sec >= 0 && current_sec < 4) {
            if (!strcmp(key, "enabled"))                                                        g_modes[current_sec].enabled = v;
            else if (!strcmp(key, "up_step") || !strcmp(key, "gears_per_upshift"))             g_modes[current_sec].up_step = v;
            else if (!strcmp(key, "down_step") || !strcmp(key, "gears_per_downshift"))         g_modes[current_sec].down_step = v;
            else if (!strcmp(key, "kick_step") || !strcmp(key, "gears_on_kickdown"))          g_modes[current_sec].kick_step = v;
            else if (!strcmp(key, "thr_gain") || !strcmp(key, "window_shift_gain_limit"))     g_modes[current_sec].thr_gain = (float)d;
            else if (!strcmp(key, "thr_peak") || !strcmp(key, "shift_window_ceiling"))        g_modes[current_sec].thr_peak = (float)d;
            else if (!strcmp(key, "min_rpm_hi") || !strcmp(key, "minimum_high_rpm"))          g_modes[current_sec].min_rpm_hi = (float)d;
            else if (!strcmp(key, "thr_lo") || !strcmp(key, "pedal_low_threshold"))           g_modes[current_sec].thr_lo = (float)d;
            else if (!strcmp(key, "thr_hi") || !strcmp(key, "pedal_high_threshold"))          g_modes[current_sec].thr_hi = (float)d;
            else if (!strcmp(key, "thr_curve") || !strcmp(key, "throttle_curve"))             g_modes[current_sec].thr_curve = (float)d;
            else if (!strcmp(key, "fast_off_hold") || !strcmp(key, "gear_hold") || !strcmp(key, "hang_on_delay")) g_modes[current_sec].fast_off_hold = (float)d;
            else if (!strcmp(key, "coast_hold") || !strcmp(key, "coasting_hold"))             g_modes[current_sec].coast_hold = v;
            else if (!strcmp(key, "coast_threshold") || !strcmp(key, "coast_thr"))            g_modes[current_sec].coast_thr = (float)d;
            else if (!strcmp(key, "max_coast_gear") || !strcmp(key, "max_coasting_gear"))     g_modes[current_sec].max_coast_gear = v;
            else if (!strcmp(key, "coast_timeout") || !strcmp(key, "coast_hold_time"))        g_modes[current_sec].coast_timeout = (float)d;
            else if (!strcmp(key, "tip_in_delay") || !strcmp(key, "tip_in") || !strcmp(key, "cruise_delay")) g_modes[current_sec].tip_in_delay = (float)d;
            else if (!strcmp(key, "inter_shift_delay") || !strcmp(key, "inter_shift") || !strcmp(key, "dwell_delay")) g_modes[current_sec].inter_shift_delay = (float)d;
            else if (!strcmp(key, "upshift_delay") || !strcmp(key, "upshift_lockout_delay"))  g_modes[current_sec].up_delay = (float)d;
            else if (!strcmp(key, "downshift_delay") || !strcmp(key, "downshift_lockout_delay")) g_modes[current_sec].dn_delay = (float)d;
            else if (!strcmp(key, "flywheel_inertia"))   g_modes[current_sec].flywheel_inertia = (float)d;
            else if (!strcmp(key, "flywheel_response"))  g_modes[current_sec].flywheel_response = (float)d;
            else if (!strcmp(key, "flywheel_drop_rate")) g_modes[current_sec].flywheel_drop_rate = (float)d;
        }
    }
    fclose(f);

    trans_apply_mode_idx(s_current_mode_idx);
}

void trans_reload_config(void)
{
    load_cfg();
    trans_update_gate();
}

void trans_reset_defaults(void)
{
    init_default_modes();
    cfg.enabled     = 1;
    trans_set_menu_key("F9");
    trans_set_mode_key("F8");
    s_current_mode_idx = 0;
    trans_apply_mode_idx(0);
    trans_save_config();
}

void trans_apply_preset(const char *preset)
{
    if (!preset) return;
    int idx = 0;
    if (!_stricmp(preset, "sport")) idx = 1;
    else if (!_stricmp(preset, "comfort")) idx = 2;
    else if (!_stricmp(preset, "stock") || !_stricmp(preset, "truck")) idx = 3;
    else idx = 0;
    trans_switch_mode(idx);
}

static void init_paths(HMODULE self)
{
    char *slash;
    GetModuleFileNameA(self, g_dir, sizeof g_dir);
    slash = strrchr(g_dir, '\\');
    if (slash) slash[1] = 0; else g_dir[0] = 0;

    snprintf(g_cfg_dir, sizeof g_cfg_dir, "%scar_automatic_transmission\\", g_dir);
    CreateDirectoryA(g_cfg_dir, NULL);

    snprintf(g_cfg_path, sizeof g_cfg_path, "%scar_automatic_transmission.cfg", g_cfg_dir);

    char old_cfg[MAX_PATH * 2];
    snprintf(old_cfg, sizeof old_cfg, "%scar_automatic_transmission.cfg", g_dir);
    if (GetFileAttributesA(g_cfg_path) == INVALID_FILE_ATTRIBUTES &&
        GetFileAttributesA(old_cfg) != INVALID_FILE_ATTRIBUTES) {
        CopyFileA(old_cfg, g_cfg_path, TRUE);
        DeleteFileA(old_cfg);
    }
}

static void do_patch(void)
{
    const char *err;
    int i, done = 0;

    g_base = (uintptr_t)GetModuleHandleW(NULL);

    err = discover();
    if (err) {
        snprintf(g_trans_telem.status_line, sizeof(g_trans_telem.status_line), "Not applied: %s not found", err);
        status("not applied: %s not found", err);
        return;
    }

    const char *fw_err = flywheel_hook_install();
    if (fw_err) {
        trans_flight_log(TRANS_LOG_INFO, "[FLYWHEEL] rpm step hook NOT installed (%s), using telemetry fallback", fw_err);
    }

    g_tramp = alloc_near(s_hi_kick);
    if (!g_tramp) {
        snprintf(g_trans_telem.status_line, sizeof(g_trans_telem.status_line), "Not applied: No memory near call sites");
        status("not applied: no memory in range");
        return;
    }

    done += patch_call(s_hi_kick,   (void *)stub_hi_kick);
    done += patch_call(s_lo_kick,   (void *)stub_lo_kick);
    done += patch_call(s_hi_shared, (void *)stub_hi_shared);
    done += patch_call(s_lo_down,   (void *)stub_lo_down);
    done += patch_call(s_hi_up,     (void *)stub_hi_up);

    for (i = 0; i < s_window_count; i++)
        done += patch_call(s_window[i], (void *)stub_window);

    trans_update_gate();
    if (cfg.dn_on_accel) done++;

    g_trans_telem.patches_applied = done;
    g_trans_telem.window_sites    = s_window_count;
    snprintf(g_trans_telem.status_line, sizeof(g_trans_telem.status_line),
             "Active: %d patches, %d window hooks", done, s_window_count);
    status("applied, %d patches, %d window call sites", done, s_window_count);
}

static void __cdecl telem_channel_cb(const char *name, unsigned int index, const scs_value_t *value, void *context)
{
    (void)index; (void)context;
    if (!value || !name) return;
    if (strcmp(name, "truck.speed") == 0 && value->type == SCS_VALUE_TYPE_float) {
        float spd = value->value_float.value * 3.6f;
        if (spd < 0.0f) spd = -spd;
        g_trans_telem.speed_kmh = spd;
    } else if (strcmp(name, "truck.input.throttle") == 0 && value->type == SCS_VALUE_TYPE_float) {
        float t = value->value_float.value;
        if (t < 0.0f) t = 0.0f;
        if (t > 1.0f) t = 1.0f;
        s_sdk_throttle = t;
        s_sdk_throttle_seen = 1;
        g_trans_telem.raw_throttle = t;
        if (g_trans_telem.gear == 0) {
            g_trans_telem.throttle = t;
        }
    } else if (strcmp(name, "truck.engine.rpm") == 0) {
        float rpm = 0.0f;
        if (value->type == SCS_VALUE_TYPE_float) {
            rpm = value->value_float.value;
        } else if (value->type == SCS_VALUE_TYPE_s32) {
            rpm = (float)value->value_s32.value;
        } else if (value->type == SCS_VALUE_TYPE_u32) {
            rpm = (float)value->value_u32.value;
        } else if (value->type == 6 ) {
            rpm = (float)*(const double *)&value->value_float;
        }
        if (rpm < 0.0f) rpm = 0.0f;
        if (rpm > 10.0f) {
            g_trans_telem.engine_rpm = rpm;
            static int s_logged_sdk_rpm = 0;
            if (!s_logged_sdk_rpm) {
                trans_flight_log(TRANS_LOG_INFO, "[RPM_INIT] First RPM from Telemetry SDK: %.1f", rpm);
                s_logged_sdk_rpm = 1;
            }
        }

        if (s_last_self) {
            update_telem_from_self(s_last_self);
        }
    } else if (strcmp(name, "truck.input.brake") == 0 && value->type == SCS_VALUE_TYPE_float) {
        g_trans_telem.brake = value->value_float.value;
    } else if (strcmp(name, "truck.input.steering") == 0 && value->type == SCS_VALUE_TYPE_float) {
        g_trans_telem.steering = value->value_float.value;
    } else if (strcmp(name, "truck.cruise_control") == 0 && value->type == SCS_VALUE_TYPE_float) {
        float cc_spd = value->value_float.value * 3.6f;
        g_trans_telem.cruise_control_kmh = (cc_spd > 0.5f) ? cc_spd : 0.0f;
    } else if (strcmp(name, "truck.brake.parking") == 0 && value->type == SCS_VALUE_TYPE_bool) {
        g_trans_telem.parking_brake = value->value_bool.value ? 1 : 0;
    } else if (strcmp(name, "truck.engine.enabled") == 0 && value->type == SCS_VALUE_TYPE_bool) {
        g_trans_telem.engine_enabled = value->value_bool.value ? 1 : 0;
    }
}

__declspec(dllexport) int __cdecl scs_telemetry_init(unsigned int version, const void *params)
{
    const scs_telemetry_init_params_v100_t *p = (const scs_telemetry_init_params_v100_t *)params;
    trans_log("scs_telemetry_init: version=%u, calling trans_overlay_init and do_patch", version);
    g_trans_telem.idle_rpm = 750.0f;
    g_trans_telem.rpm_limit = 6900.0f;
    g_trans_telem.target_rev_rpm = 750.0f;
    g_trans_telem.flywheel_state = 0;
    trans_overlay_init();
    do_patch();

    if (p && p->register_for_channel) {
        int r_spd = p->register_for_channel("truck.speed", SCS_U32_NIL, SCS_VALUE_TYPE_float,
                                            SCS_TELEMETRY_CHANNEL_FLAG_each_frame, telem_channel_cb, NULL);
        if (r_spd != 0) {
            r_spd = p->register_for_channel("truck.speed", SCS_U32_NIL, SCS_VALUE_TYPE_float,
                                            SCS_TELEMETRY_CHANNEL_FLAG_none, telem_channel_cb, NULL);
        }
        int r_thr = p->register_for_channel("truck.input.throttle", SCS_U32_NIL, SCS_VALUE_TYPE_float,
                                            SCS_TELEMETRY_CHANNEL_FLAG_each_frame, telem_channel_cb, NULL);
        if (r_thr != 0) {
            r_thr = p->register_for_channel("truck.input.throttle", SCS_U32_NIL, SCS_VALUE_TYPE_float,
                                            SCS_TELEMETRY_CHANNEL_FLAG_none, telem_channel_cb, NULL);
        }
        int r_rpm = p->register_for_channel("truck.engine.rpm", SCS_U32_NIL, SCS_VALUE_TYPE_float,
                                            SCS_TELEMETRY_CHANNEL_FLAG_each_frame, telem_channel_cb, NULL);
        if (r_rpm != 0) {
            r_rpm = p->register_for_channel("truck.engine.rpm", SCS_U32_NIL, SCS_VALUE_TYPE_float,
                                            SCS_TELEMETRY_CHANNEL_FLAG_none, telem_channel_cb, NULL);
        }
        int r_brk = p->register_for_channel("truck.input.brake", SCS_U32_NIL, SCS_VALUE_TYPE_float,
                                            SCS_TELEMETRY_CHANNEL_FLAG_each_frame, telem_channel_cb, NULL);
        if (r_brk != 0) {
            r_brk = p->register_for_channel("truck.input.brake", SCS_U32_NIL, SCS_VALUE_TYPE_float,
                                            SCS_TELEMETRY_CHANNEL_FLAG_none, telem_channel_cb, NULL);
        }
        int r_steer = p->register_for_channel("truck.input.steering", SCS_U32_NIL, SCS_VALUE_TYPE_float,
                                              SCS_TELEMETRY_CHANNEL_FLAG_each_frame, telem_channel_cb, NULL);
        if (r_steer != 0) {
            r_steer = p->register_for_channel("truck.input.steering", SCS_U32_NIL, SCS_VALUE_TYPE_float,
                                              SCS_TELEMETRY_CHANNEL_FLAG_none, telem_channel_cb, NULL);
        }
        int r_cc = p->register_for_channel("truck.cruise_control", SCS_U32_NIL, SCS_VALUE_TYPE_float,
                                           SCS_TELEMETRY_CHANNEL_FLAG_none, telem_channel_cb, NULL);
        int r_pk = p->register_for_channel("truck.brake.parking", SCS_U32_NIL, SCS_VALUE_TYPE_bool,
                                           SCS_TELEMETRY_CHANNEL_FLAG_none, telem_channel_cb, NULL);
        int r_eng = p->register_for_channel("truck.engine.enabled", SCS_U32_NIL, SCS_VALUE_TYPE_bool,
                                            SCS_TELEMETRY_CHANNEL_FLAG_none, telem_channel_cb, NULL);

        trans_flight_log(TRANS_LOG_INFO,
            "Telemetry registered: spd=%d, thr=%d, rpm=%d, brk=%d, steer=%d, cc=%d, pk=%d, eng=%d (Game: %s, ID: %s, Ver: %u)",
            r_spd, r_thr, r_rpm, r_brk, r_steer, r_cc, r_pk, r_eng,
            p->common.game_name ? p->common.game_name : "ETS2",
            p->common.game_id ? p->common.game_id : "?",
            p->common.game_version);
    }
    return 0;
}

__declspec(dllexport) void __cdecl scs_telemetry_shutdown(void)
{
    trans_log("scs_telemetry_shutdown called");
    trans_overlay_shutdown();
}

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID reserved)
{
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) {
        HMODULE dummy;
        DisableThreadLibraryCalls(inst);
        init_paths(inst);
        load_cfg();
        g_trans_telem.idle_rpm = 750.0f;
        g_trans_telem.rpm_limit = 6900.0f;
        g_trans_telem.target_rev_rpm = 750.0f;
        g_trans_telem.flywheel_state = 0;
        trans_log("DllMain: ATTACH, menu_key='%s', menu_vk=0x%X, enabled=%d", cfg.menu_key, cfg.menu_vk, cfg.enabled);
        GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_PIN |
                           GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS,
                           (LPCWSTR)(void *)&DllMain, &dummy);
    } else if (reason == DLL_PROCESS_DETACH) {
        trans_log("DllMain: DETACH");
        trans_overlay_shutdown();
    }
    return TRUE;
}


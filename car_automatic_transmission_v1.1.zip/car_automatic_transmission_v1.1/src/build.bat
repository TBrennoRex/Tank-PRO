@echo off
setlocal enabledelayedexpansion

where gcc >nul 2>nul
if %ERRORLEVEL% neq 0 (
    set "PATH=C:\Users\jastr\re-tools\w64devkit\bin;%PATH%"
)

echo [1/3] Compiling C sources (car_automatic_transmission, minhook)...
gcc -O2 -c car_automatic_transmission.c minhook/hook.c minhook/buffer.c minhook/trampoline.c minhook/hde/hde64.c
if %ERRORLEVEL% neq 0 exit /b %ERRORLEVEL%

echo [2/3] Compiling C++ sources (ui_overlay, car_automatic_transmission_manager)...
g++ -O2 -c ui_overlay.cpp car_automatic_transmission_manager/car_automatic_transmission_manager.cpp car_automatic_transmission_manager/car_automatic_transmission_manager_draw.cpp car_automatic_transmission_manager/car_automatic_transmission_manager_widgets.cpp car_automatic_transmission_manager/car_automatic_transmission_manager_tables.cpp car_automatic_transmission_manager/car_automatic_transmission_manager_impl_win32.cpp car_automatic_transmission_manager/car_automatic_transmission_manager_impl_dx11.cpp
if %ERRORLEVEL% neq 0 exit /b %ERRORLEVEL%

echo [3/3] Linking car_automatic_transmission.dll...
g++ -shared -o car_automatic_transmission.dll car_automatic_transmission.o hook.o buffer.o trampoline.o hde64.o ui_overlay.o car_automatic_transmission_manager.o car_automatic_transmission_manager_draw.o car_automatic_transmission_manager_widgets.o car_automatic_transmission_manager_tables.o car_automatic_transmission_manager_impl_win32.o car_automatic_transmission_manager_impl_dx11.o car_automatic_transmission.def -ld3d11 -ldxgi -ld3dcompiler -ldwmapi -ldinput8 -ldxguid -lkernel32 -luser32 -lgdi32 -lshell32 -static -lm
if %ERRORLEVEL% neq 0 exit /b %ERRORLEVEL%

del /Q *.o 2>nul

if not exist "..\bin\win_x64\plugins\car_automatic_transmission" mkdir "..\bin\win_x64\plugins\car_automatic_transmission"
copy /Y car_automatic_transmission.dll ..\bin\win_x64\plugins\car_automatic_transmission.dll >nul
echo Built and copied to ..\bin\win_x64\plugins\car_automatic_transmission.dll

if exist "C:\Program Files (x86)\Steam\steamapps\common\Euro Truck Simulator 2\bin\win_x64\plugins" (
    if not exist "C:\Program Files (x86)\Steam\steamapps\common\Euro Truck Simulator 2\bin\win_x64\plugins\car_automatic_transmission" mkdir "C:\Program Files (x86)\Steam\steamapps\common\Euro Truck Simulator 2\bin\win_x64\plugins\car_automatic_transmission"
    copy /Y car_automatic_transmission.dll "C:\Program Files (x86)\Steam\steamapps\common\Euro Truck Simulator 2\bin\win_x64\plugins\car_automatic_transmission.dll" >nul 2>nul
    if errorlevel 1 (
        del /Q "C:\Program Files (x86)\Steam\steamapps\common\Euro Truck Simulator 2\bin\win_x64\plugins\car_automatic_transmission.dll.old" >nul 2>nul
        move /Y "C:\Program Files (x86)\Steam\steamapps\common\Euro Truck Simulator 2\bin\win_x64\plugins\car_automatic_transmission.dll" "C:\Program Files (x86)\Steam\steamapps\common\Euro Truck Simulator 2\bin\win_x64\plugins\car_automatic_transmission.dll.old" >nul 2>nul
        copy /Y car_automatic_transmission.dll "C:\Program Files (x86)\Steam\steamapps\common\Euro Truck Simulator 2\bin\win_x64\plugins\car_automatic_transmission.dll" >nul
    )
    copy /Y ..\bin\win_x64\plugins\car_automatic_transmission\car_automatic_transmission.cfg "C:\Program Files (x86)\Steam\steamapps\common\Euro Truck Simulator 2\bin\win_x64\plugins\car_automatic_transmission\car_automatic_transmission.cfg" >nul 2>nul
    echo Deployed directly to ETS2 Steam plugins folder!
)

#pragma once
#include <windows.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int   enabled;
    int   up_step;
    int   down_step;
    int   kick_step;
    float thr_gain;
    float thr_peak;
    float min_rpm_hi;
    float thr_lo;
    float thr_hi;
    float thr_curve;
    int   dn_on_accel;
    float fast_off_hold;
    int   coast_hold;
    float coast_thr;
    int   max_coast_gear;
    float coast_timeout;
    float tip_in_delay;
    float inter_shift_delay;
    float up_delay;
    float dn_delay;
    float flywheel_inertia;
    float flywheel_response;
    float flywheel_drop_rate;
    char  menu_key[32];
    int   menu_vk;
    char  mode_key[32];
    int   mode_vk;
} trans_config_t;

typedef struct {
    int   enabled;
    int   up_step;
    int   down_step;
    int   kick_step;
    float thr_gain;
    float thr_peak;
    float min_rpm_hi;
    float thr_lo;
    float thr_hi;
    float thr_curve;
    float fast_off_hold;
    int   coast_hold;
    float coast_thr;
    int   max_coast_gear;
    float coast_timeout;
    float tip_in_delay;
    float inter_shift_delay;
    float up_delay;
    float dn_delay;
    float flywheel_inertia;
    float flywheel_response;
    float flywheel_drop_rate;
} trans_mode_t;

extern trans_config_t cfg;
extern trans_mode_t g_modes[4];
extern char g_cfg_path[MAX_PATH * 2];
extern char g_cfg_dir[MAX_PATH * 2];

#define trans_log(...) ((void)0)
#define trans_flight_log(...) ((void)0)

typedef struct {
    int   active;
    int   gear;
    int   forward_gear_count;
    int   reverse_gear_count;
    char  gear_str[16];
    float speed_kmh;
    float accel_mps2;
    float accel_g;
    float brake;
    float throttle;
    float raw_throttle;
    int   bos_active;
    float pedal_ramp;
    float steering;
    float cruise_control_kmh;
    int   parking_brake;
    int   engine_enabled;
    float idle_rpm;
    float rpm_limit;
    float engine_rpm;
    float rpm_grad;
    float thr_grad;
    float win_min_rpm;
    float win_max_rpm;
    float win_min_orig;
    float win_max_orig;
    float time_since_shift;
    int   upshift_locked;
    int   downshift_locked;
    int   inter_shift_locked;
    float inter_shift_remaining;
    int   brake_locked;
    int   fast_off_active;
    float fast_off_remaining;
    int   coast_active;
    int   coast_downhill;
    float coast_remaining;
    int   tip_in_active;
    float tip_in_remaining;
    int   patches_applied;
    int   window_sites;
    char  status_line[128];

    float dsg_k1_pressure;
    float dsg_k2_pressure;
    float dsg_k1_torque;
    float dsg_k2_torque;
    int   dsg_active_clutch;
    int   dsg_preselected_gear;
    int   dsg_phase;
    char  dsg_phase_str[24];
    float dsg_propshaft_torque;
    float dsg_diff_ratio;
    float dsg_wheel_torque;
    float dsg_inertia_kick_nm;
    float dsg_active_blip_nm;
    int   dsg_is_skip_shift;
    int   dsg_ignition_cut;

    float target_rev_rpm;
    int   flywheel_state;
} trans_telemetry_t;

#define engine_idle_rpm idle_rpm
#define rev_limiter_rpm rpm_limit

extern trans_telemetry_t g_trans_telem;

const char *trans_get_mode_name(int idx);

int  trans_parse_key(const char *name);
const char* trans_vk_to_name(int vk);
void trans_set_menu_key(const char *name);
void trans_set_menu_vk(int vk);
void trans_set_mode_key(const char *name);
void trans_set_mode_vk(int vk);
void trans_cycle_mode(void);
void trans_set_current_mode_idx(int idx);
int  trans_get_current_mode_idx(void);
void trans_trigger_hud_notification(const char* title, const char* desc, int mode_idx);
void trans_save_config(void);
void trans_reload_config(void);
void trans_reset_defaults(void);
void trans_apply_preset(const char *preset);
void trans_switch_mode(int mode_idx);
void trans_apply_mode_idx(int idx);
void trans_update_gate(void);

void trans_overlay_init(void);
void trans_overlay_shutdown(void);

#ifdef __cplusplus
}
#endif


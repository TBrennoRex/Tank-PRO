# car_automatic_transmission

A plugin for Euro Truck Simulator 2 that makes the automatic gearbox behave like a modern car's automatic transmission instead of a truck's. Written for car mods, but applies to every vehicle.

## Controls

- Press **F9** (default) to toggle the Automatic Transmission Manager overlay.
- Press **F8** (default) to cycle through drive modes (`Normal` -> `Sport` -> `Comfort` -> `Stock`).
- Both hotkeys can be rebound live directly in the GUI or configured in `car_automatic_transmission.cfg`.

## Requirements

Developed and verified against Euro Truck Simulator 2, Windows 64-bit. Tested with pedals and keyboard.

## Install

Copy the “bin” folder from the archive into your ETS2 installation directory, so the DLL ends up here: 

```
Euro Truck Simulator 2\bin\win_x64\plugins\car_automatic_transmission.dll
```

Create the `plugins` folder if it does not exist. Start the game once and the folder `car_automatic_transmission` holding `car_automatic_transmission.cfg` appears next to the DLL:

```
Euro Truck Simulator 2\bin\win_x64\plugins\car_automatic_transmission\car_automatic_transmission.cfg
```

To uninstall, just delete the DLL and the `car_automatic_transmission` folder.

## Configuration

You can configure everything live in the **In-Game GUI** or edit `car_automatic_transmission\car_automatic_transmission.cfg` directly.

### General & Hotkeys

| Key                  | Default   |   Range   | What it does                                             |
| :------------------- | :-------: | :-------: | :------------------------------------------------------- |
| `enabled`            |    `1`    | `0` / `1` | `0` turns the plugin off completely                      |
| `mode`               | `Normal`  | Mode name | Active drive mode (`Normal`, `Sport`, `Comfort`, `Stock`)|
| `menu_key`           |   `F9`    | Key Name  | Hotkey to open/close menu                                |
| `mode_key`           |   `F8`    | Key Name  | Hotkey to cycle drive modes                              |

### Gear Steps

| Key                   | Default | Range | What it does                                                    |
| :-------------------- | :-----: | :---: | :-------------------------------------------------------------- |
| `gears_per_upshift`   |   `1`   |  `0`+ | Gears per upshift. `1` = sequential, `0` = unlimited (stock)    |
| `gears_per_downshift` |   `2`   |  `0`+ | Gears per downshift step                                        |
| `gears_on_kickdown`   |   `0`   |  `0`+ | Gears per kickdown step. `0` = as far as needed                 |

### Shift Map

Moves the RPM window up with throttle input, so the gearbox downshifts earlier under load and holds gears longer.

| Key          | Default |    Range    | What it does                                                                |
| :----------- | :-----: | :---------: | :-------------------------------------------------------------------------- |
| `min_rpm_hi` | `0.72`  | `0.0`-`1.0` | Minimum target RPM at full pedal, as a fraction of the rev limit            |
| `thr_lo`     | `0.10`  | `0.0`-`1.0` | Below this pedal position, shift points stay stock                          |
| `thr_hi`     | `0.85`  | `0.0`-`1.0` | Pedal position where full kickdown shift RPM is reached                     |
| `thr_curve`  | `1.60`  | `0.5`-`3.0` | Exponent curve of throttle progression (higher = gentler low pedal)         |
| `thr_peak`   | `0.90`  | `0.0`-`1.0` | Ceiling for the top of the shift window, as a fraction of the rev limit     |
| `thr_gain`   | `3.00`  |    `0`+     | Dynamic spread of the shift window. `0` disables the map                    |

### Shift Timing & Delays

| Key               | Default |    Range    | What it does                                                                 |
| :---------------- | :-----: | :---------: | :--------------------------------------------------------------------------- |
| `fast_off_hold`   | `2.00`  |   seconds   | Hold timer upon rapid throttle release (Fast-Off / Hang-On). `0` = off       |
| `coast_hold`      |   `1`   |  `0` / `1`  | Holds gear during coasting for engine braking / drag torque                  |
| `coast_threshold` | `0.06`  |`0.01`-`0.20`| Throttle threshold below which coasting is active (default: 6%)              |
| `coast_timeout`   | `6.00`  |   seconds   | Coast hold timeout before auto-shifting to overdrive. `0` = off              |
| `tip_in_delay`    | `0.45`  |   seconds   | Debounce settling delay after coasting before upshifting to overdrive        |
| `inter_shift_delay`| `0.75` |   seconds   | Minimum pause between any shifts (anti-hunting protection)                   |
| `upshift_delay`   | `0.00`  |   seconds   | Static delay before the next upshift. `0` = off                              |
| `downshift_delay` | `0.00`  |   seconds   | Static delay before the next downshift. `0` = off                            |

### Flywheel & Rev Dynamics

Simulates realistic low-inertia sports car flywheel behavior in neutral and rev-matching dynamics.

| Key                   | Default |    Range    | What it does                                                                 |
| :-------------------- | :-----: | :---------: | :--------------------------------------------------------------------------- |
| `flywheel_inertia`    | `0.18`  | `0.05`-`0.50` | Flywheel inertia (kg*m²). Lower value = faster revving in neutral          |
| `flywheel_response`   | `1.50`  | `0.50`-`4.00` | Rev-up throttle acceleration multiplier                                    |
| `flywheel_drop_rate`  | `1.20`  | `0.50`-`3.00` | RPM drop rate on throttle release until idle handoff                       |

## Modes & Presets

All drive modes are fully and individually configurable in `car_automatic_transmission.cfg` under their respective sections (`[Normal]`, `[Sport]`, `[Comfort]`, `[Stock]`):

- **Normal**: Balanced automatic feel (`thr_lo=0.10`, `min_rpm_hi=0.72`, `thr_curve=1.60`, `thr_gain=3.00`, `flywheel_inertia=0.18`).
- **Sport**: High-revving, eager kickdowns, crisp acceleration (`thr_lo=0.00`, `min_rpm_hi=0.88`, `thr_curve=1.25`, `thr_gain=4.00`, `fast_off_hold=3.50s`, `flywheel_inertia=0.10`).
- **Comfort**: Low-RPM cruising, early upshifts, relaxed transitions (`thr_lo=0.25`, `min_rpm_hi=0.55`, `thr_curve=2.10`, `thr_gain=1.80`, `coast_hold=0`, `flywheel_inertia=0.25`).
- **Stock**: Stock truck gearbox behavior without shift map.

## Multiplayer

Single player only. Do not use with TruckersMP or Convoy.

## Antivirus

The DLL writes to the game's code in memory, which some scanners flag by behaviour alone. It is unsigned. The full source is included so you can read it and build the DLL yourself.

## Building

Requires a MinGW-w64 toolchain such as w64devkit:

```
cd src
build.bat
```

## License

MIT, see LICENSE.

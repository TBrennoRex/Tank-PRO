KPT PRO Native Updater v7

Correção da enumeração Windows.Devices.Midi/Enumeration.
- instala explicitamente Foundation, Foundation.Collections e Foundation.Metadata;
- usa as sobrecargas PyWinRT nomeadas find_all_async_aqs_filter* em vez de depender de find_all_async genérico;
- mantém o transporte MIDI WinRT;
- não inicia flash automaticamente.

Execute run_updater.bat e use primeiro Procurar KPT PRO.

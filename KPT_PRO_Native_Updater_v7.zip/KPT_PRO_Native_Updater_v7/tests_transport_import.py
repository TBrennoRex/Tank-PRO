"""Syntax-only transport smoke test; WinRT import is intentionally skipped off-Windows."""
import ast
from pathlib import Path
ast.parse(Path('winrt_midi.py').read_text())
print('transport source parse: OK')
